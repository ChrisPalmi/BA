#include "abstractpropellergeometry.h"
#include <QDebug>

AbstractPropellerGeometry::AbstractPropellerGeometry()
{

}

QList<QList<QVector3D> > AbstractPropellerGeometry::geometry() const
{
    return m_geometry;
}

void AbstractPropellerGeometry::
setGeometry(const QList<QList<QVector3D> >& geometry)
{
    if(geometry.isEmpty() == false)
    {
        m_geometry = geometry;
        setGeometrySet(true);
    }
    else
    {
        setGeometrySet(false);
        qDebug() << "ERROR:\nGeometry was not set!\nGiven geometry was empty!";
    }
}

bool AbstractPropellerGeometry::geometrySet() const
{
    return m_geometrySet;
}

void AbstractPropellerGeometry::setGeometrySet(bool geometrySet)
{
    m_geometrySet = geometrySet;
}
