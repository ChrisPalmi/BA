#ifndef PROPELLERBLADESKINGEOMETRY_H
#define PROPELLERBLADESKINGEOMETRY_H

#include "abstractpropellergeometry.h"

/**
 * @brief The PropellerBladeSkinGeometry class is a derived class from
 *        AbstractPropellerGeometry class. it provides datastructures to contain
 *        geometries (ordered point lists) of propeller skins
 */
class PropellerBladeSkinGeometry : public AbstractPropellerGeometry
{
public:

    /**
     * @brief PropellerBladeSkinGeometry constructor
     */
    PropellerBladeSkinGeometry();

    /**
     * @brief PropellerBladeSkinGeometry constructor
     * @param geometry (ordered pointlist to which m_geometry is set to)
     */
    PropellerBladeSkinGeometry(QList<QList<QVector3D>> geometry);

    /**
     * @brief ~PropellerBladeSkinGeometry destructor
     */
    ~PropellerBladeSkinGeometry();

};

#endif // PROPELLERBLADESKINGEOMETRY_H
