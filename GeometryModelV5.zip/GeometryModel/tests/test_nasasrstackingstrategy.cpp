#include "nasasrstackingstrategy.h"
#include "designparametercsvfilereader.h"
#include "geometrytransformation.h"

#include <QDebug>
#include <QString>

#include "gtest.h"



class test_NASASRStackingStrategy : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

    NASASRStackingStrategy strategy;
    DesignParameterCSVFileReader reader;
    GeometryTransformation trafo;
};

TEST_F(test_NASASRStackingStrategy, errorHandlingTest)
{
    //faedelProfiles
    //no sweepline set
    QList<QList<QVector3D>> profiles;
    profiles.clear();

    QList<QVector3D> pI;
    pI.clear();
    QList<QVector3D> pII;
    pII.clear();

    QVector3D pOne(0.0, -1.0, 10.0);
    QVector3D pTwo(-2.5, 6.99, 0.0);

    pI.append(pOne);
    pII.append(pTwo);

    profiles.append(pI);
    profiles.append(pII);

    QList<QList<QVector3D>> newProfiles = strategy.stackAirfoils(profiles);

    ASSERT_NEAR(profiles[0][0].x(), newProfiles[0][0].x(), 0.00001);
    ASSERT_NEAR(profiles[0][0].y(), newProfiles[0][0].y(), 0.00001);
    ASSERT_NEAR(profiles[0][0].z(), newProfiles[0][0].z(), 0.00001);
    ASSERT_NEAR(profiles[1][0].x(), newProfiles[1][0].x(), 0.00001);
    ASSERT_NEAR(profiles[1][0].y(), newProfiles[1][0].y(), 0.00001);
    ASSERT_NEAR(profiles[1][0].z(), newProfiles[1][0].z(), 0.00001);

    //sweep line with two points with same y coordinate
    QList<QPointF> sLine;
    sLine.clear();

    sLine.append(QPointF(0.0, 0.0));
    sLine.append(QPointF(0.5, 0.3));
    sLine.append(QPointF(1.0, 0.3));

    NASASRStackingStrategy s;

    ASSERT_FALSE(s.sweepLineSet());
    s.setSweepLine(sLine);
    ASSERT_FALSE(s.sweepLineSet());

    sLine.clear();

    //sweep line with two points with decreasing y coordinates
    sLine.append(QPointF(0.0, 0.0));
    sLine.append(QPointF(0.5, 0.3));
    sLine.append(QPointF(1.0, 0.2));

    s.setSweepLine(sLine);
    ASSERT_FALSE(s.sweepLineSet());

}

TEST_F(test_NASASRStackingStrategy, faedelProfilesTest)
{
    QList<QPointF> sweepLine;
    sweepLine.clear();
    sweepLine.append(QPointF(0.0, 0.3));
    sweepLine.append(QPointF(-1.0, 0.75));
    sweepLine.append(QPointF(1.0, 1.5));

    strategy.setSweepLine(sweepLine);

    QVector3D testPnt(1.0, 0.0, 0.3);
    QVector3D testPntII(1.0, 1.0, 0.75);
    QVector3D radPnt(0.0, 1.0, 1.5);

    QList<QVector3D> testProfile;
    QList<QVector3D> testProfileI;
    QList<QVector3D> testProfileII;
    testProfile.clear();
    testProfileI.clear();
    testProfileII.clear();
    testProfile.append(testPnt);
    testProfileI.append(testPntII);
    testProfileII.append(radPnt);

    QList<QList<QVector3D>> testProp;
    testProp.clear();
    testProp.append(testProfile);
    testProp.append(testProfileI);
    testProp.append(testProfileII);

    QList<QList<QVector3D>> newProp = strategy.stackAirfoils(testProp);

    //no sweep at r = 0.3 -> see testPnt
    ASSERT_NEAR(0.5, newProp[0][0].x(), 0.001);
    ASSERT_NEAR(0.0, newProp[0][0].y(), 0.001);

    //blade angle at r = 0.75 is about 45 degrees
    QVector3D sweeppnt = trafo.rotatePnt(QVector3D(-1.0, 0.0, 0.75), 45.0);
    QVector3D estimate;
    estimate.setX((testPntII.x() / 2.0) + sweeppnt.x());
    estimate.setY((testPntII.y() / 2.0) + sweeppnt.y());
    newProp = strategy.stackAirfoils(testProp);

    ASSERT_NEAR(estimate.x(), newProp[1][0].x(), 0.00001);
    ASSERT_NEAR(estimate.y(), newProp[1][0].y(), 0.00001);

}

