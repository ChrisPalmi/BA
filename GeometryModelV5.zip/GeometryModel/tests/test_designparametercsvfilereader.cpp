#include "designparametercsvfilereader.h"

#include <QString>

#include "gtest.h"

class Test_DesignParameterCSVFileReader : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

    DesignParameterCSVFileReader reader;

};

TEST_F(Test_DesignParameterCSVFileReader, readFileTest)
{
    //Test file has 5 columns
    //p1 should be 0.1|0.1, p2 should be 0.2|0.2 and so on

    QString path = "D:/data/PraxisphaseVI/SRIII/DesignParameters/"
                   "QuelleSonstige/DesignParamTestFile.csv";

    QList<QPointF> list = reader.readFile(path);

    ASSERT_NEAR(0.1, list[0].x(), 0.00001);
    ASSERT_NEAR(0.1, list[0].y(), 0.00001);
    ASSERT_NEAR(0.2, list[1].x(), 0.00001);
    ASSERT_NEAR(0.2, list[1].y(), 0.00001);
    ASSERT_NEAR(0.3, list[2].x(), 0.00001);
    ASSERT_NEAR(0.3, list[2].y(), 0.00001);
    ASSERT_NEAR(0.4, list[3].x(), 0.00001);
    ASSERT_NEAR(0.4, list[3].y(), 0.00001);
    ASSERT_NEAR(0.5, list[4].x(), 0.00001);
    ASSERT_NEAR(0.5, list[4].y(), 0.00001);
}

TEST_F(Test_DesignParameterCSVFileReader, errorHandlingTest)
{
    QString path = "ERRORPATH";
    QList<QPointF> list = reader.readFile(path);

    ASSERT_TRUE(list.isEmpty());
}
