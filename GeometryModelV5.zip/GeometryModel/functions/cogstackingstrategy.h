#ifndef COGSTACKINGSTRATEGY_H
#define COGSTACKINGSTRATEGY_H

#include "abstractairfoilstackingstrategy.h"
#include "geometrytransformation.h"

/**
 * @brief The COGStackingStrategy class is a derived class from
 *        AbstractAirfoilStackingStrategy class. It provides functionalities to
 *        stack airfoils along radial axis at their center of gravity
 */
class COGStackingStrategy : public AbstractAirfoilStackingStrategy
{
public:

    /**
     * @brief COGStackingStrategy constructor
     */
    COGStackingStrategy();

    /**
     * @brief ~COGStackingStrategy destructor
     */
    ~COGStackingStrategy();

    /**
     * @brief stackAirfoils function provides the functionality to stack
     *        airfoils along radial axis at their center of gravity
     * @param airfoils (ordered pointlists which contain geometric information
     *        of airfoils)
     * @return stacked airfoils (ordered pointlists)
     */
    QList<QList<QVector3D>> stackAirfoils
    (const QList<QList<QVector3D>> &airfoils);


private:

    /**
     * @brief calculateCOG function provides the functionality to calculate the
     *        center of gravity out of a closed polygon
     * @param polygon (ordered pointlist)
     * @return center of gravity of polygon
     */
    QVector3D calculateCOG(const QList<QVector3D> &polygon);

    /**
     * @brief calculateArea function provides the functionality to calculate the
     *        area out of a closed polygon
     * @param polygon (ordered pointlist)
     * @return area of polygon
     */
    double calculateArea(const QList<QVector3D> &polygon);

    /**
     * @brief m_transformer (object of class GeometryTransformation which
     *        provides functionalities to transform geometries
     *        (ordered pointlists))
     */
    GeometryTransformation m_transformer;

};

#endif // COGSTACKINGSTRATEGY_H
