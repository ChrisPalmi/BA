#ifndef PROPELLERBLADESKINSHAPEBUILDER_H
#define PROPELLERBLADESKINSHAPEBUILDER_H

#include "abstractpropellershapebuilder.h"
#include "pointadapter.h"

#include "TopoDS_Wire.hxx"
#include "TColgp_HArray1OfPnt.hxx"

#include <QList>
#include <QVector3D>


/**
 * @brief The PropellerBladeSkinShapeBuilder class provides functionalities to
 *        create an Open Cascade TopoDS_Shape out of a given geometry
 *        (ordered pointlists)
 */
class PropellerBladeSkinShapeBuilder
{
public:

    /**
     * @brief PropellerBladeSkinShapeBuilder constructor
     */
    PropellerBladeSkinShapeBuilder();

    /**
     * @brief ~PropellerBladeSkinShapeBuilder destructor
     */
    ~PropellerBladeSkinShapeBuilder();

    /**
     * @brief buildShape function provides the functionality to build a
     *        TopoDS_Shape object out of a given geometry (ordered pointlist)
     * @param geometry (ordered pointlist)
     * @return object of class TopoDS_Shape (TopoDS_Solid) which was built out
     *         of the given geometry
     */
    TopoDS_Shape buildShape(const QList<QList<QVector3D>> &geometry);

    /**
     * @brief buildShape function provides the functionality to build a
     *        TopoDS_Shape object out of a given geometry (ordered Open Cascade
     *        array)
     * @param ocGeometry (ordered Open Cascade array)
     * @return object of class TopoDS_Shape (TopoDS_Solid) which was built out
     *         of the given geometry
     */
    TopoDS_Shape buildShape
    (const QList<Handle(TColgp_HArray1OfPnt)> &ocGeometry);

private:

    /**
     * @brief m_adapter (object of class PointAdapter, which provides
     *        functionalities to adapt point objects of different classes with
     *        each other)
     */
    PointAdapter m_adapter;

    /**
     * @brief shapeBuild (help function to create an object of class
     *        TopoDS_Shape)
     * @param ocGeometry (ordered Open Cascade array)
     * @return object of class TopoDS_Shape (lofted TopoDS_Wires)
     *         which was built out of the given geometry
     */
    TopoDS_Shape shapeBuild
    (const QList<Handle(TColgp_HArray1OfPnt)> &ocGeometry);

    /**
     * @brief shapeBuildNew (help function to create an object of class
     *        TopoDS_Shape)
     * @param ocGeometry (ordered Open Cascade array)
     * @return object of class TopoDS_Shape (TopoDS_Solid)
     *         which was built out of the given geometry
     */
    TopoDS_Shape shapeBuildNew
    (const QList<Handle(TColgp_HArray1OfPnt)> &ocGeometry);



};

#endif // PROPELLERBLADESKINSHAPEBUILDER_H
