#include "cogstackingstrategy.h"

COGStackingStrategy::COGStackingStrategy()
{

}

COGStackingStrategy::~COGStackingStrategy()
{

}

QList<QList<QVector3D> > COGStackingStrategy::
stackAirfoils(const QList<QList<QVector3D>>& airfoils)
{
    QList<QList<QVector3D>> stackedAirfoils;
    stackedAirfoils.clear();

    for(int airfoilAt = 0; airfoilAt < airfoils.size(); airfoilAt++)
    {        
        //calculate direction vector to relocate airfoil at cog

        QVector3D cog = calculateCOG(airfoils.at(airfoilAt));

        QVector3D dirVect;
        dirVect.setX(- cog.x());
        dirVect.setY(- cog.y());
        dirVect.setZ(0.0);

        //relocate airfoil
        QList<QVector3D> stackedAirfoil =
                m_transformer.locateGeometry(airfoils[airfoilAt], dirVect);

        stackedAirfoils.append(stackedAirfoil);
    }

    return stackedAirfoils;
}

QVector3D COGStackingStrategy::calculateCOG(const QList<QVector3D>& polygon)
{

    QList<QVector3D> closedPolygon = polygon;

    //check if polygon is closed
    if(closedPolygon.first().x() != closedPolygon.last().x() ||
       closedPolygon.first().y() != closedPolygon.last().y())
    {
        closedPolygon.append(closedPolygon.first());
    }

    double zCoor = polygon.at(0).z();

    double area = calculateArea(polygon);

    double x = 0.0;
    double y = 0.0;

    //center of gravity is calculated with trapeze equation
    for(int i = 0; i < closedPolygon.size() - 1; ++i)
        x += (closedPolygon.at(i).x() + closedPolygon.at(i + 1).x()) *
             (closedPolygon.at(i).x() * closedPolygon.at(i + 1).y() -
              closedPolygon.at(i + 1).x() * closedPolygon.at(i).y());

    for(int j = 0; j < closedPolygon.size() - 1; ++j)
        y += (closedPolygon.at(j).y() + closedPolygon.at(j + 1).y()) *
             (closedPolygon.at(j).x() * closedPolygon.at(j + 1).y() -
              closedPolygon.at(j + 1).x() * closedPolygon.at(j).y());

    return QVector3D(x / (6.0 * area), y / (6.0 * area), zCoor);

}

double COGStackingStrategy::calculateArea(const QList<QVector3D>& polygon)
{
    double area = 0.0;

    QList<QVector3D> closedPolygon = polygon;

    //check if polygon is closed
    if(closedPolygon.first().x() != closedPolygon.last().x() ||
       closedPolygon.first().y() != closedPolygon.last().y())
    {
        closedPolygon.append(polygon.first());
    }

    for(int i = 0; i < closedPolygon.size() - 1; i++)
    {
        QVector3D pI = closedPolygon.at(i);
        QVector3D pIplusOne = closedPolygon.at(i + 1);
        area += (pI.x() * pIplusOne.y()) - (pIplusOne.x() * pI.y());
    }

    area = area * 0.5;
    return area;
}

