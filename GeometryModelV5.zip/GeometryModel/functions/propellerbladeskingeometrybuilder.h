#ifndef PROPELLERBLADESKINGEOMETRYBUILDER_H
#define PROPELLERBLADESKINGEOMETRYBUILDER_H

#include "abstractpropellergeometrybuilder.h"
#include "nasasrstackingstrategy.h"
#include "geometrytransformation.h"
#include "sweeplinebuilder.h"
#include "propellerbladeskingeometry.h"

#include "propeller.h"

/**
 * @brief The PropellerBladeSkinGeometryBuilder class provides functionalities
 *        to preprocess the normalized geometric information out of a propeller
 *        object and create the original geometry (ordered pointlists) out of it
 */
class PropellerBladeSkinGeometryBuilder :
        public AbstractPropellerGeometryBuilder
{
public:

    /**
     * @brief PropellerBladeSkinGeometryBuilder constructor
     */
    PropellerBladeSkinGeometryBuilder();

    /**
     * @brief ~PropellerBladeSkinGeometryBuilder destructor
     */
    ~PropellerBladeSkinGeometryBuilder();

    /**
     * @brief buildGeometry function provides the functionality to preprocess
     *        the geometric information out of a propeller object and create
     *        the original geometry (ordered pointlist)
     * @param propeller (propeller object which provides geometric information)
     * @param stackingStrategy (object of derived class from
     *        AbstractAirfoilStackingStrategy, which provides the functionality
     *        to stack airfoil geometries by a defined course of action
     * @return original geometry (scaled, turned and stacked)
     */
    QList<QList<QVector3D>> buildGeometry(const Propeller *propeller,
                                          AbstractAirfoilStackingStrategy
                                          &stackingStrategy);

    /**
     * @brief buildPropellerBladeSkinGeometry function provides the
     *        functionality to preprocess the geometric information out of a
     *        propeller object and create an Object of class
     *        PropellerBladeSkinGeometry, which provides the original geometry
     *        (ordered pointlist)
     * @param propeller (propeller object which provides geometric information)
     * @param stackingStrategy stackingStrategy (object of derived class from
     *        AbstractAirfoilStackingStrategy, which provides the functionality
     *        to stack airfoil geometries by a defined course of action
     * @return object of class PropellerBladeSkinGeometry, which provides the
     *         original geometry (ordered pointlist)
     */
    PropellerBladeSkinGeometry buildPropellerBladeSkinGeometry
    (const Propeller *propeller,
     AbstractAirfoilStackingStrategy &stackingStrategy);



private:

    /**
     * @brief m_transformer (object of class GeometryTransformation, which
     *        provides functionalities to transform geometries
     *        (ordered pointlists)
     */
    GeometryTransformation m_transformer;



    bool outputSTLII(QString filepath, QList<QVector3D> station);
};

#endif // PROPELLERBLADESKINGEOMETRYBUILDER_H
