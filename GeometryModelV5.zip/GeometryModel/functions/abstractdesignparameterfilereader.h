#ifndef ABSTRACTDESIGNPARAMETERFILEREADER_H
#define ABSTRACTDESIGNPARAMETERFILEREADER_H

#include <QPointF>
#include <QList>

/**
 * @brief The AbstractDesignParameterFileReader class provides functionalities
 *        to read in design parameters of propellers out of files and create an
 *        ordered point list out of it (Abstract class).
 */
class AbstractDesignParameterFileReader
{
public:


    /**
     * @brief AbstractDesignParameterFileReader constructor
     */
    AbstractDesignParameterFileReader();

    /**
     * @brief ~AbstractDesignParameterFileReader destructor
     */
    virtual ~AbstractDesignParameterFileReader(){}

    /**
     * @brief readFile function has to be overwritten by inheriting classes. It
     *        prvides functionalities to read in data from files which contain
     *        information about design parameters of a propeller
     * @param filepath (path where file is located)
     * @return ordered point list with design parameter information
     */
    virtual QList<QPointF> readFile(const QString &filepath) = 0;
};

#endif // ABSTRACTDESIGNPARAMETERFILEREADER_H
