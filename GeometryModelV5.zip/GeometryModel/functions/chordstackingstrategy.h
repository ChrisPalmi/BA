#ifndef CHORDSTACKINGSTRATEGY_H
#define CHORDSTACKINGSTRATEGY_H

#include "abstractairfoilstackingstrategy.h"
#include "geometrytransformation.h"

/**
 * @brief The ChordStackingStrategy class is a derived class of
 *        AbstractAirfoilStackingStrategy class. It provides functionalities to
 *        stack airfoils along radial axis at a given percentual chordlength
 */
class ChordStackingStrategy : public AbstractAirfoilStackingStrategy
{
public:
    /**
     * @brief ChordStackingStrategy constructor
     */
    ChordStackingStrategy();

    /**
     * @brief ChordStackingStrategy constructor
     * @param stackAt (value between 0.0 and 1.0, percentual chordlength where
     *        airfoils should be stacked)
     */
    ChordStackingStrategy(double stackAt);

    /**
     * @brief ChordStackingStrategy destructor
     */
    ~ChordStackingStrategy();

    /**
     * @brief stackProfiles function provides the functionality to stack
     *        airfoils at a given percentual chord length
     * @param airfoils (ordered point lists providing the geometric inforamtion
     *        of the airfoils)
     * @return stacked airfoils
     */
    QList<QList<QVector3D>> stackAirfoils
    (const QList<QList<QVector3D>> &airfoils);

    /**
     * @brief stackAt (getter function of m_stackAt)
     * @return m_stackAt
     */
    double stackAt() const;

    /**
     * @brief setstackAt (setter function of m_stackAt)
     * @param stackAt (value between 0.0 and 1.0, percentual chordlength where
     *        airfoils should be stacked)
     */
    void setStackAt(double stackAt);

    /**
     * @brief stackAtSet (getter function of m_stackAtSet)
     * @return true if m_stackAt was set, else false
     */
    bool stackAtSet() const;


private:

    /**
     * @brief m_stackAt (member variable with value between 0.0 and 1.0,
     *        percentual chordlength where airfoils should be stacked)
     */
    double m_stackAt;

    /**
     * @brief m_stackAtSet (member variable which is set true if m_stackAt was
     *        set, else false)
     */
    bool m_stackAtSet;

    /**
     * @brief setstackAtSet (setter function for m_stackAtSet)
     * @param stackAtSet (true if m_stackAt was set, else false)
     */
    void setStackAtSet(bool stackAtSet);

    /**
     * @brief m_transformer (object of class GeometryTransformation which
     *        provides functionalities to transform geometries
     *        (ordered pointlists))
     */
    GeometryTransformation m_transformer;
};

#endif // CHORDSTACKINGSTRATEGY_H
