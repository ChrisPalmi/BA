#include "stepexporter.h"
#include "STEPControl_Controller.hxx"
#include "STEPControl_Writer.hxx"
#include <QDebug>

STEPExporter::STEPExporter()
{

}

STEPExporter::~STEPExporter()
{

}

void STEPExporter::exportFile(TopoDS_Shape& geometryShape,
                              Standard_CString& filepath)
{
    STEPControl_Controller::Init();
    STEPControl_Writer stepExporter;
    bool addedShape = stepExporter.Transfer(geometryShape, STEPControl_AsIs);

    if(addedShape)
    {
        setSuccessfulExport(stepExporter.Write(filepath));

        if(successfulExport())
        {
            qDebug() << "STEP output file was successfully created!";
        }
        else
        {
            qDebug() << "ERROR:\nSTEP Output file could not be created!\n"
                        "Please check your geometry";
        }
    }

    else
    {
        qDebug() << "ERROR:\nShape could not be added to STEP Exporter!\n"
                    "No file will be created!\nPlease check your geometry!";
        setSuccessfulExport(false);
    }
}
