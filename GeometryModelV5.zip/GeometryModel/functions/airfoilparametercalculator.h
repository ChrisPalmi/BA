#ifndef AIRFOILPARAMETERCALCULATOR_H
#define AIRFOILPARAMETERCALCULATOR_H

#include <QList>
#include <QVector3D>

/**
 * @brief The AirfoilParameterCalculator class provides functionalities to
 *        calculate several parameters of an airfoil by using their geometry
 *        (ordered pointlist)
 */
class AirfoilParameterCalculator
{
public:
    /**
     * @brief AirfoilParameterCalculator constructor
     */
    AirfoilParameterCalculator();

    /**
     * @brief ~AirfoilParameterCalculator destructor
     */
    ~AirfoilParameterCalculator();

    /**
     * @brief calculateChordLength calculates the chord length of an airfoil
     * @param airfoil (geometry -> ordered pointlist where first point is the
     *                 trailing edge and leading edge is (0.0|0.0)
     * @return chordlength of airfoil
     */
    double calculateChordLength(const QList<QVector3D>& airfoil);

    /**
     * @brief calculateBladeAngleDeg calculates the bladeangle (deg) of an
     *        airfoil
     * @param airfoil (geometry -> ordered pointlist where first point is the
     *                 trailing edge and leading edge is (0.0|0.0)
     * @return bladeangle (deg)
     */
    double calculateBladeAngleDeg(const QList<QVector3D>& airfoil);
};

#endif // AIRFOILPARAMETERCALCULATOR_H
