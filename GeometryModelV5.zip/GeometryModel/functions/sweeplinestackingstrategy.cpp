#define _USE_MATH_DEFINES
#include <cmath>

#include "sweeplinestackingstrategy.h"
#include "sweeplinebuilder.h"

#include "gt_splinefit.h"
#include "rootfinder.h"

#include <QDebug>

SweepLineStackingStrategy::SweepLineStackingStrategy()
{
    setSweepLineSet(false);
}

SweepLineStackingStrategy::SweepLineStackingStrategy(QList<QPointF> sweepLine)
{
    setSweepLine(sweepLine);
}


SweepLineStackingStrategy::~SweepLineStackingStrategy()
{

}

QList<QList<QVector3D> > SweepLineStackingStrategy::
stackAirfoils(const QList<QList<QVector3D> >& airfoils)
{
    if(sweepLineSet() == false)
    {
        qDebug() << "ERROR:\nNo sweep line was set!\n"
                    "Please set it before calling this "
                    "function again!\nSame profiles will be returned!";

        return airfoils;
    }

    QList<QList<QVector3D>> sweptProfiles;
    sweptProfiles.clear();

    for(int profileNumb = 0; profileNumb < airfoils.size(); profileNumb++)
    {

        QList<QVector3D> aProfile;
        aProfile.clear();

        //stack airfoils at 50% chord
        QVector3D dirVect(-(airfoils[profileNumb][0].x() / 2.0),
                          -(airfoils[profileNumb][0].y() / 2.0), 0.0);

        aProfile =
                m_transformer.locateGeometry(airfoils.at(profileNumb), dirVect);

        //get sweep
        double profileAtZ = airfoils[profileNumb][0].z();
        double sweep = calculateSweep(profileAtZ);

        //consider sweep an no lean
        for(int pointNumb = 0; pointNumb < airfoils[profileNumb].size();
            pointNumb++)
        {
            aProfile[pointNumb].setX(aProfile[pointNumb].x() + sweep);
        }

        sweptProfiles.append(aProfile);
    }

    return sweptProfiles;
}

QList<QPointF> SweepLineStackingStrategy::sweepLine() const
{
    return m_sweepLine;
}

void SweepLineStackingStrategy::setSweepLine(const QList<QPointF>& sweepLine)
{
    if(sweepLine.isEmpty())
    {
        qDebug() << "WARNING:\nSweep line is empty!";
        setSweepLineSet(false);
    }
    else
    {
        bool readyToSetSweepLine = true;
        for(int listAt = 0; listAt < (sweepLine.size() - 1); listAt++)
        {
            if(sweepLine.at(listAt).y() >= sweepLine.at(listAt + 1).y())
            {
                qDebug() << "ERROR:\nY values of points have to increase with "
                            "every step!\n Sweep line won´t be set!";
                readyToSetSweepLine = false;
                setSweepLineSet(false);
            }
        }

        if(readyToSetSweepLine)
        {
            m_sweepLine = sweepLine;
            setSweepLineSet(true);
        }
    }
}

bool SweepLineStackingStrategy::sweepLineSet() const
{
    return m_sweepLineSet;
}

void SweepLineStackingStrategy::setSweepLineSet(bool sweepLineSet)
{
    m_sweepLineSet = sweepLineSet;
}

double SweepLineStackingStrategy::calculateSweep(double radi)
{
    if(sweepLineSet() == false)
    {
        qDebug() << "ERROR:\n No sweep line was set!\n Please set th sweep line"
                    " before calling this function again!\n Sweep of 0.0 will"
                    "be returned!";

        return 0.0;

    }

    if(radi < 0.0)
    {
        qDebug() << "ERROR:\n No negative radi allowed!\n Sweep of 0.0 "
                    "will be returned!";

        return 0.0;
    }

    if(radi > m_sweepLine.last().y())
    {
        qDebug() << "ERROR: \n Your chosen radi ist bigger than max size of "
                    "sweep line you set!\n Sweep of 0.0 will be returned!";

        return 0.0;
    }

    double sweep;

    for(int i = 0; i < m_sweepLine.size() - 1; i++)
    {


        if(m_sweepLine.at(i).y() <= radi &&
           m_sweepLine.at(i + 1).y() >= radi)
        {

            //calculate sweep
            //linear interpolation between pnt i and i+1 of semichord

            QPointF dirVect(m_sweepLine.at(i + 1).x() - m_sweepLine.at(i).x(),
                            m_sweepLine.at(i + 1).y() - m_sweepLine.at(i).y());

            if(dirVect.y() == 0.0)
            {
                qDebug() << "ERROR:\n Y values of your sweep line have to "
                            "increase with every point!\nSweep of 0.0 will be "
                            "returned!";
                sweep = 0.0;
            }
            else
            {
                double factor = (radi - m_sweepLine.at(i).y()) / dirVect.y();
                sweep = m_sweepLine.at(i).x() + factor * dirVect.x();
            }


        }
    }

    return sweep;
}
