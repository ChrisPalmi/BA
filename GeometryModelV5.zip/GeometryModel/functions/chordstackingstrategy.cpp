#include "chordstackingstrategy.h"

ChordStackingStrategy::ChordStackingStrategy()
{
    setStackAtSet(false);
}

ChordStackingStrategy::ChordStackingStrategy(double stackAt)
{
    setStackAt(stackAt);
}

ChordStackingStrategy::~ChordStackingStrategy()
{

}

QList<QList<QVector3D> > ChordStackingStrategy::
stackAirfoils(const QList<QList<QVector3D> >& airfoils)
{
    if(stackAtSet())
    {

        QList<QList<QVector3D>> stackedAirfoils;
        stackedAirfoils.clear();

        for(int airfoilAt = 0; airfoilAt < airfoils.size(); airfoilAt++)
        {
            //calculate direction vector to relocate airfoil at given %chord

            QVector3D dirVect;
            dirVect.setX(- (airfoils[airfoilAt][0].x() * m_stackAt));
            dirVect.setY(- (airfoils[airfoilAt][0].y() * m_stackAt));
            dirVect.setZ(0.0);

            //relocate airfoil
            QList<QVector3D> stackedAirfoil =
                    m_transformer.locateGeometry(airfoils[airfoilAt], dirVect);

            stackedAirfoils.append(stackedAirfoil);

        }

        return stackedAirfoils;
    }

    else
    {
        qDebug() << "ERROR:\nm_stackAt was not set!\nSame geometry will be "
                    "returned!";
        return airfoils;
    }
}
double ChordStackingStrategy::stackAt() const
{
    return m_stackAt;
}

void ChordStackingStrategy::setStackAt(double stackAt)
{
    if(stackAt >= 0.0 && stackAt <= 1.0)
    {
        m_stackAt = stackAt;
        setStackAtSet(true);
    }
    else
    {
        qDebug() << "WARNING:\nValue for stackAt is not in the allowed "
                    "interval between 0.0 and 1.0!\nm_stackAt was not set!";
        setStackAtSet(false);
    }
}

bool ChordStackingStrategy::stackAtSet() const
{
    return m_stackAtSet;
}

void ChordStackingStrategy::setStackAtSet(bool stackAtSet)
{
    m_stackAtSet = stackAtSet;
}


