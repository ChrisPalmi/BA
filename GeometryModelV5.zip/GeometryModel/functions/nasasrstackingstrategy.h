#ifndef NASASRSTACKINGSTRATEGY_H
#define NASASRSTACKINGSTRATEGY_H

#include "abstractairfoilstackingstrategy.h"
#include "geometrytransformation.h"
#include "airfoilparametercalculator.h"

/**
 * @brief The NASASRStackingStrategy class provides functionalities to
 *        stack airfoil geometries at 50% chord along a given sweep line
 *        (a swept and leaned propeller geometry will be the result)
 */
class NASASRStackingStrategy : public AbstractAirfoilStackingStrategy
{
public:

    /**
     * @brief NASASRStackingStrategy constructor
     */
    NASASRStackingStrategy();

    /**
     * @brief NASASRStackingStrategy constructor
     * @param sweepLine (ordered point list of sweep line from hub to tip)
     */
    NASASRStackingStrategy(QList<QPointF> sweepLine);

    /**
     * @brief ~NASASRStackingStrategy destructor
     */
    ~NASASRStackingStrategy();

    /**
     * @brief stackAirfoils stacks airfoiles by using the NASA strategy for SR
     *        propellers (sweep and lean are considered)
     * @param airfoils (ordererd point lists of airfoils which are stacked at
     *        their leading edge)
     * @return airfoils which are stacked
     */
    virtual QList<QList<QVector3D>>stackAirfoils
    (const QList<QList<QVector3D> > &airfoils);

    /**
     * @brief sweepLine getter function
     * @return member variable of sweepline
     */
    QList<QPointF> sweepLine() const;

    /**
     * @brief setSweepLine setter function for sweep line
     * @param sweepLine (line which should be set)
     */
     void setSweepLine(const QList<QPointF>& sweepLine);

    /**
     * @brief sweepLineSet getter function
     * @return true if sweep line was set, else false
     */
    bool sweepLineSet() const;

    /**
     * @brief calculateSweep calculates the sweep at radi by considering the
     *        sweepline
     * @param radi (rad where sweep should be calculated)
     * @return sweep at radius
     */
    double calculateSweep(double radi);


private:

    /**
     * @brief m_sweepLine (sweep line of this strategy)
     */
    QList<QPointF> m_sweepLine;

    /**
     * @brief m_sweepLineSet (bool variable to check if sweepline is set)
     */
    bool m_sweepLineSet;

    /**
     * @brief setSweepLineSet setter function for bool variable m_sweepLineSet
     * @param sweepLineSet true if sweepline was set, else false
     */
    void setSweepLineSet(bool sweepLineSet);

    /**
     * @brief m_calculator (calculator to calculate the blade angle of a
     *                      airfoil)
     */
    AirfoilParameterCalculator m_calculator;

    /**
     * @brief m_transformer provides functionalities to transform points or
     *        pointlists
     */
    GeometryTransformation m_transformer;


};

#endif // NASASRSTACKINGSTRATEGY_H
