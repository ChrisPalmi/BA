#include "abstractexporter.h"

AbstractExporter::AbstractExporter()
{

}

bool AbstractExporter::successfulExport() const
{
    return m_successfulExport;
}

void AbstractExporter::setSuccessfulExport(bool successfulExport)
{
    m_successfulExport = successfulExport;
}
