#ifndef ABSTRACTFAEDELSTRATEGY_H
#define ABSTRACTFAEDELSTRATEGY_H

#include "propeller.h"

#include <QList>
#include <QVector3D>


/**
 * @brief The AbstractFaedelStrategy class provides functionalities to stack
 *        airfoils of a propeller along radial axis (Abstract class).
 */
class AbstractFaedelStrategy
{
public:
    /**
     * @brief AbstractFaedelStrategy constructor
     */
    AbstractFaedelStrategy();

    /**
     * @brief ~AbstractFaedelStrategy destructor
     */
    virtual ~AbstractFaedelStrategy() {}

    /**
     * @brief faedelProfiles stacks airfoils along radial axis
     * @param profiles (list of 2D airfoils(ordered point lists))
     * @return list of stacked airfoils(ordered point lists)
     */
    virtual QList<QList<QVector3D>> faedelProfiles
    (const QList<QList<QVector3D>> &profiles) = 0;
};

#endif // ABSTRACTFAEDELSTRATEGY_H
