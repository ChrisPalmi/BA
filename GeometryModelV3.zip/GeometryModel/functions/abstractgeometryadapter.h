#ifndef ABSTRACTGEOMETRYADAPTER_H
#define ABSTRACTGEOMETRYADAPTER_H

/**
 * @brief The AbstractGeometryAdapter class provides functionalities to adapt a
 *        the geometry of a PropellerBladeSkinGeometry object into geometrical
 *        information which is needed to create the skin of a propeller blade
 *        (Abstract class).
 */
class AbstractGeometryAdapter
{
public:
    /**
     * @brief AbstractGeometryAdapter contructor
     */
    AbstractGeometryAdapter();

    /**
     * @brief ~AbstractGeometryAdapter destructor
     */
    ~AbstractGeometryAdapter() {}
};

#endif // ABSTRACTGEOMETRYADAPTER_H
