#ifndef NACALXVGEOMETRYBUILDER_H
#define NACALXVGEOMETRYBUILDER_H

#include <QList>
#include <QPointF>

class NACALXVGeometryBuilder
{
public:

    /**
     * @brief NACALXVGeometryBuilder constructor
     */
    NACALXVGeometryBuilder();

    /**
     * @brief ~NACALXVGeometryBuilder destructor
     */
    ~NACALXVGeometryBuilder();

    /**
     * @brief buildGeometry creates geometry of normalized naca 65/CA series
     *                      (chord length = 1)
     * @param cld (Design Lift Coefficient)
     * @param maxThicknessPC (maximum thickness in Percent)
     * @param pointsPerSide (number of points which describe pressure or
     *                       suction side of profile)
     * @return list of points - 2D profile of naca 65/CA series
     */
    QList<QPointF> buildGeometry(double cld, double maxThicknessPC,
                                 int pointsPerSide);

    /**
     * @brief buildGeometryNoCamber creates geometry with no camber line
     *                               of normalized naca 65/CA series
     *                               (chord length = 1)
     * @param maxThicknessPC (maximum thickness in Percent)
     * @return list of points - 2D profile with no camber line of
     *                          naca 65/CA series
     */
    QList<QPointF> buildGeometryNoCamber(double maxThicknessPC);

    /**
     * @brief buildGeometryNoCamber creates geometry with no camber line
     *                               of normalized naca 65/CA series used by
     *                               the srII propeller (chord length = 1)
     * @param rad (non dimensional radius r/R of srII)
     * @param thicknessRatioPath (path of digitalized data t/b - thickness to
     *                            chord ratio)
     * @return list of points - 2D profile with no camber line of
     *                          naca 65/CA series
     */
    QList<QPointF> buildGeometryNoCamber(double rad,
                                          QString thicknessRatioPath);

    /**
     * @brief buildCamberLineNNormals creates the camber line and its normals
     *                                 of a naca 65/CA profile(chord length = 1)
     * @param cld (Design Lift Coefficient)
     * @param numberOfPoints (number of points which describe camber line)
     * @return 2D vector with 2 contents -
     *         First content (vector at 0) - camber line
     *         Second Content (vector at 1) - normals of camber line
     */
    QVector<QVector<QPointF>> buildCamberLineNNormals(double cld,
                                                       int numberOfPoints);

    /**
     * @brief getCircArcCentralAngle returns the central angle in dependance of
     *                              the Design Lift Coefficient which is
     *                              necessary to create the camber line
     * @param cld (Design Lift Coefficient)
     * @return central angle in degrees
     */
    double getCircArcCentralAngle(double cld);

    /**
     * @brief basicAirfoil returns the basic airfoil of naca 65/CA series
     * @return basic airfoil of naca 65/CA series
     */
    QList<QPointF> basicAirfoil() const;

    /**
     * @brief basicLEradius returns the leading edge radius of basic naca 65/CA
     *                      airfoil
     * @return leading edge radius in degrees
     */
    double basicLEradius() const;

    /**
     * @brief createAirfoilExperimentFile creates an experiment input file for
     *        PROPSTER of the naca 65/CA series
     * @param cld (Design Lift Coefficient)
     * @param maxThicknessPC (maximum thickness in percent)
     * @param pointsPerSide (number of points per side -
     *                       pressure and suction side)
     * @param filepath (path where file should be created)
     * @return true if file was created successfully
     */
    bool createAirfoilExperimentFile(double cld, double maxThicknessPC,
                                     int pointsPerSide, QString filepath);

    /**
     * @brief createAirfoilFile creates a file where the geometry of a naca
     *         65/CA profile is provided
     * @param cld (Design Lift Coefficient)
     * @param maxThicknessPC (maximum thickness in percent)
     * @param pointsPerSide (number of points per side -
     *                       pressure and suction side)
     * @param filepath (path where file should be created)
     * @return true if file was created successfully
     */
    bool createAirfoilFile(double cld, double maxThicknessPC, int pointsPerSide,
                           QString filepath);
private:

    /**
     * @brief setUpBasicAirfoil sets up member variable m_basicAirfoil
     * @return basic airfoil of naca 65/CA series
     */
    QList<QPointF> setUpBasicAirfoil();

    QList<QPointF> m_basicAirfoil;
    double m_basicLEradius;


};

#endif // NACALXVGEOMETRYBUILDER_H
