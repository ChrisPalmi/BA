#ifndef NACAXVIGEOMETRYBUILDER_H
#define NACAXVIGEOMETRYBUILDER_H

#include "abstractairfoilgeometrybuilder.h"


class NACAXVIGeometryBuilder : public AbstractAirfoilGeometryBuilder
{
public:

    /**
     * @brief NACAXVIGeometryBuilder constructor
     */
    NACAXVIGeometryBuilder();

    /**
     * @brief ~NACAXVIGeometryBuilder destructor
     */
    ~NACAXVIGeometryBuilder();

    /**
     * @brief buildGeometry creates geometry of normalized naca 16 profile
     *                       (chord length = 1)
     * @param pointsPerSide (number of points for suction and pressure side)
     * @param thicknessRatio (thickness to chord ratio t/b)
     * @param cld (Design Lift Coefficient)
     * @return list of points - geometry of naca 16 series
     */
    QList<QPointF> buildGeometry(int pointsPerSide, double thicknessRatio,
                                 double cld);

    /**
     * @brief buildGeometryNoCamber creates geometry of normalized
     *                               naca 16 profile series without
     *                               a camber line
     * @param pointsPerSide (number of points for suction and pressure side)
     * @param thicknessRatio (thickness to chord ratio t/b)
     * @return geometry of naca 16 series without a camber line
     */
    QList<QPointF> buildGeometryNoCamber(int pointsPerSide,
                                         double thicknessRatio);

    /**
     * @brief thicknessDistribution creates thickness distribution of
     *                              naca 16 series
     * @param pointsPerSide (number of points for point distribution)
     * @param thicknessRatio (thickness to chord ratio t/b)
     * @return thickness distribution of naca 16 series
     */
    QList<QPointF> thicknessDistribution(int pointsPerSide,
                                         double thicknessRatio);

    /**
     * @brief camberLine creates the camber line of a naca 16 series profile
     * @param numberOfPoints (number of points which describe camber line)
     * @param cld (Design Lift Coefficient)
     * @return camber line of naca 16 profile
     */
    QList<QPointF> camberLine(int numberOfPoints, double cld);

    /**
     * @brief derivativesOfCamberLine creates the derivatives of camber line
     *                                of a naca 16 series profile which is
     *                                necessary to create a naca 16 profile with
     *                                a camber line
     * @param numberOfPoints !!!Should be equal to numberOfPoints in function
     *                          camberLine(number of points which describe
     *                                     camber line)!!!
     * @param cld (Design Lift Coefficient)
     * @return derivatives of camber line of naca 16 profile
     */
    QList<QPointF> derivativesOfCamberLine(int numberOfPoints, double cld);

    /**
     * @brief getLeadingEdgeRadius returns leading edge radius of naca 16
     *                             profile
     * @param thicknessRatio (thickness to chord ratio t/b)
     * @return leading edge radius of naca 16 profile in degrees
     */
    double getLeadingEdgeRadius(double thicknessRatio);

    /**
     * @brief createAirfoilExperimentFile creates an experiment input file for
     *        POPSTER of the naca 16 series
     * @param cld (Design Lift Coefficient)
     * @param thicknessRatio (thickness to chord ratio t/b)
     * @param pointsPerSide (number of points per side -
     *                       pressure and suction side)
     * @param diameter (in meters)
     * @param filepath (path where file should be created)
     * @return true if file was created successfully
     */
    bool createAirfoilExperimentFile(double cld, double thicknessRatio,
                                     int pointsPerSide, double diameter,
                                     QString filepath);

    /**
     * @brief createAirfoilFile creates a file where the geometry of a naca 16
     *        profile is provided
     * @param cld (Design Lift Coefficient)
     * @param thicknessRatio (thickness to chord ratio t/b)
     * @param pointsPerSide (number of points per side -
     *                       pressure and suction side)
     * @param filepath (path where file should be created)
     * @return true if file was created successfully
     */
    bool createAirfoilFile(double cld, double thicknessRatio,
                           int pointsPerSide, QString filepath);

};

#endif // NACAXVIGEOMETRYBUILDER_H
