#ifndef PROFILETRANSFORMATION_H
#define PROFILETRANSFORMATION_H

#include <QList>
#include <QVector3D>

class ProfileTransformation
{
public:
    ProfileTransformation();

    ~ProfileTransformation();

    QList<QVector3D> resizeProfile(const QList<QVector3D> &profile,
                                   const double scalingFactor);

    QList<QList<QVector3D>> resizeMultipleProfiles
    (const QList<QList<QVector3D>> &profiles,
     const QList<double> scalingFactorList);

    QVector3D rotatePnt(const QVector3D &pnt, const double angleDeg);

    QList<QVector3D> rotateProfile(const QList<QVector3D> &profile,
                                   const double angleDeg);

    QList<QList<QVector3D>> rotateMultipleProfiles
    (const QList<QList<QVector3D>> &profiles, const QList<double> angleDegList);

    QVector3D locatePnt(const QVector3D &pnt, const QVector3D &directionVect);

    QList<QVector3D> locateProfile(const QList<QVector3D> &profile,
                                   const QVector3D &directionVect);

    QList<QList<QVector3D>> locateMultipleProfiles
    (const QList<QList<QVector3D>> &profiles,
     const QList<QVector3D> &directionVectList);




};

#endif //PROFILETRANSFORMATION_H
