#include "propellerbladeskingeometrybuilder.h"
#include <QFile>

PropellerBladeSkinGeometryBuilder::PropellerBladeSkinGeometryBuilder()
{

}

PropellerBladeSkinGeometryBuilder::~PropellerBladeSkinGeometryBuilder()
{

}

QList<QList<QVector3D> > PropellerBladeSkinGeometryBuilder::
buildGeometry(const Propeller *propeller,
              AbstractFaedelStrategy &faedelStrategy)
{
    //propeller design parameters
    double radius = propeller->radius() * 1000.0;
    Blade *blade = propeller->blade();


    //get profile geometries and further design parameters

    QList<QList<QVector3D>> allProfiles;
    allProfiles.clear();

    for(int profileNumb = 0; profileNumb < blade->stationNonRadii().size();
        profileNumb++)
    {
        Station *station =
                blade->station(blade->stationNonRadii().at(profileNumb));

        double radi = station->nonRadius() * radius;

        QVector<QPointF> geom =
                station->airfoil()->airfoilGeometry()->geometry();

        QList<QVector3D> profileGeometry;

        for(int geomAt = 0; geomAt < geom.size(); geomAt++)
        {
            QVector3D pnt(geom[geomAt].x(), geom[geomAt].y(), radi);

            profileGeometry.append(pnt);
        }

        double chordlength = station->chord() * 1000.0;

        profileGeometry = m_transformer.resizeProfile(profileGeometry,
                                                      chordlength);

        profileGeometry = m_transformer.rotateProfile(profileGeometry,
                                                      station->bladeAngleDeg());

        allProfiles.append(profileGeometry);
    }


    QList<QList<QVector3D>> finalGeometry =
           faedelStrategy.faedelProfiles(allProfiles);

    return finalGeometry;

}

PropellerBladeSkinGeometry PropellerBladeSkinGeometryBuilder::
buildPropellerBladeSkinGeometry(const Propeller* propeller,
                                AbstractFaedelStrategy& faedelStrategy)
{
    QList<QList<QVector3D>> geometry = buildGeometry(propeller, faedelStrategy);
    PropellerBladeSkinGeometry skinGeometry(geometry);
    return skinGeometry;
}


bool PropellerBladeSkinGeometryBuilder::
outputSTLII(QString filepath, QList<QVector3D> station)
{
    QString filename = filepath + ".stl";
    QFile aFile(filename);

    if (aFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&aFile);

        //list with points of station(stationNumb)

        //xCoors
        for (int pointNumb = 0; pointNumb < station.size() - 1; pointNumb++)
        {
            QVector3D pointP = station.at(pointNumb);

            out << pointP.x() << ", ";
        }

        //after last point new line for yCoors
        QVector3D pointPP = station.at(station.size() - 1);

        out << pointPP.x() << "\n";


        //yCoors
        for (int pointNum = 0; pointNum < station.size() - 1; pointNum++)
        {
            QVector3D pointA = station.at(pointNum);
            out << pointA.y() << ", ";
        }

        QVector3D pointAA = station.at(station.size() - 1);

        out << pointAA.y() << "\n";

    }

    else
    {
        qDebug() << "ERROR: File could not be created";
        return false;
    }

    return true;
}























