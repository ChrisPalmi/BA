#ifndef ABSTRACTPROPELLERGEOMETRYBUILDER_H
#define ABSTRACTPROPELLERGEOMETRYBUILDER_H

#include <QList>
#include <QVector3D>

/**
 * @brief The AbstractPropellerGeometryBuilder class provides functionalities to
 *        create geometries of a propeller (Abstract class).
 */
class AbstractPropellerGeometryBuilder
{
public:
    /**
     * @brief AbstractPropellerGeometryBuilder constructor
     */
    AbstractPropellerGeometryBuilder();

    /**
     * @brief ~AbstractPropellerGeometryBuilder destructor
     */
    ~AbstractPropellerGeometryBuilder() {}

//    virtual QList<QList<QVector3D>> buildGeometry() = 0;
};

#endif // ABSTRACTPROPELLERGEOMETRYBUILDER_H
