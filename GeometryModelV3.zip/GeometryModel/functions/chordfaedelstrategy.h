#ifndef CHORDFAEDELSTRATEGY_H
#define CHORDFAEDELSTRATEGY_H

#include "abstractfaedelstrategy.h"

class ChordFaedelStrategy : public AbstractFaedelStrategy
{
public:
    ChordFaedelStrategy();

//    ChordFaedelStrategy(double faedelAt);

    ~ChordFaedelStrategy();

//    QList<QList<QVector3D>> faedelProfiles
//    (const QList<QList<QVector3D>> &profiles);


//    double faedelAt() const;
//    void setFaedelAt(double faedelAt);

private:

    double m_faedelAt;

};

#endif // CHORDFAEDELSTRATEGY_H
