#ifndef SWEEPLINEFAEDELSTRATEGY_H
#define SWEEPLINEFAEDELSTRATEGY_H

#include "abstractfaedelstrategy.h"
#include "propeller.h"
#include "designparametercsvfilereader.h"
#include "profiletransformation.h"
#include "airfoilparametercalculator.h"

class SweepLineFaedelStrategy : public AbstractFaedelStrategy
{
public:
    SweepLineFaedelStrategy();

    SweepLineFaedelStrategy(QList<QPointF> sweepLine);

    ~SweepLineFaedelStrategy();

    QList<QList<QVector3D>> faedelProfiles
    (const QList<QList<QVector3D>> &profiles);

    QList<QPointF> sweepLine() const;
    void setSweepLine(const QList<QPointF>& sweepLine);
    bool sweepLineSet() const;

    double calculateSweep(double radi);


private:

    QList<QPointF> m_sweepLine;
    bool m_sweepLineSet;
    void setSweepLineSet(bool sweepLineSet);

    AirfoilParameterCalculator m_calculator;
    ProfileTransformation m_transformer;






};

#endif // SWEEPLINEFAEDELSTRATEGY_H
