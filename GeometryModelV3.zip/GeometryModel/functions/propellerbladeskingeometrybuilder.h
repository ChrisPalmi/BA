#ifndef PROPELLERBLADESKINGEOMETRYBUILDER_H
#define PROPELLERBLADESKINGEOMETRYBUILDER_H

#include "abstractpropellergeometrybuilder.h"
#include "nasasrfaedelstrategy.h"
#include "profiletransformation.h"
#include "sweeplinebuilder.h"
#include "propellerbladeskingeometry.h"

#include "propeller.h"


class PropellerBladeSkinGeometryBuilder :
        public AbstractPropellerGeometryBuilder
{
public:
    PropellerBladeSkinGeometryBuilder();

    ~PropellerBladeSkinGeometryBuilder();

    QList<QList<QVector3D>> buildGeometry(const Propeller *propeller,
                                          AbstractFaedelStrategy
                                          &faedelStrategy);

    PropellerBladeSkinGeometry
    buildPropellerBladeSkinGeometry(const Propeller *propeller,
                                    AbstractFaedelStrategy &faedelStrategy);



private:

    ProfileTransformation m_transformer;



    bool outputSTLII(QString filepath, QList<QVector3D> station);
};

#endif // PROPELLERBLADESKINGEOMETRYBUILDER_H
