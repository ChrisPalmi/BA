#include "abstractdesignparameterfilereader.h"

AbstractDesignParameterFileReader::AbstractDesignParameterFileReader()
{

}
