#ifndef AIRFOILPARAMETERCALCULATOR_H
#define AIRFOILPARAMETERCALCULATOR_H

#include <QList>
#include <QVector3D>

class AirfoilParameterCalculator
{
public:
    AirfoilParameterCalculator();

    ~AirfoilParameterCalculator();

    double calculateChordLength(const QList<QVector3D>& airfoil);

    double calculateBladeAngleDeg(const QList<QVector3D>& airfoil);
};

#endif // AIRFOILPARAMETERCALCULATOR_H
