#ifndef COGFAEDELSTRATEGY_H
#define COGFAEDELSTRATEGY_H

#include "abstractfaedelstrategy.h"

class COGFaedelStrategy : public AbstractFaedelStrategy
{
public:
    COGFaedelStrategy();

    ~COGFaedelStrategy();

//    QList<QList<QVector3D>> faedelProfiles();


private:

//    QVector3D calcCOG(QList<QVector3D> &profile);

};

#endif // COGFAEDELSTRATEGY_H
