#ifndef NASASRFAEDELSTRATEGY_H
#define NASASRFAEDELSTRATEGY_H

#include "sweeplinefaedelstrategy.h"
#include "designparametercsvfilereader.h"
#include "profiletransformation.h"
#include "airfoilparametercalculator.h"

class NASASRFaedelStrategy : public AbstractFaedelStrategy
{
public:

    /**
     * @brief NASASRFaedelStrategy constructor
     */
    NASASRFaedelStrategy();

    /**
     * @brief NASASRFaedelStrategy constructor
     * @param sweepLine ordered point list of sweep line from hub to tip
     * @param propeller - object of the propeller which should be stacked
     */
    NASASRFaedelStrategy(QList<QPointF> sweepLine);

    NASASRFaedelStrategy(Propeller* propeller);

    /**
     * @brief ~NASASRFaedelStrategy destructor
     */
    ~NASASRFaedelStrategy();

    virtual QList<QList<QVector3D>>faedelProfiles
    (const QList<QList<QVector3D> > &profiles);

    QList<QPointF> sweepLine() const;
    void setSweepLine(const QList<QPointF>& sweepLine);
    bool sweepLineSet() const;

    double calculateSweep(double radi);


private:

    QList<QPointF> m_sweepLine;
    bool m_sweepLineSet;
    void setSweepLineSet(bool sweepLineSet);

    AirfoilParameterCalculator m_calculator;
    ProfileTransformation m_transformer;


};

#endif // NASASRFAEDELSTRATEGY_H
