#ifndef ABSTRACTPROPELLERGEOMETRY_H
#define ABSTRACTPROPELLERGEOMETRY_H

#include <QList>
#include <QVector3D>

class AbstractPropellerGeometry
{
public:
    AbstractPropellerGeometry();

    ~AbstractPropellerGeometry() {}

    QList<QList<QVector3D> > geometry() const;
    void setGeometry(const QList<QList<QVector3D> >& geometry);

    bool geometrySet() const;


protected:

    QList<QList<QVector3D>> m_geometry;

    bool m_geometrySet;
    void setGeometrySet(bool geometrySet);


};

#endif // ABSTRACTPROPELLERGEOMETRY_H
