#include <QCoreApplication>

#include "propeller.h"
#include "xmlreader.h"

#include "gtest.h"


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    XMLReader reader;
    Propeller *srII;

    srII = reader.loadPropeller
           ("D:\\devel\\projects\\propster\\Output\\Propeller_SRII.xml");

    qDebug() << srII->name();
    qDebug() << srII->blade()->station(srII->blade()->stationNonRadii().at(0))
                ->airfoil()->airfoilGeometry()->geometry();

    qDebug() << "Finished!";
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();









}
