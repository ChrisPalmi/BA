#include "abstractpropellergeometry.h"

AbstractPropellerGeometry::AbstractPropellerGeometry()
{

}
