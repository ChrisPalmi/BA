#ifndef ABSTRACTPROPELLERGEOMETRY_H
#define ABSTRACTPROPELLERGEOMETRY_H

#include <QList>
#include <QVector3D>

class AbstractPropellerGeometry
{
public:
    AbstractPropellerGeometry();

    ~AbstractPropellerGeometry() {}

protected:

    QList<QList<QVector3D>> m_geometry;


};

#endif // ABSTRACTPROPELLERGEOMETRY_H
