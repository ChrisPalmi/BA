#ifndef PROPELLERBLADESKINGEOMETRY_H
#define PROPELLERBLADESKINGEOMETRY_H

#include "abstractpropellergeometry.h"

class PropellerBladeSkinGeometry : public AbstractPropellerGeometry
{
public:
    PropellerBladeSkinGeometry();

    ~PropellerBladeSkinGeometry();


};

#endif // PROPELLERBLADESKINGEOMETRY_H
