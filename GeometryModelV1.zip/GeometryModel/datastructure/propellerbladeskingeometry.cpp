#include "propellerbladeskingeometry.h"

PropellerBladeSkinGeometry::PropellerBladeSkinGeometry()
{

}
