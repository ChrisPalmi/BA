#include "profiletransformationstrategy.h"

#include "gtest.h"

#include <QDebug>

class test_ProfileTransformationStrategy : public ::testing::Test
{

protected:

    virtual void SetUp()
    {
        pI.setX(0.0);
        pI.setY(2.5);
        pI.setZ(0.0);

        pII.setX(-1.0);
        pII.setY(0.0);
        pII.setZ(0.5);

        pIII.setX(1.0);
        pIII.setY(1.0);
        pIII.setZ(0.0);

        pIV.setX(0.0);
        pIV.setY(1.0);
        pIV.setZ(0.0);

        //--------------------------

        dirVect.setX(1.0);
        dirVect.setY(-1.0);
        dirVect.setZ(0.0);

        testprofile.append(pI);
        testprofile.append(pII);

        testprofileII.append(pIII);
        testprofileII.append(pIV);

        profiles.append(testprofile);
        profiles.append(testprofileII);

    }

    virtual void TearDown()
    {

    }


    QVector3D pI;
    QVector3D pII;
    QVector3D pIII;
    QVector3D pIV;

    QVector3D dirVect;

    QList<QVector3D> testprofile;
    QList<QVector3D> testprofileII;

    QList<QList<QVector3D>> profiles;

    ProfileTransformationStrategy transformer;



};

TEST_F(test_ProfileTransformationStrategy, resizeProfileTest)
{
    QList<QVector3D> testprof;

    //positive scalation < 1
    testprof = transformer.resizeProfile(testprofile, 2.0);
    ASSERT_DOUBLE_EQ(0.0, testprof[0].x());
    ASSERT_DOUBLE_EQ(5.0, testprof[0].y());
    ASSERT_DOUBLE_EQ(0.0, testprof[0].z());
    ASSERT_DOUBLE_EQ(-2.0, testprof[1].x());
    ASSERT_DOUBLE_EQ(0.0, testprof[1].y());
    ASSERT_DOUBLE_EQ(0.5, testprof[1].z());

    //positive scalation > 1
    testprof = transformer.resizeProfile(testprofile, 0.5);
    ASSERT_DOUBLE_EQ(0.0, testprof[0].x());
    ASSERT_DOUBLE_EQ(1.25, testprof[0].y());
    ASSERT_DOUBLE_EQ(0.0, testprof[0].z());
    ASSERT_DOUBLE_EQ(-0.5, testprof[1].x());
    ASSERT_DOUBLE_EQ(0.0, testprof[1].y());
    ASSERT_DOUBLE_EQ(0.5, testprof[1].z());

    //negative scalation < 1
    testprof = transformer.resizeProfile(testprofile, -2.0);
    ASSERT_DOUBLE_EQ(0.0, testprof[0].x());
    ASSERT_DOUBLE_EQ(-5.0, testprof[0].y());
    ASSERT_DOUBLE_EQ(0.0, testprof[0].z());
    ASSERT_DOUBLE_EQ(2.0, testprof[1].x());
    ASSERT_DOUBLE_EQ(0.0, testprof[1].y());
    ASSERT_DOUBLE_EQ(0.5, testprof[1].z());

    //negative scalation > 1
    testprof = transformer.resizeProfile(testprofile, -0.5);
    ASSERT_DOUBLE_EQ(0.0, testprof[0].x());
    ASSERT_DOUBLE_EQ(-1.25, testprof[0].y());
    ASSERT_DOUBLE_EQ(0.0, testprof[0].z());
    ASSERT_DOUBLE_EQ(0.5, testprof[1].x());
    ASSERT_DOUBLE_EQ(0.0, testprof[1].y());
    ASSERT_DOUBLE_EQ(0.5, testprof[1].z());

    //scalation with 1
    testprof = transformer.resizeProfile(testprofile, 1.0);
    ASSERT_DOUBLE_EQ(0.0, testprof[0].x());
    ASSERT_DOUBLE_EQ(2.5, testprof[0].y());
    ASSERT_DOUBLE_EQ(0.0, testprof[0].z());
    ASSERT_DOUBLE_EQ(-1.0, testprof[1].x());
    ASSERT_DOUBLE_EQ(0.0, testprof[1].y());
    ASSERT_DOUBLE_EQ(0.5, testprof[1].z());


    //scalation with zero
    testprof = transformer.resizeProfile(testprofile, 0.0);
    ASSERT_DOUBLE_EQ(0.0, testprof[0].x());
    ASSERT_DOUBLE_EQ(0.0, testprof[0].y());
    ASSERT_DOUBLE_EQ(0.0, testprof[0].z());
    ASSERT_DOUBLE_EQ(0.0, testprof[1].x());
    ASSERT_DOUBLE_EQ(0.0, testprof[1].y());
    ASSERT_DOUBLE_EQ(0.5, testprof[1].z());

}

TEST_F(test_ProfileTransformationStrategy, resizeMultipleProfilesTest)
{
    QList<double> scalingFactors;
    scalingFactors.append(2.0);
    scalingFactors.append(-3.0);

    QList<QList<QVector3D>> prof;

    prof = transformer.resizeMultipleProfiles(profiles, scalingFactors);
    ASSERT_DOUBLE_EQ(0.0, prof[0][0].x());
    ASSERT_DOUBLE_EQ(5.0, prof[0][0].y());
    ASSERT_DOUBLE_EQ(-2.0, prof[0][1].x());
    ASSERT_DOUBLE_EQ(0.0, prof[0][1].y());
    ASSERT_DOUBLE_EQ(-3.0, prof[1][0].x());
    ASSERT_DOUBLE_EQ(-3.0, prof[1][0].y());
    ASSERT_DOUBLE_EQ(0.0, prof[1][1].x());
    ASSERT_DOUBLE_EQ(-3.0, prof[1][1].y());

}

TEST_F(test_ProfileTransformationStrategy, rotatePntTest)
{
    QVector3D testPnt;

    //positive rotation
    testPnt = transformer.rotatePnt(pI, 90.0);
    ASSERT_NEAR(2.5, testPnt.x(), 0.00001);
    ASSERT_NEAR(0.0, testPnt.y(), 0.00001);

    //negative rotation
    testPnt = transformer.rotatePnt(pI, -90.0);
    ASSERT_NEAR(-2.5, testPnt.x(), 0.00001);
    ASSERT_NEAR(0.0, testPnt.y(), 0.00001);

    //no rotation
    testPnt = transformer.rotatePnt(pI, 0.0);
    ASSERT_NEAR(0.0, testPnt.x(), 0.00001);
    ASSERT_NEAR(2.5, testPnt.y(), 0.00001);

    //positive rotation > 360 degrees
    testPnt = transformer.rotatePnt(pI, 450.0);
    ASSERT_NEAR(2.5, testPnt.x(), 0.00001);
    ASSERT_NEAR(0.0, testPnt.y(), 0.00001);

    //negative rotation > 360 degrees
    testPnt = transformer.rotatePnt(pI, -450.0);
    ASSERT_NEAR(-2.5, testPnt.x(), 0.00001);
    ASSERT_NEAR(0.0, testPnt.y(), 0.00001);
}

TEST_F(test_ProfileTransformationStrategy, rotateProfileTest)
{
    QList<QVector3D> testprof;

    //positive rotation
    testprof = transformer.rotateProfile(testprofileII, 90);
    ASSERT_NEAR(1.0, testprof[0].x(), 0.00001);
    ASSERT_NEAR(-1.0, testprof[0].y(), 0.00001);
    ASSERT_NEAR(1.0, testprof[1].x(), 0.00001);
    ASSERT_NEAR(0.0, testprof[1].y(), 0.00001);

    //negative rotation
    testprof = transformer.rotateProfile(testprofileII, -90);
    ASSERT_NEAR(-1.0, testprof[0].x(), 0.00001);
    ASSERT_NEAR(1.0, testprof[0].y(), 0.00001);
    ASSERT_NEAR(-1.0, testprof[1].x(), 0.00001);
    ASSERT_NEAR(0.0, testprof[1].y(), 0.00001);

    //no rotation
    testprof = transformer.rotateProfile(testprofileII, 0);
    ASSERT_NEAR(1.0, testprof[0].x(), 0.00001);
    ASSERT_NEAR(1.0, testprof[0].y(), 0.00001);
    ASSERT_NEAR(0.0, testprof[1].x(), 0.00001);
    ASSERT_NEAR(1.0, testprof[1].y(), 0.00001);

    //positive rotation > 360 degrees
    testprof = transformer.rotateProfile(testprofileII, 450);
    ASSERT_NEAR(1.0, testprof[0].x(), 0.00001);
    ASSERT_NEAR(-1.0, testprof[0].y(), 0.00001);
    ASSERT_NEAR(1.0, testprof[1].x(), 0.00001);
    ASSERT_NEAR(0.0, testprof[1].y(), 0.00001);

    //negative rotation > 360 degrees
    testprof = transformer.rotateProfile(testprofileII, -450);
    ASSERT_NEAR(-1.0, testprof[0].x(), 0.00001);
    ASSERT_NEAR(1.0, testprof[0].y(), 0.00001);
    ASSERT_NEAR(-1.0, testprof[1].x(), 0.00001);
    ASSERT_NEAR(0.0, testprof[1].y(), 0.00001);

}

TEST_F(test_ProfileTransformationStrategy, rotateMultipleProfilesTest)
{
    QList<double> angleList;
    angleList.clear();
    angleList.append(90);
    angleList.append(0);

    QList<QList<QVector3D>> prof;

    //positive rotation and no rotation
    prof = transformer.rotateMultipleProfiles(profiles, angleList);
    ASSERT_NEAR(2.5, prof[0][0].x(), 0.00001);
    ASSERT_NEAR(0.0, prof[0][0].y(), 0.00001);
    ASSERT_NEAR(0.0, prof[0][1].x(), 0.00001);
    ASSERT_NEAR(1.0, prof[0][1].y(), 0.00001);
    ASSERT_NEAR(1.0, prof[1][0].x(), 0.00001);
    ASSERT_NEAR(1.0, prof[1][0].y(), 0.00001);
    ASSERT_NEAR(0.0, prof[1][1].x(), 0.00001);
    ASSERT_NEAR(1.0, prof[1][1].y(), 0.00001);

    angleList.clear();
    angleList.append(-90);
    angleList.append(0);

    //negative rotation and no rotation
    prof = transformer.rotateMultipleProfiles(profiles, angleList);
    ASSERT_NEAR(-2.5, prof[0][0].x(), 0.00001);
    ASSERT_NEAR(0.0, prof[0][0].y(), 0.00001);
    ASSERT_NEAR(0.0, prof[0][1].x(), 0.00001);
    ASSERT_NEAR(-1.0, prof[0][1].y(), 0.00001);
    ASSERT_NEAR(1.0, prof[1][0].x(), 0.00001);
    ASSERT_NEAR(1.0, prof[1][0].y(), 0.00001);
    ASSERT_NEAR(0.0, prof[1][1].x(), 0.00001);
    ASSERT_NEAR(1.0, prof[1][1].y(), 0.00001);

    angleList.clear();
    angleList.append(450);
    angleList.append(-450);

    //positive an negative rotation > 360 degrees
    prof = transformer.rotateMultipleProfiles(profiles, angleList);
    ASSERT_NEAR(2.5, prof[0][0].x(), 0.00001);
    ASSERT_NEAR(0.0, prof[0][0].y(), 0.00001);
    ASSERT_NEAR(0.0, prof[0][1].x(), 0.00001);
    ASSERT_NEAR(1.0, prof[0][1].y(), 0.00001);
    ASSERT_NEAR(-1.0, prof[1][0].x(), 0.00001);
    ASSERT_NEAR(1.0, prof[1][0].y(), 0.00001);
    ASSERT_NEAR(-1.0, prof[1][1].x(), 0.00001);
    ASSERT_NEAR(0.0, prof[1][1].y(), 0.00001);
}

TEST_F(test_ProfileTransformationStrategy, locatePntTest)
{
    QVector3D pOne;

    pOne = transformer.locatePnt(pI, dirVect);
    ASSERT_NEAR(1.0, pOne.x(), 0.00001);
    ASSERT_NEAR(1.5, pOne.y(), 0.00001);
    ASSERT_NEAR(0.0, pOne.z(), 0.00001);
}

TEST_F(test_ProfileTransformationStrategy, locateProfileTest)
{
    QList<QVector3D> testprof;

    testprof = transformer.locateProfile(testprofile, dirVect);

    ASSERT_NEAR(1.0, testprof[0].x(), 0.00001);
    ASSERT_NEAR(1.5, testprof[0].y(), 0.00001);
    ASSERT_NEAR(0.0, testprof[0].z(), 0.00001);
    ASSERT_NEAR(0.0, testprof[1].x(), 0.00001);
    ASSERT_NEAR(-1.0, testprof[1].y(), 0.00001);
    ASSERT_NEAR(0.5, testprof[1].z(), 0.00001);
}

TEST_F(test_ProfileTransformationStrategy, locateMultipleProfilesTest)
{
    QList<QList<QVector3D>> testprofiles;

    QList<QVector3D> dirVectList;
    dirVectList.append(dirVect);
    dirVectList.append(QVector3D(0.0, 0.0, 1.0));

    testprofiles = transformer.locateMultipleProfiles(profiles, dirVectList);

    ASSERT_NEAR(1.0, testprofiles[0][0].x(), 0.00001);
    ASSERT_NEAR(1.5, testprofiles[0][0].y(), 0.00001);
    ASSERT_NEAR(0.0, testprofiles[0][0].z(), 0.00001);
    ASSERT_NEAR(0.0, testprofiles[0][1].x(), 0.00001);
    ASSERT_NEAR(-1.0, testprofiles[0][1].y(), 0.00001);
    ASSERT_NEAR(0.5, testprofiles[0][1].z(), 0.00001);

    ASSERT_NEAR(1.0, testprofiles[1][0].x(), 0.00001);
    ASSERT_NEAR(1.0, testprofiles[1][0].y(), 0.00001);
    ASSERT_NEAR(1.0, testprofiles[1][0].z(), 0.00001);
    ASSERT_NEAR(0.0, testprofiles[1][1].x(), 0.00001);
    ASSERT_NEAR(1.0, testprofiles[1][1].y(), 0.00001);
    ASSERT_NEAR(1.0, testprofiles[1][1].z(), 0.00001);

}

TEST_F(test_ProfileTransformationStrategy, unequalListSize)
{
    QList<QList<QVector3D>> multipleProfiles;
    QList<double> emptyList;

    multipleProfiles = transformer.resizeMultipleProfiles(profiles, emptyList);
    ASSERT_NEAR(profiles[0][0].x(), multipleProfiles[0][0].x(), 0.00001);
    ASSERT_NEAR(profiles[0][0].y(), multipleProfiles[0][0].y(), 0.00001);
    ASSERT_NEAR(profiles[0][1].x(), multipleProfiles[0][1].x(), 0.00001);
    ASSERT_NEAR(profiles[0][1].y(), multipleProfiles[0][1].y(), 0.00001);
    ASSERT_NEAR(profiles[1][0].x(), multipleProfiles[1][0].x(), 0.00001);
    ASSERT_NEAR(profiles[1][0].y(), multipleProfiles[1][0].y(), 0.00001);
    ASSERT_NEAR(profiles[1][1].x(), multipleProfiles[1][1].x(), 0.00001);
    ASSERT_NEAR(profiles[1][1].y(), multipleProfiles[1][1].y(), 0.00001);

    QList<double> biggerList;
    biggerList.append(90.0);
    biggerList.append(99.0);
    biggerList.append(10.0);

    multipleProfiles = transformer.rotateMultipleProfiles(profiles, biggerList);
    ASSERT_NEAR(profiles[0][0].x(), multipleProfiles[0][0].x(), 0.00001);
    ASSERT_NEAR(profiles[0][0].y(), multipleProfiles[0][0].y(), 0.00001);
    ASSERT_NEAR(profiles[0][1].x(), multipleProfiles[0][1].x(), 0.00001);
    ASSERT_NEAR(profiles[0][1].y(), multipleProfiles[0][1].y(), 0.00001);
    ASSERT_NEAR(profiles[1][0].x(), multipleProfiles[1][0].x(), 0.00001);
    ASSERT_NEAR(profiles[1][0].y(), multipleProfiles[1][0].y(), 0.00001);
    ASSERT_NEAR(profiles[1][1].x(), multipleProfiles[1][1].x(), 0.00001);
    ASSERT_NEAR(profiles[1][1].y(), multipleProfiles[1][1].y(), 0.00001);

   QList<QVector3D> smallerList;
   smallerList.append(QVector3D(0.0, 0.0, 0.0));

   multipleProfiles = transformer.locateMultipleProfiles(profiles, smallerList);
   ASSERT_NEAR(profiles[0][0].x(), multipleProfiles[0][0].x(), 0.00001);
   ASSERT_NEAR(profiles[0][0].y(), multipleProfiles[0][0].y(), 0.00001);
   ASSERT_NEAR(profiles[0][1].x(), multipleProfiles[0][1].x(), 0.00001);
   ASSERT_NEAR(profiles[0][1].y(), multipleProfiles[0][1].y(), 0.00001);
   ASSERT_NEAR(profiles[1][0].x(), multipleProfiles[1][0].x(), 0.00001);
   ASSERT_NEAR(profiles[1][0].y(), multipleProfiles[1][0].y(), 0.00001);
   ASSERT_NEAR(profiles[1][1].x(), multipleProfiles[1][1].x(), 0.00001);
   ASSERT_NEAR(profiles[1][1].y(), multipleProfiles[1][1].y(), 0.00001);

}
