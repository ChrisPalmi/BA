#ifndef OPENCASCADEGEOMETRYADAPTER_H
#define OPENCASCADEGEOMETRYADAPTER_H

#include "abstractgeometryadapter.h"

class OpenCascadeGeometryAdapter
{
public:
    OpenCascadeGeometryAdapter();

    ~OpenCascadeGeometryAdapter();

//    adaptGeometry()
};

#endif // OPENCASCADEGEOMETRYADAPTER_H
