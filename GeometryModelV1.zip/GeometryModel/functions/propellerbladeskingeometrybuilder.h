#ifndef PROPELLERBLADESKINGEOMETRYBUILDER_H
#define PROPELLERBLADESKINGEOMETRYBUILDER_H

#include "abstractpropellergeometrybuilder.h"

class PropellerBladeSkinGeometryBuilder : public AbstractPropellerGeometryBuilder
{
public:
    PropellerBladeSkinGeometryBuilder();

    ~PropellerBladeSkinGeometryBuilder();

    QList<QList<QVector3D>> buildGeometry();
};

#endif // PROPELLERBLADESKINGEOMETRYBUILDER_H
