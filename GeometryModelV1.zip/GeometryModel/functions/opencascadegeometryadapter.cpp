#include "opencascadegeometryadapter.h"

OpenCascadeGeometryAdapter::OpenCascadeGeometryAdapter()
{

}
