#include "propellerbladeskinshapebuilder.h"

PropellerBladeSkinShapeBuilder::PropellerBladeSkinShapeBuilder()
{

}

PropellerBladeSkinShapeBuilder::~PropellerBladeSkinShapeBuilder()
{

}

//TopoDS_Shape PropellerBladeSkinShapeBuilder::buildShape()
//{

//}


