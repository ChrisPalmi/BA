#include "cogfaedelstrategy.h"

COGFaedelStrategy::COGFaedelStrategy()
{

}

COGFaedelStrategy::~COGFaedelStrategy()
{

}

//QList<QList<QVector3D> > COGFaedelStrategy::faedelProfiles()
//{

//}

//QVector3D COGFaedelStrategy::calcCOG(QList<QVector3D>& profile)
//{

//}
