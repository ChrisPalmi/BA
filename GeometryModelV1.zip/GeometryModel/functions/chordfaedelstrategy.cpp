#include "chordfaedelstrategy.h"

ChordFaedelStrategy::ChordFaedelStrategy()
{

}

ChordFaedelStrategy::~ChordFaedelStrategy()
{

}

//QList<QList<QVector3D> > ChordFaedelStrategy::faedelProfiles(double chordAt)
//{

//}
