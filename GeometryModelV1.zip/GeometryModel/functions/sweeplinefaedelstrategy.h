#ifndef SWEEPLINEFAEDELSTRATEGY_H
#define SWEEPLINEFAEDELSTRATEGY_H

#include "abstractfaedelstrategy.h"

class SweepLineFaedelStrategy : public AbstractFaedelStrategy
{
public:
    SweepLineFaedelStrategy();

    ~SweepLineFaedelStrategy();

//    QList<QList<QVector3D>> faedelProfiles();


private:

//    QList<QPointF> createSweepLine(QList<QPointF> sweepAngleDegList);

//    QList<QPointF> createSweepLine(QString sweepAngleDegPath,
//                                   int numberOfIterations,
//                                   double nonHubRad);

    //gtSpline createSweepLineSpline(int sweepAngleDegHub,
    //                               int sweepAngleDegTip);

//    QList<QPointF> sweepLine(QList<QPointF> sweepAngleDegList);


};

#endif // SWEEPLINEFAEDELSTRATEGY_H
