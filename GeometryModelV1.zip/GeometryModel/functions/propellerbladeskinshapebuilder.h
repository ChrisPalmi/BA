#ifndef PROPELLERBLADESKINSHAPEBUILDER_H
#define PROPELLERBLADESKINSHAPEBUILDER_H

#include "abstractpropellershapebuilder.h"

class PropellerBladeSkinShapeBuilder
{
public:
    PropellerBladeSkinShapeBuilder();

    ~PropellerBladeSkinShapeBuilder();

    TopoDS_Shape buildShape();
};

#endif // PROPELLERBLADESKINSHAPEBUILDER_H
