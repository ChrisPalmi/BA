#include "propellerbladeskingeometrybuilder.h"

PropellerBladeSkinGeometryBuilder::PropellerBladeSkinGeometryBuilder()
{

}

PropellerBladeSkinGeometryBuilder::~PropellerBladeSkinGeometryBuilder()
{

}

//QList<QList<QVector3D> > PropellerBladeSkinGeometryBuilder::buildGeometry()
//{

//}
