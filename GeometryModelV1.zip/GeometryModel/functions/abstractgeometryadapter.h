#ifndef ABSTRACTGEOMETRYADAPTER_H
#define ABSTRACTGEOMETRYADAPTER_H


class AbstractGeometryAdapter
{
public:
    AbstractGeometryAdapter();

    ~AbstractGeometryAdapter() {}
};

#endif // ABSTRACTGEOMETRYADAPTER_H
