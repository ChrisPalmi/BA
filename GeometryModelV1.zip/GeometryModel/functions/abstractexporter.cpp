#include "abstractexporter.h"

AbstractExporter::AbstractExporter()
{

}
