#ifndef ABSTRACTEXPORTER_H
#define ABSTRACTEXPORTER_H


class AbstractExporter
{
public:
    AbstractExporter();

    ~AbstractExporter() {}

    virtual bool exportFile() = 0;
};

#endif // ABSTRACTEXPORTER_H
