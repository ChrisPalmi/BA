#define _USE_MATH_DEFINES
#include <cmath>

#include "profiletransformationstrategy.h"

#include <QDebug>

ProfileTransformationStrategy::ProfileTransformationStrategy()
{

}

ProfileTransformationStrategy::~ProfileTransformationStrategy()
{

}


QList<QVector3D> ProfileTransformationStrategy::
resizeProfile(const QList<QVector3D>& profile, const double scalingFactor)
{
    QList<QVector3D> resizedProfile;
    resizedProfile.clear();

    for(int listAt = 0; listAt < profile.size(); listAt++)
    {
        QVector3D pnt(profile[listAt].x() * scalingFactor,
                      profile[listAt].y() * scalingFactor,
                      profile[listAt].z());
        resizedProfile.append(pnt);
    }

    return resizedProfile;
}

QList<QList<QVector3D> > ProfileTransformationStrategy::resizeMultipleProfiles
(const QList<QList<QVector3D> >& profiles,
 const QList<double> scalingFactorList)
{
    if(profiles.size() != scalingFactorList.size())
    {
        qDebug() << "ERROR:\nYour number of profiles is not the same than your "
                 << "number of scaling factors!\n"
                    "Unrotated profiles will be returned!";

        return profiles;
    }

    QList<QList<QVector3D>> resizedProfiles;
    resizedProfiles.clear();

    for(int profilesAt = 0; profilesAt < profiles.size(); profilesAt++)
    {
        QList<QVector3D> newProfile = resizeProfile(profiles[profilesAt],
                                             scalingFactorList[profilesAt]);
        resizedProfiles.append(newProfile);
    }

    return resizedProfiles;

}


QVector3D ProfileTransformationStrategy::rotatePnt(const QVector3D& pnt,
                                                   const double angleDeg)
{
    /*
     * 2D Position Vector
     *
     * xCoor     yCoor
     *
     * 2D Rotation matrix
     *
     * cos(beta)    -sin(beta)
     * sin(beta)     cos(beta)
     *
     */

     //blade angle degree has to be considered in clockwise rotation
     //matrix multiplication with rotation matrix for x coordinate
    double x = (pnt.x() * cos(angleDeg * (M_PI / 180.0))) +
               (pnt.y() * sin(angleDeg * (M_PI / 180.0)));

    //matrix multiplication with rotation matrix for y coordinate
    double y = (pnt.x() * - sin(angleDeg * (M_PI / 180.0))) +
               (pnt.y() * cos(angleDeg * (M_PI / 180.0)));


    QVector3D rotatedPnt(x, y, pnt.z());

    return rotatedPnt;
}


QList<QVector3D> ProfileTransformationStrategy::
rotateProfile(const QList<QVector3D>& profile, const double angleDeg)
{
    QList<QVector3D> rotatedProfile;
    rotatedProfile.clear();

    for(int profileAt = 0; profileAt < profile.size(); profileAt++)
    {
        QVector3D point = rotatePnt(profile[profileAt], angleDeg);
        rotatedProfile.append(point);
    }

    return rotatedProfile;
}

QList<QList<QVector3D> > ProfileTransformationStrategy::rotateMultipleProfiles
(const QList<QList<QVector3D> >& profiles, const QList<double> angleDegList)
{
    if(profiles.size() != angleDegList.size())
    {
        qDebug() << "ERROR:\nYour number of profiles is not the same than your "
                 << "number of angles!\n Unrotated profiles will be returned!";

        return profiles;
    }

    QList<QList<QVector3D>> rotatedProfiles;
    rotatedProfiles.clear();

    for(int profilesAt = 0; profilesAt < profiles.size(); profilesAt++)
    {
        QList<QVector3D> aProfile = rotateProfile(profiles[profilesAt],
                                             angleDegList[profilesAt]);
        rotatedProfiles.append(aProfile);
    }

    return rotatedProfiles;
}


QVector3D ProfileTransformationStrategy::locatePnt(const QVector3D& pnt,
                                          const QVector3D& directionVect)
{
    QVector3D locatedPnt(pnt.x() + directionVect.x(),
                         pnt.y() + directionVect.y(),
                         pnt.z() + directionVect.z());

    return locatedPnt;
}


QList<QVector3D> ProfileTransformationStrategy::
locateProfile(const QList<QVector3D>& profile, const QVector3D& directionVect)
{
    QList<QVector3D> locatedProfile;
    locatedProfile.clear();

    for(int listAt = 0; listAt < profile.size(); listAt++)
    {
        QVector3D point = locatePnt(profile[listAt], directionVect);
        locatedProfile.append(point);
    }

    return locatedProfile;
}

QList<QList<QVector3D> > ProfileTransformationStrategy::
locateMultipleProfiles(const QList<QList<QVector3D> >& profiles,
                       const QList<QVector3D>& directionVectList)
{
    if(profiles.size() != directionVectList.size())
    {
        qDebug() << "ERROR:\nYour number of profiles is not the same than your "
                 << "number of direction vectors!\n"
                    "Unrotated profiles will be returned!";

        return profiles;
    }

    QList<QList<QVector3D>> locatedProfiles;
    locatedProfiles.clear();

    for(int profilesAt = 0; profilesAt < profiles.size(); profilesAt++)
    {
        QList<QVector3D> aProfile = locateProfile(profiles[profilesAt],
                                             directionVectList[profilesAt]);
        locatedProfiles.append(aProfile);
    }

    return locatedProfiles;
}
