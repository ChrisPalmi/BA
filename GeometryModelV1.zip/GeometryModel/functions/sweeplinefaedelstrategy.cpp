#include "sweeplinefaedelstrategy.h"

SweepLineFaedelStrategy::SweepLineFaedelStrategy()
{

}

SweepLineFaedelStrategy::~SweepLineFaedelStrategy()
{

}

//QList<QList<QVector3D>> SweepLineFaedelStrategy::faedelProfiles()
//{

//}

//QList<QPointF> SweepLineFaedelStrategy::
//createSweepLine(QList<QPointF> sweepAngleDegList, int numberOfIterations,
//                double nonHubRad)
//{
//    GtSplineFit* sweepFitter = new GtSplineFit(3, 4, 0.001, 800);
//    sweepFitter->fit(sweepAngleDegList);
//    qDebug() << "sweep fit";
//    RootFinder finder;

//    QList<QPointF> sweepSemiChordLine;
//    sweepSemiChordLine.clear();

//    QPointF firstPoint(0.0, nonHubRad);
//    sweepSemiChordLine.append(firstPoint);

//    double iterFactor = (1.0 - nonHubRad) / (numberOfIterations - 1);
//    double lastX = 0.0;

//    for(int iterAt = 1; iterAt < numberOfIterations; iterAt++)
//    {
//        double nonRad = nonHubRad + (iterFactor * iterAt);
//        double nonRadBefore = nonHubRad + (iterFactor * (iterAt - 1));

//        auto sweepFunc = [nonRadBefore, sweepFitter](double u)
//        {
//            QPointF aPoint = sweepFitter->getCurvePoint(u);
//            double diff = nonRadBefore - aPoint.x();
//            return diff;
//        };

//        double sweepU = finder.Brent(sweepFunc, 0.0, 1.0);
//        QPointF sweepPnt = sweepFitter->getCurvePoint(sweepU);
//        double sweepAngle = sweepPnt.y();


//        if(sweepAngle <= 0.0)
//        {
//            double shift = tan(sweepAngle * (M_PI / 180.0)) * iterFactor;
//            double xCoor = lastX + shift;
//            QPointF semiChordLinePnt(xCoor, nonRad);
//            sweepSemiChordLine.append(semiChordLinePnt);

//            lastX = xCoor;
//        }

//        else
//        {
//            sweepAngle = -1.0 * sweepAngle;
//            double shift = tan(sweepAngle * (M_PI / 180.0)) * iterFactor;
//            double xCoor = lastX - shift;
//            QPointF semiChordLinePnt(xCoor, nonRad);
//            sweepSemiChordLine.append(semiChordLinePnt);

//            lastX = xCoor;
//        }
//    }

//    return sweepSemiChordLine;
//}

//QList<QPointF> SweepLineFaedelStrategy::
//createSweepLine(QString sweepAngleDegPath, int numberOfIterations,
//                double nonHubRad)
//{
//    QList<QPointF> sweepList =
//           m_inputhandler.readFile(sweepAngleDegPath);

//    return createSweepLine(sweepList, numberOfIterations, nonHubRad);

//}

