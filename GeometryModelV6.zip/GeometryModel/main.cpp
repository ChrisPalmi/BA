#include <QCoreApplication>

#include "propeller.h"
#include "xmlreader.h"
#include "gtest.h"
#include "sweeplinestackingstrategy.h"
#include "propellerbladeskingeometrybuilder.h"
#include "propellerbladeskingeometry.h"
#include "propellerbladeskinshapebuilder.h"
#include "opencascadegeometryadapter.h"
#include "TopoDS_Shape.hxx"
#include "igesexporter.h"
#include "stepexporter.h"
#include "cogstackingstrategy.h"
#include "chordstackingstrategy.h"

#include "gt_bsplinealgorithm.h"

#include "IGESControl_Writer.hxx"
#include "IGESControl_Controller.hxx"
#include "STEPControl_Controller.hxx"
#include "STEPControl_Writer.hxx"

#include <QFile>


#include "gt_splinefit.h"


bool outputSTLII(QString filepath, QList<QVector3D> station)
{
    QString filename = filepath + ".stl";
    QFile aFile(filename);

    if (aFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&aFile);

        //list with points of station(stationNumb)

        //xCoors
        for (int pointNumb = 0; pointNumb < station.size() - 1; pointNumb++)
        {
            QVector3D pointP = station.at(pointNumb);

            out << pointP.x() << ", ";
        }

        //after last point new line for yCoors
        QVector3D pointPP = station.at(station.size() - 1);

        out << pointPP.x() << "\n";


        //yCoors
        for (int pointNum = 0; pointNum < station.size() - 1; pointNum++)
        {
            QVector3D pointA = station.at(pointNum);
            out << pointA.y() << ", ";
        }

        QVector3D pointAA = station.at(station.size() - 1);

        out << pointAA.y() << "\n";

    }

    else
    {
        qDebug() << "ERROR: File could not be created";
        return false;
    }

    return true;
}

void createSTLFile(QList<QList<QVector3D> >& blade, QString filepath)
{
    QFile stlFile(filepath);
    if(stlFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&stlFile);
        out << "solid propGeometry\n";

        for(int i = 0; i < blade.size() - 1; i++)
        {
            QList<QVector3D> lowerProfile = blade.at(i);
            QList<QVector3D> upperProfile = blade.at(i + 1);



            for(int j = 0; j < lowerProfile.size(); j++)
            {
                //points of two triangles

                QVector3D pI;
                QVector3D pII;
                QVector3D pIII;
                QVector3D pIV;

                if(j == lowerProfile.size() - 1)
                {
                    pI = lowerProfile.at(j);
                    pII = lowerProfile.at(0);
                    pIII = upperProfile.at(j);
                    pIV = upperProfile.at(0);
                }

                else
                {
                    pI = lowerProfile.at(j);
                    pII = lowerProfile.at(j + 1);
                    pIII = upperProfile.at(j);
                    pIV = upperProfile.at(j + 1);
                }


                //-----------first triangle------------------------------
                //direction vectors for one triangle
                QVector3D dirVectI(pII.x() - pI.x(), pII.y() - pI.y(),
                                   pII.z() - pI.z());
                QVector3D dirVectII(pIII.x() - pI.x(), pIII.y() - pI.y(),
                                   pIII.z() - pI.z());
                //normal vector
                QVector3D normalVect;
                normalVect.setX(dirVectI.y() * dirVectII.z() -
                                dirVectI.z() * dirVectII.y());
                normalVect.setY(dirVectI.z() * dirVectII.x() -
                                dirVectI.x() * dirVectII.z());
                normalVect.setZ(dirVectI.x() * dirVectII.y() -
                                dirVectI.y() * dirVectII.x());

                out << "\tfacet normal " << normalVect.x() << " " <<
                    normalVect.y() << " " << normalVect.z() << "\n";

                out << "\t\touter loop\n";
                out << "\t\t\tvertex " << pI.x() << " " <<
                       pI.y() << " " << pI.z() << "\n";
                out << "\t\t\tvertex " << pII.x() << " " <<
                       pII.y() << " " << pII.z() << "\n";
                out << "\t\t\tvertex " << pIII.x() << " " <<
                       pIII.y() << " " << pIII.z() << "\n";
                out << "\t\tendloop\n";
                out << "\tendfacet\n";

                //-----------second triangle----------------------------

                //direction vectors for one triangle
                dirVectI.setX(pIII.x() - pII.x());
                dirVectI.setY(pIII.y() - pII.y());
                dirVectI.setZ(pIII.z() - pII.z());

                dirVectII.setX(pIV.x() - pII.x());
                dirVectII.setY(pIV.y() - pII.y());
                dirVectII.setZ(pIV.z() - pII.z());

                //normal vector
                normalVect.setX(dirVectI.y() * dirVectII.z() -
                                dirVectI.z() * dirVectII.y());
                normalVect.setY(dirVectI.z() * dirVectII.x() -
                                dirVectI.x() * dirVectII.z());
                normalVect.setZ(dirVectI.x() * dirVectII.y() -
                                dirVectI.y() * dirVectII.x());

                out << "\tfacet normal " << normalVect.x() << " " <<
                    normalVect.y() << " " << normalVect.z() << "\n";

                out << "\t\touter loop\n";
                out << "\t\t\tvertex " << pII.x() << " " <<
                       pII.y() << " " << pII.z() << "\n";
                out << "\t\t\tvertex " << pIII.x() << " " <<
                       pIII.y() << " " << pIII.z() << "\n";
                out << "\t\t\tvertex " << pIV.x() << " " <<
                       pIV.y() << " " << pIV.z() << "\n";
                out << "\t\tendloop\n";
                out << "\tendfacet\n";

            }

        }

        out << "endsolid propGeometry";

    }
    return;
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);


    XMLReader reader;
    Propeller *srIII;

    srIII = reader.loadPropeller
           ("D:\\data\\PraxisphaseVI\\ExperimentFilesPropster\\"
            "Output\\SRIII Manufacture Sweep.xml");

    SweepLineBuilder b;
    PropellerBladeSkinGeometryBuilder builder;
    NASASRStackingStrategy nasaStackingStrategy(b.buildSweepLine(srIII, 10000));
    ChordStackingStrategy chordStackingStrategy(0.98);
    COGStackingStrategy cogStackingStrategy;
    SweepLineStackingStrategy sweepLineStackingStrategy
            (b.buildSweepLine(srIII, 10000));
    PropellerBladeSkinGeometry skinGeom =
            builder.buildPropellerBladeSkinGeometry(srIII, chordStackingStrategy);

//    createSTLFile(skinGeom.geometry(),
//                  "D:/data/PraxisphaseVI/Anwendungstests/TestMatrixData/"
//                  "STLFiles/srIIIManufactureSweep_98ChordStrategy.stl");


    OpenCascadeGeometryAdapter adapter;
    QList<Handle(TColgp_HArray1OfPnt)> openCascadeGeometry =
            adapter.adaptThreeDGeometry(skinGeom.geometry());

    PropellerBladeSkinShapeBuilder builderII;

    TopoDS_Shape skinShape = builderII.buildShape(openCascadeGeometry);

    qDebug() << skinShape.IsNull();


    IGESExporter igesExporter;
    Standard_CString igesPathString = "D:/mumpitz/DRISS";
    //Standard_CString igesPathString = "D:/data/PraxisphaseVI/Anwendungstests"
                                      "/TestMatrixData/IGESFiles/"
                                      "SRIIIManufactureSweep_98chordStrategy.igs";
    igesExporter.exportFile(skinShape, igesPathString);

//    STEPExporter stepExporter;
//    Standard_CString stepPathString = "D:/data/PraxisphaseVI/Anwendungstests"
//                                      "/TestMatrixData/STEPFiles/"
//                                      "SRIIIManufactureSweep_98chordStrategy.stp";
//    stepExporter.exportFile(skinShape, stepPathString);







//    BladeBuilder bladebuilder("bladebuilder");
//    for(int j = 0; j < skinGeom.geometry().size(); j++)
//    {
//        bladebuilder.addSection(toList(skinGeom.geometry().at(j)));
//    }

//    ShapePtr skinShape = bladebuilder;

//    QMainWindow myWindow;
//    myWindow.setFixedSize(500, 750);
//    QWidget *myWidget = new QWidget();
//    View3d *myView = new View3d(myWidget);
//    Scene3d *myScene = new Scene3d();

//    myScene->setMeshAccuracy(0.0001);
//    myScene->displayShape(skinShape);
//    myScene->setShapeVisibile("skinShape", true);

//    myView->setScene(myScene);
//    myView->setBackgroundColor(Qt::white);
//    myWindow.setCentralWidget(myView);
//    myWindow.show();
//    return app.exec();









//    QList<QList<QVector3D>> prop = builder.buildGeometry(srIII);

//    createSTLFile(prop, "D:/data/PraxisphaseVI/SRII/STLFiles/"
//                  "srII.stl");

    qDebug() << "Finished!";

    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();




}
