#include "nacalxvgeometrybuilder.h"

#include "gtest.h"

#include <QVector>
#include <QPointF>
#include <QList>
#include <QString>

class test_NACALXVGeometryBuilder : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }



};

TEST_F(test_NACALXVGeometryBuilder, errorHandlingTest)
{
    //max and min of each variable:
    //-3.0 <= cld <= 3.0
    //0 < maxThicknessPC <= 100
    //PointsPerSide >= 2
    //NumberOfPoints >= 2

    NACALXVGeometryBuilder builder;

    //--------------------------
    //buildGeometry test
    //--------------------------

    //cld < -3.0
    QList<QPointF> list = builder.buildGeometry(-3.1, 20.0, 100);
    ASSERT_TRUE(list.isEmpty());

    //cld > 3.0
    list = builder.buildGeometry(3.1, 20.0, 100);
    ASSERT_TRUE(list.isEmpty());

    //negative maxThicknessPC
    list = builder.buildGeometry(0.5, -0.1, 100);
    ASSERT_TRUE(list.isEmpty());

    //maxThicknessPC > 100
    list = builder.buildGeometry(0.5, 101.0, 100);
    ASSERT_TRUE(list.isEmpty());

    //points per side < 2
    list = builder.buildGeometry(0.5, 20.0, 1);
    ASSERT_TRUE(list.isEmpty());

    //--------------------------
    //buildGeometryNoCamber test
    //--------------------------

    //negative maxThicknessPC
    list = builder.buildGeometryNoCamber(-0.1);
    ASSERT_TRUE(list.isEmpty());

    //maxThicknessPC > 100
    list = builder.buildGeometryNoCamber(101.0);
    ASSERT_TRUE(list.isEmpty());

    //----------------------------
    //buildCamberLineNNormals test
    //----------------------------

    //cld < -3.0
    QVector<QVector<QPointF>> listII =
            builder.buildCamberLineNNormals(-3.1, 100);
    ASSERT_TRUE(listII.isEmpty());

    //cld > 3.0
    listII = builder.buildCamberLineNNormals(3.1, 100);
    ASSERT_TRUE(listII.isEmpty());

    //numberOfPoints <= 2
    listII = builder.buildCamberLineNNormals(3.1, -1);
    ASSERT_TRUE(listII.isEmpty());

    //--------------------------------
    //createAirfoilExperimentFile test
    //--------------------------------

    QString bla = "bla";

    //cld < -3.0
    bool success = builder.createAirfoilExperimentFile(-3.1, 20.0, 100, bla);
    ASSERT_FALSE(success);

    //cld > 3.0
    success = builder.createAirfoilExperimentFile(3.1, 20.0, 100, bla);
    ASSERT_FALSE(success);

    //maxThicknessPC < 0.0
    success = builder.createAirfoilExperimentFile(0.5, -20.0, 100, bla);
    ASSERT_FALSE(success);

    //maxThicknessPC > 100.0
    success = builder.createAirfoilExperimentFile(0.5, 200.0, 100, bla);
    ASSERT_FALSE(success);

    //pointsPerSide < 2
    success = builder.createAirfoilExperimentFile(0.5, 20.0, 1, bla);
    ASSERT_FALSE(success);

    //--------------------------------
    //createAirfoilFile test
    //--------------------------------

    //cld < -3.0
    success = builder.createAirfoilFile(-3.1, 20.0, 100, bla);
    ASSERT_FALSE(success);

    //cld > 3.0
    success = builder.createAirfoilFile(3.1, 20.0, 100, bla);
    ASSERT_FALSE(success);

    //maxThicknessPC < 0.0
    success = builder.createAirfoilFile(0.5, -20.0, 100, bla);
    ASSERT_FALSE(success);

    //maxThicknessPC > 100.0
    success = builder.createAirfoilFile(0.5, 200.0, 100, bla);
    ASSERT_FALSE(success);

    //pointsPerSide < 2
    success = builder.createAirfoilFile(0.5, 20.0, 1, bla);
    ASSERT_FALSE(success);
}
