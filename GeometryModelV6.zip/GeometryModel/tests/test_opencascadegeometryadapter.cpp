#include "opencascadegeometryadapter.h"

#include <QDebug>

#include "gtest.h"

class test_OpenCascadeGeometryAdapter : public ::testing::Test
{
protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }


};

TEST_F(test_OpenCascadeGeometryAdapter, errorHandling)
{
    OpenCascadeGeometryAdapter adapter;

    //---------------------------
    //adaptTwoDGeometry Test
    //---------------------------

    //empty Geometry

    QList<QVector3D> emptyList;
    emptyList.clear();

    Handle(TColgp_HArray1OfPnt) array = adapter.adaptTwoDGeometry(emptyList);
    ASSERT_EQ(0, array->Value(1).X());
    ASSERT_EQ(0, array->Value(1).Y());
    ASSERT_EQ(0, array->Value(1).Z());

    //points to near to each other

    QList<QVector3D> list;
    list.clear();

    QVector3D pI(0.0, 1.0, 0.0);
    QVector3D pII(1.0, 1.0, 0.0);

    list.append(pI);
    list.append(pI);
    list.append(pII);

    array = adapter.adaptTwoDGeometry(list);
    ASSERT_EQ(0, array->Value(1).X());
    ASSERT_EQ(0, array->Value(1).Y());
    ASSERT_EQ(0, array->Value(1).Z());

    //--------------------------
    //adaptThreeDGeometry
    //--------------------------

    //empty list
    QList<QList<QVector3D>> otherEmptyList;
    otherEmptyList.clear();

    QList<Handle(TColgp_HArray1OfPnt)> otherArrayList =
            adapter.adaptThreeDGeometry(otherEmptyList);

    ASSERT_TRUE(otherArrayList.isEmpty());




}






















