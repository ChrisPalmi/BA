#include "chordstackingstrategy.h"

#include <QDebug>
#include <QList>
#include <QVector3D>

#include "gtest.h"


class test_ChordStackingStrategy : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }



};

TEST_F(test_ChordStackingStrategy, errorHandlingTest)
{
    //stack at not set
    ChordStackingStrategy strategy;
    ASSERT_FALSE(strategy.stackAtSet());

    //stack at has to be a value between 0.0 and 1.0 (r/R)
    ChordStackingStrategy strategyI(-0.2);
    ASSERT_FALSE(strategyI.stackAtSet());
    ChordStackingStrategy strategyII(1.5);
    ASSERT_FALSE(strategyII.stackAtSet());

    strategy.setStackAt(-0.2);
    ASSERT_FALSE(strategy.stackAtSet());
    strategy.setStackAt(1.5);
    ASSERT_FALSE(strategy.stackAtSet());

    //stack at set
    strategy.setStackAt(0.5);
    ASSERT_TRUE(strategy.stackAtSet());

    //empty Airfoil
    QList<QList<QVector3D>> emptyAirfoil;
    emptyAirfoil.clear();

    QList<QList<QVector3D>> newEmptyAirfoil =
            strategy.stackAirfoils(emptyAirfoil);

    ASSERT_TRUE(newEmptyAirfoil.isEmpty());

}

TEST_F(test_ChordStackingStrategy, stackAirfoilsTest)
{

    QList<QList<QVector3D>> airfoils;
    airfoils.clear();

    //trailing edges of 2 airfoils
    QVector3D pI(1.0, 0.0, 0.2);
    QVector3D pII(0.5, 0.3, 0.3);

    QList<QVector3D> listI;
    listI.clear();
    listI.append(pI);
    QList<QVector3D> listII;
    listII.clear();
    listII.append(pII);

    airfoils.append(listI);
    airfoils.append(listII);

    //50% chord
    ChordStackingStrategy s(0.5);
    QList<QList<QVector3D>> stackedAirfoils = s.stackAirfoils(airfoils);

    ASSERT_NEAR(0.5, stackedAirfoils[0][0].x(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[0][0].y(), 0.00001);
    ASSERT_NEAR(0.2, stackedAirfoils[0][0].z(), 0.00001);
    ASSERT_NEAR(0.25, stackedAirfoils[1][0].x(), 0.00001);
    ASSERT_NEAR(0.15, stackedAirfoils[1][0].y(), 0.00001);
    ASSERT_NEAR(0.3, stackedAirfoils[1][0].z(), 0.00001);

}
