#include "airfoilparametercalculator.h"
#include <QList>
#include <QVector3D>

#include "gtest.h"

class test_AirfoilParameterCalculator : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

    AirfoilParameterCalculator calculator;
};

TEST_F(test_AirfoilParameterCalculator, errorHandling)
{
    QList<QVector3D> emptyList;
    emptyList.clear();

    //calculateBladeAngleDeg should return 0.0 if list is empty
    double testVal = calculator.calculateBladeAngleDeg(emptyList);
    ASSERT_NEAR(0.0, testVal, 0.00001);

    //calculateChordLength should return 0.0 if list is empty
    testVal = calculator.calculateChordLength(emptyList);
    ASSERT_NEAR(0.0, testVal, 0.00001);

    //calculateArea should return 0.0 if list is empty
    testVal = calculator.calculateArea(emptyList);
    ASSERT_NEAR(0.0, testVal, 0.00001);

    //calculateCOG should return origin if list is empty
    QVector3D aPnt = calculator.calculateCOG(emptyList);
    ASSERT_NEAR(0.0, aPnt.x(), 0.00001);
    ASSERT_NEAR(0.0, aPnt.y(), 0.00001);
    ASSERT_NEAR(0.0, aPnt.z(), 0.00001);

    QList<QVector3D> firstPntZeroList;
    QVector3D pnt(0.0, 0.0, 0.0);
    firstPntZeroList.clear();
    firstPntZeroList.append(pnt);

    //calculateBladeAngleDeg should return 0.0 if x coor of first pnt is zero
    testVal = calculator.calculateBladeAngleDeg(firstPntZeroList);
    ASSERT_NEAR(0.0, testVal, 0.00001);

}

TEST_F(test_AirfoilParameterCalculator, calculateChordLengthTest)
{
    //calculate chordlength of airfoil from each quadrant of koordinate system
    //only first point (trailing edge) of airfoil will be considered in
    //algorithm, so only one pnt has to be appended
    QList<QVector3D> airfoil;
    airfoil.clear();

    //first quadrant
    QVector3D pnt(1.0, 1.0, 0.0);
    airfoil.append(pnt);

    double chordLength = calculator.calculateChordLength(airfoil);
    ASSERT_NEAR(sqrt(2.0), chordLength, 0.00001);

    //fourth quadrant
    airfoil.clear();
    pnt.setX(-1.0);
    airfoil.append(pnt);

    chordLength = calculator.calculateChordLength(airfoil);
    ASSERT_NEAR(sqrt(2.0), chordLength, 0.00001);

    //third quadrant
    airfoil.clear();
    pnt.setY(-1.0);
    airfoil.append(pnt);

    chordLength = calculator.calculateChordLength(airfoil);
    ASSERT_NEAR(sqrt(2.0), chordLength, 0.00001);

    //second quadrant
    airfoil.clear();
    pnt.setX(1.0);
    airfoil.append(pnt);

    chordLength = calculator.calculateChordLength(airfoil);
    ASSERT_NEAR(sqrt(2.0), chordLength, 0.00001);
}


TEST_F(test_AirfoilParameterCalculator, calculateBladeAngleDegTest)
{
    //calculate bladeangle (deg) of airfoil from each quadrant of
    //koordinate system only first point (trailing edge) of airfoil will be
    //considered in algorithm, so only one pnt has to be appended


    QList<QVector3D> airfoil;
    airfoil.clear();

    //first quadrant
    QVector3D pnt(1.0, 1.0, 0.0);
    airfoil.append(pnt);

    double baDeg = calculator.calculateBladeAngleDeg(airfoil);
    ASSERT_NEAR(45.0, baDeg, 0.00001);

    //fourth quadrant
    airfoil.clear();
    pnt.setX(-1.0);
    airfoil.append(pnt);

    baDeg = calculator.calculateBladeAngleDeg(airfoil);
    ASSERT_NEAR(135.0, baDeg, 0.00001);

    //third quadrant
    airfoil.clear();
    pnt.setY(-1.0);
    airfoil.append(pnt);

    baDeg = calculator.calculateBladeAngleDeg(airfoil);
    ASSERT_NEAR(-135.0, baDeg, 0.00001);

    //second quadrant
    airfoil.clear();
    pnt.setX(1.0);
    airfoil.append(pnt);

    baDeg = calculator.calculateBladeAngleDeg(airfoil);
    ASSERT_NEAR(-45.0, baDeg, 0.00001);

}

TEST_F(test_AirfoilParameterCalculator, calculateCOGTest)
{
    //calculate center of gravity of a square in different positions
    //first quadrant

    QList<QVector3D> square;
    square.clear();

    QVector3D pI(1.0, 1.0, 0.0);
    QVector3D pII(3.0, 1.0, 0.0);
    QVector3D pIII(3.0, 3.0, 0.0);
    QVector3D pIV(1.0, 3.0, 0.0);

    square.append(pI);
    square.append(pII);
    square.append(pIII);
    square.append(pIV);

    //square is open polygon and should be closed in function calculateCOG

    QVector3D centroid = calculator.calculateCOG(square);

    ASSERT_NEAR(2.0, centroid.x(), 0.00001);
    ASSERT_NEAR(2.0, centroid.y(), 0.00001);
    ASSERT_NEAR(0.0, centroid.z(), 0.00001);

    square.clear();
    pII.setX(-1.0);
    pIII.setX(-1.0);
    pIII.setY(-1.0);
    pIV.setY(-1.0);

    square.append(pI);
    square.append(pII);
    square.append(pIII);
    square.append(pIV);
    square.append(pI);

    //square is closed polygon, so calculation should work and function should
    //recognize that square is a closed polygon
    //points are distributed in all four quadrants

    centroid = calculator.calculateCOG(square);

    ASSERT_NEAR(0.0, centroid.x(), 0.00001);
    ASSERT_NEAR(0.0, centroid.y(), 0.00001);
    ASSERT_NEAR(0.0, centroid.z(), 0.00001);
}

TEST_F(test_AirfoilParameterCalculator, calculateAreaTest)
{
    //calculate area of a square in different positions
    //first quadrant

    QList<QVector3D> square;
    square.clear();

    QVector3D pI(1.0, 1.0, 0.0);
    QVector3D pII(3.0, 1.0, 0.0);
    QVector3D pIII(3.0, 3.0, 0.0);
    QVector3D pIV(1.0, 3.0, 0.0);

    square.append(pI);
    square.append(pII);
    square.append(pIII);
    square.append(pIV);

    //square is opened polygon, so calculation function should close it

    double area = calculator.calculateArea(square);
    ASSERT_NEAR(4.0, area, 0.00001);

    square.clear();
    pII.setX(-1.0);
    pIII.setX(-1.0);
    pIII.setY(-1.0);
    pIV.setY(-1.0);

    square.append(pI);
    square.append(pII);
    square.append(pIII);
    square.append(pIV);
    square.append(pI);

    //square is closed polygon, so calculation function should recognize it
    //points are distributed in all four quadrants

    area = calculator.calculateArea(square);
    ASSERT_NEAR(4.0, area, 0.00001);
}
