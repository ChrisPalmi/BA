#include "stepexporter.h"

#include "xmlreader.h"
#include "propellerbladeskingeometrybuilder.h"
#include "cogstackingstrategy.h"
#include "opencascadegeometryadapter.h"
#include "propellerbladeskinshapebuilder.h"
#include "TopoDS_Shape.hxx"

#include <QDebug>
#include "gtest.h"

class test_STEPExporter : public ::testing::Test
{
protected:
    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }


};

TEST_F(test_STEPExporter, errorHandling)
{
    STEPExporter exporter;

    //wrong path
    XMLReader reader;
    Propeller *srIII;

    srIII = reader.loadPropeller
           ("D:\\data\\PraxisphaseVI\\ExperimentFilesPropster\\"
            "Output\\SRII.xml");

    PropellerBladeSkinGeometryBuilder builder;
    COGStackingStrategy cogStackingStrategy;

    PropellerBladeSkinGeometry skinGeom =
            builder.buildPropellerBladeSkinGeometry(srIII, cogStackingStrategy);


    OpenCascadeGeometryAdapter adapter;
    QList<Handle(TColgp_HArray1OfPnt)> openCascadeGeometry =
            adapter.adaptThreeDGeometry(skinGeom.geometry());

    PropellerBladeSkinShapeBuilder builderII;
    TopoDS_Shape skinShape = builderII.buildShape(openCascadeGeometry);

    Standard_CString notExistingPath = "D:/filepathdoesNOTexist/file.stp";

    exporter.exportFile(skinShape, notExistingPath);
    ASSERT_FALSE(exporter.successfulExport());

    //empty shape
    TopoDS_Shape emptyShape;
    ASSERT_TRUE(emptyShape.IsNull());
    Standard_CString filePathInYourSourceCodeDirectory = "file";
    exporter.exportFile(emptyShape, filePathInYourSourceCodeDirectory);
    ASSERT_FALSE(exporter.successfulExport());

}
