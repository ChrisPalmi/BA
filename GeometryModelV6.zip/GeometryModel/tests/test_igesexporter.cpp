#include "igesexporter.h"
#include "xmlreader.h"
#include "propellerbladeskingeometrybuilder.h"
#include "cogstackingstrategy.h"
#include "opencascadegeometryadapter.h"
#include "propellerbladeskinshapebuilder.h"


#include "gtest.h"

class test_IGESExporter : public ::testing::Test
{
protected:
    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

    IGESExporter exporter;
};

TEST_F(test_IGESExporter, errorHandling)
{
    //wrong path
    XMLReader reader;
    Propeller *srIII;

    srIII = reader.loadPropeller
           ("D:\\data\\PraxisphaseVI\\ExperimentFilesPropster\\"
            "Output\\SRII.xml");

    PropellerBladeSkinGeometryBuilder builder;
    COGStackingStrategy cogStackingStrategy;

    PropellerBladeSkinGeometry skinGeom =
            builder.buildPropellerBladeSkinGeometry(srIII, cogStackingStrategy);


    OpenCascadeGeometryAdapter adapter;
    QList<Handle(TColgp_HArray1OfPnt)> openCascadeGeometry =
            adapter.adaptThreeDGeometry(skinGeom.geometry());

    PropellerBladeSkinShapeBuilder builderII;
    TopoDS_Shape skinShape = builderII.buildShape(openCascadeGeometry);

    Standard_CString notExistingPath = "D:/filepathdoesNOTexist/file.igs";

    exporter.exportFile(skinShape, notExistingPath);
    ASSERT_FALSE(exporter.successfulExport());

    //empty shape
    TopoDS_Shape emptyShape;
    ASSERT_TRUE(emptyShape.IsNull());

    Standard_CString filePathInYourSourceCodeDirectory = "file.igs";
    exporter.exportFile(emptyShape, filePathInYourSourceCodeDirectory);
    ASSERT_FALSE(exporter.successfulExport());

}
