#include "pointadapter.h"

#include "gtest.h"

class test_PointAdapter : public ::testing::Test
{

protected:

    virtual void SetUp()
    {
        QPointF pI(0.0, -1.0);
        QPointF pII(0.0, 1.0);
        QVector3D pIII(2.0, -2.0, 2.0);
        QVector3D pIV(0.0, -3.0, 3.0);
        gp_Pnt pV(4.0, -4.0, 4.0);
        gp_Pnt pVI(0.0, -5.0, 5.0);

        listI.append(pI);
        listI.append(pII);
        listIII.append(pIII);
        listIII.append(pIV);
        listV.append(pV);
        listV.append(pVI);

        zList.append(0.0);
        zList.append(1.0);
    }

    virtual void TearDown()
    {

    }

    PointAdapter adapter;
    QPointF pI;
    QPointF pII;
    QVector3D pIII;
    QVector3D pIV;
    gp_Pnt pV;
    gp_Pnt pVI;
    QList<QPointF> listI;
    QList<QPointF> listII;
    QList<QVector3D> listIII;
    QList<QVector3D> listIV;
    QList<gp_Pnt> listV;
    QList<gp_Pnt> listVI;
    QList<double> zList;

};

TEST_F(test_PointAdapter, singleAdaption)
{
    pII = adapter.gpPntToQPointF(pV);
    ASSERT_DOUBLE_EQ(pV.X(), pII.x());
    ASSERT_DOUBLE_EQ(pV.Y(), pII.y());

    pII = adapter.qVectorThreeDToQPointF(pIII);
    ASSERT_DOUBLE_EQ(pIII.x(), pII.x());
    ASSERT_DOUBLE_EQ(pIII.y(), pII.y());

    pIV = adapter.qPointFToQVectorThreeD(pI, 0.0);
    ASSERT_DOUBLE_EQ(pI.x(), pIV.x());
    ASSERT_DOUBLE_EQ(pI.y(), pIV.y());
    ASSERT_DOUBLE_EQ(0.0, pIV.z());

    pIV = adapter.gpPntToQVectorThreeD(pV);
    ASSERT_DOUBLE_EQ(pV.X(), pIV.x());
    ASSERT_DOUBLE_EQ(pV.Y(), pIV.y());
    ASSERT_DOUBLE_EQ(pV.Z(), pIV.z());

    pVI = adapter.qPointFToGpPnt(pI, 0.0);
    ASSERT_DOUBLE_EQ(pI.x(), pVI.X());
    ASSERT_DOUBLE_EQ(pI.y(), pVI.Y());
    ASSERT_DOUBLE_EQ(0.0, pVI.Z());

    pVI = adapter.qVectorThreeDToGpPnt(pIII);
    ASSERT_DOUBLE_EQ(pIII.x(), pVI.X());
    ASSERT_DOUBLE_EQ(pIII.y(), pVI.Y());
    ASSERT_DOUBLE_EQ(pIII.z(), pVI.Z());
}

TEST_F(test_PointAdapter, listAdaption)
{
    listII = adapter.gpPntsToQPointFs(listV);
    ASSERT_DOUBLE_EQ(listV[0].X(), listII[0].x());
    ASSERT_DOUBLE_EQ(listV[0].Y(), listII[0].y());
    ASSERT_DOUBLE_EQ(listV[1].X(), listII[1].x());
    ASSERT_DOUBLE_EQ(listV[1].Y(), listII[1].y());

    listII = adapter.qVectorThreeDsToQPointFs(listIII);
    ASSERT_DOUBLE_EQ(listIII[0].x(), listII[0].x());
    ASSERT_DOUBLE_EQ(listIII[0].y(), listII[0].y());
    ASSERT_DOUBLE_EQ(listIII[1].x(), listII[1].x());
    ASSERT_DOUBLE_EQ(listIII[1].y(), listII[1].y());

    listIV = adapter.qPointFsToQVectorThreeDs(listI, zList);
    ASSERT_DOUBLE_EQ(listI[0].x(), listIV[0].x());
    ASSERT_DOUBLE_EQ(listI[0].y(), listIV[0].y());
    ASSERT_DOUBLE_EQ(zList[0], listIV[0].z());
    ASSERT_DOUBLE_EQ(listI[1].x(), listIV[1].x());
    ASSERT_DOUBLE_EQ(listI[1].y(), listIV[1].y());
    ASSERT_DOUBLE_EQ(zList[1], listIV[1].z());

    listIV = adapter.gpPntsToQVectorThreeDs(listV);
    ASSERT_DOUBLE_EQ(listV[0].X(), listIV[0].x());
    ASSERT_DOUBLE_EQ(listV[0].Y(), listIV[0].y());
    ASSERT_DOUBLE_EQ(listV[0].Z(), listIV[0].z());
    ASSERT_DOUBLE_EQ(listV[1].X(), listIV[1].x());
    ASSERT_DOUBLE_EQ(listV[1].Y(), listIV[1].y());
    ASSERT_DOUBLE_EQ(listV[1].Z(), listIV[1].z());

    listVI = adapter.qPointFsToGpPnts(listI, zList);
    ASSERT_DOUBLE_EQ(listI[0].x(), listVI[0].X());
    ASSERT_DOUBLE_EQ(listI[0].y(), listVI[0].Y());
    ASSERT_DOUBLE_EQ(zList[0], listVI[0].Z());
    ASSERT_DOUBLE_EQ(listI[1].x(), listVI[1].X());
    ASSERT_DOUBLE_EQ(listI[1].y(), listVI[1].Y());
    ASSERT_DOUBLE_EQ(zList[1], listVI[1].Z());

    listVI = adapter.qVectorThreeDsToGpPnts(listIII);
    ASSERT_DOUBLE_EQ(listIII[0].x(), listVI[0].X());
    ASSERT_DOUBLE_EQ(listIII[0].y(), listVI[0].Y());
    ASSERT_DOUBLE_EQ(listIII[0].z(), listVI[0].Z());
    ASSERT_DOUBLE_EQ(listIII[1].x(), listVI[1].X());
    ASSERT_DOUBLE_EQ(listIII[1].y(), listVI[1].Y());
    ASSERT_DOUBLE_EQ(listIII[1].z(), listVI[1].Z());
}

TEST_F(test_PointAdapter, unequalListSize)
{
    zList.removeLast();
    listIV = adapter.qPointFsToQVectorThreeDs(listI, zList);
    ASSERT_EQ(0, listIV.size());
    listVI = adapter.qPointFsToGpPnts(listI, zList);
    ASSERT_EQ(0, listVI.size());
}









