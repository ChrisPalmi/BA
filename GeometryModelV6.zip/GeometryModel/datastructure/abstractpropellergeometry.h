#ifndef ABSTRACTPROPELLERGEOMETRY_H
#define ABSTRACTPROPELLERGEOMETRY_H

#include <QList>
#include <QVector3D>

/**
 * @brief The AbstractPropellerGeometry class (abstract class) provides
 *        datastructures to contain geometries (ordered point lists) of
 *        propellers
 */
class AbstractPropellerGeometry
{
public:
    /**
     * @brief AbstractPropellerGeometry constructor
     */
    AbstractPropellerGeometry();

    /**
     * @brief ~AbstractPropellerGeometry destructor
     */
    virtual ~AbstractPropellerGeometry() {}

    /**
     * @brief geometry (getter function of m_geometry)
     * @return m_geometry
     */
    QList<QList<QVector3D> > geometry() const;

    /**
     * @brief setGeometry (setter function of m_geometry)
     * @param geometry (ordered pointlist to which m_geometry is set to)
     */
    void setGeometry(const QList<QList<QVector3D> >& geometry);

    /**
     * @brief geometrySet (getter function of m_geometrySet)
     * @return (true if m_geometry was set, else false)
     */
    bool geometrySet() const;

protected:

    /**
     * @brief m_geometry (ordered point list, which contains geometric
     *        information of a propeller)
     */
    QList<QList<QVector3D>> m_geometry;

    /**
     * @brief m_geometrySet (bool variable to check if m_geometry was set (true)
     *        or not (false))
     */
    bool m_geometrySet;

    /**
     * @brief setGeometrySet (setter function for m_geometrySet)
     * @param geometrySet (true if m_geometry was set, else false)
     */
    void setGeometrySet(bool geometrySet);

};

#endif // ABSTRACTPROPELLERGEOMETRY_H
