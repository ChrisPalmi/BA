#include "propellerbladeskingeometry.h"

PropellerBladeSkinGeometry::PropellerBladeSkinGeometry()
{
    setGeometrySet(false);
}

PropellerBladeSkinGeometry::
PropellerBladeSkinGeometry(QList<QList<QVector3D> > geometry)
{
    setGeometry(geometry);
}

PropellerBladeSkinGeometry::~PropellerBladeSkinGeometry()
{

}
