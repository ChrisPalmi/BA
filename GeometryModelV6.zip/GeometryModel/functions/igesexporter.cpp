#include "igesexporter.h"

#include "IGESControl_Controller.hxx"
#include "IGESControl_Writer.hxx"
#include <QDebug>

IGESExporter::IGESExporter()
{
    m_successfulExport = false;
}

IGESExporter::~IGESExporter()
{

}

void IGESExporter::exportFile(TopoDS_Shape &geometryShape,
                              Standard_CString& filepath)
{   
    if(geometryShape.IsNull())
    {
        qDebug() << "ERROR:\nGeometryShape is null! No step file will be "
                    "created!";
        setSuccessfulExport(false);
        return;
    }
    IGESControl_Controller::Init();
    IGESControl_Writer igesExporter;
    bool addedShape = igesExporter.AddShape(geometryShape);

    if(addedShape)
    {
        igesExporter.ComputeModel();
        setSuccessfulExport(igesExporter.Write(filepath));



        if(successfulExport())
        {
            qDebug() << "IGES output file was successfully created!";
        }
        else
        {
            qDebug() << "ERROR:\nIGES Output file could not be created!\n"
                        "Please check your filepath or your geometry";
        }
    }

    else
    {
        qDebug() << "ERROR:\nShape could not be added to IGES Exporter!\n"
                    "No file will be created!\nPlease check your geometry!";
        setSuccessfulExport(false);
    }
}
