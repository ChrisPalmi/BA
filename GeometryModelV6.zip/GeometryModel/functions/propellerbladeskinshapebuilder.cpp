#include "propellerbladeskinshapebuilder.h"

#include <QDebug>

#include "TColgp_HArray1OfPnt.hxx"
#include "GeomAPI_Interpolate.hxx"
#include "BRepBuilderAPI_MakeEdge.hxx"
#include "BRepBuilderAPI_MakeWire.hxx"
#include "BRepBuilderAPI_MakeFace.hxx"
#include "BRepOffsetAPI_ThruSections.hxx"
#include "Geom_Curve.hxx"

#include <Precision.hxx>

#include "TColgp_Array2OfPnt.hxx"
#include "GeomAPI_PointsToBSplineSurface.hxx"
#include "Geom_BSplineSurface.hxx"
#include "BRep_Builder.hxx"
#include "TopoDS_Compound.hxx"
#include "BRepBuilderAPI_Sewing.hxx"
#include "BRepBuilderAPI_MakeSolid.hxx"
#include "BRepClass3d_SolidClassifier.hxx"
#include "TopoDS.hxx"
#include "TopExp.hxx"


PropellerBladeSkinShapeBuilder::PropellerBladeSkinShapeBuilder()
{

}

PropellerBladeSkinShapeBuilder::~PropellerBladeSkinShapeBuilder()
{

}

TopoDS_Shape PropellerBladeSkinShapeBuilder::
buildShape(const QList<QList<QVector3D> >& geometry)
{
    for(int geoAt = 1; geoAt < geometry.size(); geoAt++)
    {
        if(geometry[0].size() != geometry[geoAt].size())
        {
            qDebug() << "ERROR:\nNot all Profiles have the same amount of"
                        "points!\nEmpty TopoDS_Shape will be returned!";

            TopoDS_Shape shape;
            return shape;
        }
    }

    try
    {
        QList<Handle(TColgp_HArray1OfPnt)> ocGeometry;
        ocGeometry.clear();

        for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
        {
            Handle(TColgp_HArray1OfPnt) profileArray = new TColgp_HArray1OfPnt
                                                      (1,
                                                       geometry[geomAt].size());

            gp_Pnt lastPnt;
            int counter = 1;

            for(int profileAt = 1; profileAt <= geometry[geomAt].size();
                profileAt++)
            {
                qDebug() << profileAt;
                gp_Pnt profilepoint = m_adapter.qVectorThreeDToGpPnt
                                      (geometry.at(geomAt).at(profileAt - 1));

                //check if two neighbouring points are to close to each other
                //for b-spline approximation

                //first point
                if(profileAt == 1)
                {
                    profileArray->SetValue(counter, profilepoint);
                    counter++;
                    lastPnt = profilepoint;
                }
                else if(profilepoint.X() - lastPnt.X() <= 1e-10 &&
                        ((profilepoint.X() - lastPnt.X()) * -1.0) <= 1e-10)
                {
                    if(profilepoint.Y() - lastPnt.Y() <= 1e-10 &&
                       ((profilepoint.Y() - lastPnt.Y()) * -1.0) <= 1e-10)
                    {
                        qDebug() << "ERROR:\nTwo points are to close to each "
                                    "other!\nEmpty Shape will be returned!";

                        TopoDS_Shape emptyShape;
                        return emptyShape;
                    }
                    else
                    {
                        profileArray->SetValue(counter, profilepoint);
                        counter++;
                        lastPnt = profilepoint;
                    }
                }
                else
                {
                    profileArray->SetValue(counter, profilepoint);
                    counter++;
                    lastPnt = profilepoint;
                }

            }

            ocGeometry.append(profileArray);
        }

        return shapeBuildNew(ocGeometry);
    }

    catch (...)
    {
        TopoDS_Shape emptyShape;
        return emptyShape;
    }
}

TopoDS_Shape PropellerBladeSkinShapeBuilder::
shapeBuildNew(const QList<Handle (TColgp_HArray1OfPnt)>& ocGeometry)
{
    TColgp_Array2OfPnt thepoints(1, ocGeometry.size(),
                                 1, ocGeometry.at(0)->Length() + 1);

    for(int geomAt = 0; geomAt < ocGeometry.size(); geomAt++)
    {
        for(int profileAt = 0; profileAt < ocGeometry.at(0)->Length();
            profileAt++)
        {

            thepoints.SetValue(geomAt + 1, profileAt + 1,
                               ocGeometry.at(geomAt)->Value(profileAt + 1));
        }

        thepoints.SetValue(geomAt + 1, ocGeometry.at(0)->Length() + 1,
                           ocGeometry.at(geomAt)->Value(1));
    }

    GeomAPI_PointsToBSplineSurface ptbss(thepoints, Approx_Centripetal, 3,
                                         3, GeomAbs_C2, 1.0);
    Handle(Geom_BSplineSurface) propSurface = ptbss.Surface();

    Handle(Geom_Curve) bottomCurve;
    Handle(Geom_Curve) topCurve;

    //check if u or v is closed to see which variable is for radial direction
    //an which one is for direction along an airfoil
    if(propSurface->IsUClosed())
    {
        Standard_Integer firstVKnotIndex = propSurface->FirstVKnotIndex();
        Standard_Integer lastVKnotIndex = propSurface->LastVKnotIndex();

        Standard_Real firstVKnot = propSurface->VKnot(firstVKnotIndex);
        Standard_Real lastVKnot = propSurface->VKnot(lastVKnotIndex);

        bottomCurve = propSurface->VIso(firstVKnot);
        topCurve = propSurface->VIso(lastVKnot);
    }

    else if(propSurface->IsVClosed())
    {
        Standard_Integer firstUKnotIndex = propSurface->FirstUKnotIndex();
        Standard_Integer lastUKnotIndex = propSurface->LastUKnotIndex();

        Standard_Real firstUKnot = propSurface->UKnot(firstUKnotIndex);
        Standard_Real lastUKnot = propSurface->UKnot(lastUKnotIndex);

        bottomCurve = propSurface->UIso(firstUKnot);
        topCurve = propSurface->UIso(lastUKnot);
    }

    else
    {
        "ERROR:\nNeither u nor v is closed!\nEmpty Shape will be returned!";

        TopoDS_Shape emptyShape;
        return emptyShape;
    }

    //create edges, wires, faces and finally a solid out of a shell
    BRepBuilderAPI_MakeEdge bottomEdgeMaker(bottomCurve);
    BRepBuilderAPI_MakeEdge topEdgeMaker(topCurve);

    BRepBuilderAPI_MakeWire bottomWireMaker(bottomEdgeMaker.Edge());
    BRepBuilderAPI_MakeWire topWireMaker(topEdgeMaker.Edge());

    BRepBuilderAPI_MakeFace bottomFaceMaker(bottomWireMaker.Wire());
    BRepBuilderAPI_MakeFace topFaceMaker(topWireMaker.Wire());

    Handle(Geom_BSplineSurface) thisSurface = propSurface;
    TopoDS_Shape mainFace = BRepBuilderAPI_MakeFace(thisSurface,
                                                   Precision::Confusion());

//    BRep_Builder b;
//    TopoDS_Compound compound;
//    b.MakeCompound(compound);
//    b.Add(compound, mainFace);
//    b.Add(compound, bottomFaceMaker.Face());
//    b.Add(compound, topFaceMaker.Face());

    BRepBuilderAPI_Sewing shellMaker;
    TopoDS_Shape shell;
    shellMaker.Add(mainFace);
    shellMaker.Add(bottomFaceMaker.Face());
    shellMaker.Add(topFaceMaker.Face());
    shellMaker.Perform();
    shell = shellMaker.SewedShape();

    BRepBuilderAPI_MakeSolid solidmaker;

    TopTools_IndexedMapOfShape shellMap;
    TopExp::MapShapes(shell, TopAbs_SHELL, shellMap);
    for(int ishell = 1; ishell <= shellMap.Extent(); ishell++)
    {
        const TopoDS_Shell& myshell = TopoDS::Shell(shellMap(ishell));
        solidmaker.Add(myshell);
    }


    TopoDS_Shape solid = solidmaker.Solid();

    BRepClass3d_SolidClassifier clas3d(solid);
    clas3d.PerformInfinitePoint(Precision::Confusion());

    if(clas3d.State() == TopAbs_IN)
    {
        solid.Reverse();
    }

    return solid;

}


TopoDS_Shape PropellerBladeSkinShapeBuilder::
buildShape(const QList<Handle(TColgp_HArray1OfPnt)> &ocGeometry)
{
    for(int geoAt = 1; geoAt < ocGeometry.size(); geoAt++)
    {
        if(ocGeometry[0]->Length() != ocGeometry[geoAt]->Length())
        {
            qDebug() << "ERROR:\nNot all Profiles have the same amount of"
                        "points!\nEmpty TopoDS_Shape will be returned!";

            TopoDS_Shape shape;
            return shape;
        }
    }

    try
    {
        return shapeBuildNew(ocGeometry);
    }
    catch (...)
    {
        TopoDS_Shape emptyShape;
        return emptyShape;
    }
}



TopoDS_Shape PropellerBladeSkinShapeBuilder::
shapeBuild(const QList<Handle (TColgp_HArray1OfPnt)> &ocGeometry)
{
    try
    {
        QList<TopoDS_Wire> profileWires;
        profileWires.clear();


        for(int geomAt = 0; geomAt < ocGeometry.size(); geomAt++)
        {
            GeomAPI_Interpolate interpolator(ocGeometry[geomAt], Standard_False,
                                             1e-8);
            interpolator.Perform();

            Handle(Geom_Curve) profileCurve = interpolator.Curve();
            profileCurve->Reverse();

            BRepBuilderAPI_MakeEdge edgeMaker(profileCurve);
            TopoDS_Edge edge = edgeMaker.Edge();

            BRepBuilderAPI_MakeWire wireMaker;
            wireMaker.Add(edge);
            wireMaker.Build();

            profileWires.append(wireMaker.Wire());
        }


        BRepOffsetAPI_ThruSections lofter(Standard_False, Standard_False);




        for(int wiresAt = 0; wiresAt < profileWires.size(); wiresAt++)
        {
            lofter.AddWire(profileWires.at(wiresAt));
        }

        lofter.Build();

        TopoDS_Shape propellerBladeSkinGeometryShape = lofter.Shape();

        return propellerBladeSkinGeometryShape;

    }

    catch (...)
    {
        qDebug() << "WARNING:\nSomething went wrong by creating a shape!\n"
                    "Funktion shape build is concerned!\nEmpty Shape will be "
                    "returned!";

        TopoDS_Shape emptyShape;
        return emptyShape;
    }
}




















