#include "abstractairfoilgeometrybuilder.h"

AbstractAirfoilGeometryBuilder::AbstractAirfoilGeometryBuilder()
{

}
