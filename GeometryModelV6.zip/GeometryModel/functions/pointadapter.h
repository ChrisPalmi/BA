#ifndef POINTADAPTER_H
#define POINTADAPTER_H

#include <QPointF>
#include <QVector3D>
#include <QList>

#include "gp_Pnt.hxx"

/**
 * @brief The PointAdapter class provides functionalities to convert different
 *        point class structures into each other
 */
class PointAdapter
{
public:
    /**
     * @brief PointAdapter constructor
     */
    PointAdapter();

    /**
     * @brief ~PointAdapter destructor
     */
    ~PointAdapter();

    /**
     * @brief gpPntToQPointF function provides functionality to convert a
     *        gp_pnt into a QPointF
     * @param pnt (point which should be converted)
     * @return QPointF with pnt input
     */
    QPointF gpPntToQPointF(gp_Pnt pnt);

    /**
     * @brief qVectorThreeDToQPointF function provides functionality to
     *        convert a QVector3D into a QPointF
     * @param pnt (point which should be converted)
     * @return QPointF with pnt input
     */
    QPointF qVectorThreeDToQPointF(QVector3D pnt);

    /**
     * @brief gpPntToQVectorThreeD function provides functionality to
     *        convert a gp_pnt into a QVector3D
     * @param pnt (point which should be converted)
     * @return QVector3D with pnt input
     */
    QVector3D gpPntToQVectorThreeD(gp_Pnt pnt);

    /**
     * @brief qPointFToQVectorThreeD function provides functionality to
     *        convert a QPointF into a QVector3D
     * @param pnt (point which should be converted)
     * @param zCoor (z coordinate of QVector3D)
     * @return QVector3D with pnt input
     */
    QVector3D qPointFToQVectorThreeD(QPointF pnt, double zCoor);

    /**
     * @brief qVectorThreeDToGpPnt function provides functionality to
     *        convert a QVector3D into a gp_pnt
     * @param pnt (point which should be converted)
     * @return gp_pnt with pnt input
     */
    gp_Pnt qVectorThreeDToGpPnt(QVector3D pnt);

    /**
     * @brief qPointFToGpPnt function provides functionality to
     *        convert a QPointF into a gp_pnt
     * @param pnt (point which should be converted)
     * @param zCoor (z coordinate of gp_pnt)
     * @return gp_pnt with pnt input
     */
    gp_Pnt qPointFToGpPnt(QPointF pnt, double zCoor);

    /**
     * @brief gpPntsToQPointFs function provides functionality to
     *        convert multiple gp_pnt´s into QPointF´s
     * @param pnts (points which should be converted)
     * @return QPointF´s with pnts input
     */
    QList<QPointF> gpPntsToQPointFs(QList<gp_Pnt> pnts);

    /**
     * @brief qVectorThreeDsToQPointFs function provides functionality to
     *        convert multiple QVector3D´s into QPointF´s
     * @param pnts (points which should be converted)
     * @return QPointF´s with pnts input
     */
    QList<QPointF> qVectorThreeDsToQPointFs(QList<QVector3D> pnts);

    /**
     * @brief gpPntsToQVectorThreeDs function provides functionality to
     *        convert multiple gp_pnt´s into QVector3D´s
     * @param pnts (points which should be converted)
     * @return QVector3D´s with pnts input
     */
    QList<QVector3D> gpPntsToQVectorThreeDs(QList<gp_Pnt> pnts);

    /**
     * @brief qPointFsToQVectorThreeDs function provides functionality to
     *        convert multiple QPointF´s into QVector3D´s
     * @param pnts (points which should be converted)
     * @param zCoors (z coordinates of QVector3D´s)
     * @return QVector3D´s with pnts input
     */
    QList<QVector3D> qPointFsToQVectorThreeDs(QList<QPointF> pnts,
                                              QList<double> zCoors);

    /**
     * @brief qPointFsToQVectorThreeDs function provides functionality to
     *        convert multiple QPointF´s into QVector3D´s
     * @param pnts (points which should be converted)
     * @param zCoor (z coordinate of all QVector3D´s)
     * @return QVector3D´s with pnts input
     */
    QList<QVector3D> qPointFsToQVectorThreeDs(QList<QPointF> pnts,
                                              double zCoor);

    /**
     * @brief qVectorThreeDsToGpPnts function provides functionality to
     *        convert multiple QPointF´s into QVector3D´s
     * @param pnts (points which should be converted)
     * @return gp_pnt´s with pnts input
     */
    QList<gp_Pnt> qVectorThreeDsToGpPnts(QList<QVector3D> pnts);

    /**
     * @brief qPointFsToGpPnts function provides functionality to
     *        convert multiple QPointF´s into QVector3D´s
     * @param pnts (points which should be converted)
     * @param zCoors (z coordinates of gp_pnt´s)
     * @return gp_pnt´s with pnts input
     */
    QList<gp_Pnt> qPointFsToGpPnts(QList<QPointF> pnts, QList<double> zCoors);

    /**
     * @brief qPointFsToGpPnts function provides functionality to
     *        convert multiple QPointF´s into QVector3D´s
     * @param pnts (points which should be converted)
     * @param zCoor (z coordinate of all gp_pnt´s)
     * @return gp_pnt´s with pnts input
     */
    QList<gp_Pnt> qPointFsToGpPnts(QList<QPointF> pnts, double zCoor);


};



#endif // POINTADAPTER_H
