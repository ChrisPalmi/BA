#include "stepexporter.h"
#include "STEPControl_Controller.hxx"
#include "STEPControl_Writer.hxx"
#include <QDebug>
#include "Standard_PrimitiveTypes.hxx"

STEPExporter::STEPExporter()
{

}

STEPExporter::~STEPExporter()
{

}

void STEPExporter::exportFile(TopoDS_Shape& geometryShape,
                              Standard_CString& filepath)
{
    if(geometryShape.IsNull())
    {
        qDebug() <<"ERROR:\nGeometryShape is null!\nNo step file can be "
                   "created!";
        setSuccessfulExport(false);
        return;
    }

    STEPControl_Controller::Init();
    STEPControl_Writer stepExporter;
    bool addedShape = stepExporter.Transfer(geometryShape, STEPControl_AsIs);

    if(addedShape)
    {
        IFSelect_ReturnStatus status = stepExporter.Write(filepath);

        if(status == IFSelect_RetDone)
        {
            qDebug() << "STEP output file was successfully created!";
            setSuccessfulExport(true);
        }
        else
        {
            qDebug() << "ERROR:\nSTEP Output file could not be created!\n"
                        "Please check your geometry";
            setSuccessfulExport(false);
        }
    }

    else
    {
        qDebug() << "ERROR:\nShape could not be added to STEP Exporter!\n"
                    "No file will be created!\nPlease check your geometry!";
        setSuccessfulExport(false);
    }
}
