#ifndef INTERSECTIONFINDER_H
#define INTERSECTIONFINDER_H

#include <QPointF>

/**
 * @brief The Intersectionfinder class provides the functionality to find the
 *        intersection point of two linear vector equations
 */
class Intersectionfinder
{
public:

    /**
     * @brief Intersectionfinder constructor
     */
    Intersectionfinder();

    /**
     * @brief ~Intersectionfinder destructor
     */
    ~Intersectionfinder();

    /**
     * @brief findIntersection provides the functionality to find the
     *        intersection point of two linear vector equations
     * @param firstPosVect (position vector of first equation)
     * @param firstDirVect (direction vector of first equation)
     * @param secondPosVect (position vector of second equation)
     * @param secondDirVect (direction vector of second equation)
     * @return intersection point
     */
    QPointF findIntersection(const QPointF& firstPosVect,
                             const QPointF& firstDirVect,
                             const QPointF& secondPosVect,
                             const QPointF& secondDirVect);

    bool intersectionFound() const;


private:

    bool m_intersectionFound;
    void setIntersectionFound(bool intersectionFound);
};


#endif // INTERSECTIONFINDER_H
