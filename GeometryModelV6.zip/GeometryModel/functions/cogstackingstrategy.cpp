#include "cogstackingstrategy.h"
#include <QDebug>

COGStackingStrategy::COGStackingStrategy()
{

}

COGStackingStrategy::~COGStackingStrategy()
{

}

QList<QList<QVector3D> > COGStackingStrategy::
stackAirfoils(const QList<QList<QVector3D>>& airfoils)
{
    if(airfoils.isEmpty())
    {
        qDebug() << "ERROR:\nAirfoils is empty, so no airfoils could be "
                    "stacked!\nEmpty list will be returned!";

        return airfoils;
    }

    QList<QList<QVector3D>> stackedAirfoils;
    stackedAirfoils.clear();

    for(int airfoilAt = 0; airfoilAt < airfoils.size(); airfoilAt++)
    {        
        //calculate direction vector to relocate airfoil at cog

        QVector3D cog = m_calculator.calculateCOG(airfoils.at(airfoilAt));

        QVector3D dirVect;
        dirVect.setX(- cog.x());
        dirVect.setY(- cog.y());
        dirVect.setZ(0.0);

        //relocate airfoil
        QList<QVector3D> stackedAirfoil =
                m_transformer.locateGeometry(airfoils[airfoilAt], dirVect);

        stackedAirfoils.append(stackedAirfoil);
    }

    return stackedAirfoils;
}


