#ifndef OPENCASCADEGEOMETRYADAPTER_H
#define OPENCASCADEGEOMETRYADAPTER_H

#include "abstractgeometryadapter.h"
#include "pointadapter.h"

#include "gp_Pnt.hxx"
#include "TColgp_HArray1OfPnt.hxx"
#include "Standard_Macro.hxx"

#include <QList>
#include <QVector3D>
#include <QString>

/**
 * @brief The OpenCascadeGeometryAdapter class provides functionalities to adapt
 *        ordered point lists into Open Cascade array formats
 */
class OpenCascadeGeometryAdapter
{
public:

    /**
     * @brief OpenCascadeGeometryAdapter constructor
     */
    OpenCascadeGeometryAdapter();
    /**
     * @brief ~OpenCascadeGeometryAdapter destructor
     */
    ~OpenCascadeGeometryAdapter();

    /**
     * @brief adaptTwoDGeometry function provides functionality to adapt an
     *        ordered point list into a Handle(TColgp_HArray1OfPnt)
     * @param geometry (ordered point list which should be adapted)
     * @return Handle(TColgp_HArray1OfPnt) with input of geometry
     */
    Handle(TColgp_HArray1OfPnt) adaptTwoDGeometry(QList<QVector3D> &geometry);

    /**
     * @brief adaptThreeDGeometry function provides functionality to adapt
     *        multiple ordered point lists into a list of
     *        Handle(TColgp_HArray1OfPnt)
     * @param geometry (pointlists which should be adapted)
     * @return list of Handle(TColgp_HArray1OfPnt) with input of geometry
     */
    QList<Handle(TColgp_HArray1OfPnt)>
    adaptThreeDGeometry(QList<QList<QVector3D>> & geometry);

private:

    /**
     * @brief m_adapter PointAdapter member variable to convert qt points
     *        (QPointF, QVector3D) into Open Cascade points (gp_pnt)
     */
    PointAdapter m_adapter;

    void createSTLFile(QList<Handle(TColgp_HArray1OfPnt)> blade,
                       QString outputpath);

    bool outputSTLII(QString filepath, Handle(TColgp_HArray1OfPnt) station);
    bool outputSTLI(QString filepath, QList<QVector3D> station);

};

#endif // OPENCASCADEGEOMETRYADAPTER_H
