#ifndef STEPEXPORTER_H
#define STEPEXPORTER_H

#include "abstractexporter.h"

/**
 * @brief The STEPExporter class provides functionality to create STEP output
 *        files out of a given geometry (Open Cascade TopoDS_Shape)
 */
class STEPExporter : public AbstractExporter
{
public:
    /**
     * @brief STEPExporter constructor
     */
    STEPExporter();

    /**
     * @brief ~STEPExporter destructor
     */
    virtual ~STEPExporter();

    /**
     * @brief exportFile function provides functionality to create STEP output
     *        files out of a given geometry (Open Cascade TopoDS_Shape)
     * @param geometryShape (geometry which should be described in output file)
     * @param filepath (path where output file should be created
     *                  For example: "D:/data/myOutputFiles/myFile.stp")
     */
    void exportFile(TopoDS_Shape &geometryShape, Standard_CString &filepath);
};

#endif // STEPEXPORTER_H
