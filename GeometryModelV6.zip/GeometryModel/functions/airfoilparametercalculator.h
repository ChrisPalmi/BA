#ifndef AIRFOILPARAMETERCALCULATOR_H
#define AIRFOILPARAMETERCALCULATOR_H

#include <QList>
#include <QVector3D>

/**
 * @brief The AirfoilParameterCalculator class provides functionalities to
 *        calculate several parameters of an airfoil by using their geometry
 *        (ordered pointlist)
 */
class AirfoilParameterCalculator
{
public:
    /**
     * @brief AirfoilParameterCalculator constructor
     */
    AirfoilParameterCalculator();

    /**
     * @brief ~AirfoilParameterCalculator destructor
     */
    ~AirfoilParameterCalculator();

    /**
     * @brief calculateChordLength calculates the chord length of an airfoil
     * @param airfoil (geometry -> ordered pointlist where first point is the
     *                 trailing edge and leading edge is (0.0|0.0)
     * @return chordlength of airfoil
     */
    double calculateChordLength(const QList<QVector3D>& airfoil);

    /**
     * @brief calculateBladeAngleDeg calculates the bladeangle (deg) of an
     *        airfoil
     * @param airfoil (geometry -> ordered pointlist where first point is the
     *                 trailing edge and leading edge is (0.0|0.0)
     * @return bladeangle (deg)
     */
    double calculateBladeAngleDeg(const QList<QVector3D>& airfoil);

    /**
     * @brief calculateCOG function provides the functionality to calculate the
     *        center of gravity out of a closed polygon
     * @param polygon (ordered pointlist)
     * @return center of gravity of polygon
     */
    QVector3D calculateCOG(const QList<QVector3D> &polygon);

    /**
     * @brief calculateArea function provides the functionality to calculate the
     *        area out of a closed polygon
     * @param polygon (ordered pointlist)
     * @return area of polygon
     */
    double calculateArea(const QList<QVector3D> &polygon);
};

#endif // AIRFOILPARAMETERCALCULATOR_H
