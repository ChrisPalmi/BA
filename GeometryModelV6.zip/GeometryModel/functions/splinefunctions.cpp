using namespace std;

#include "iostream"
#include "splinefunctions.h"
#include "QDebug"
#include "QPointF"
#include "QtGlobal"



//Constructor
SplineFunctions::SplineFunctions()
{
}


//Destructor
SplineFunctions::~SplineFunctions()
{
}



void SplineFunctions::test(int amountCP, int degree, qreal u, int i, int p)
{
    clearAllParams();
    m_paramsSet = false;
    m_allSet = false;
    setCDBParams(amountCP, degree);
    setTriangularScheme();
    coxDeBoorAlgorithm(amountCP, p, u, i);
}




QPointF SplineFunctions::getCU(int amountCP, int degree, qreal u)

/*
 * Public Function, which returns a QPointF of a B-Spline at u
 */

{
    clearAllParams();
    setCDBParams(amountCP, degree);
    setTriangularScheme();
    return pointOfFunction(amountCP, degree, u);
}




QVector<QPointF> SplineFunctions::getMultipleCUs(int amountCP, int degree, int amountCU)

/*
 * Public Function, which returns multiple QPointF
 * of a B-Spline which are provided by a QVector.
 * The distance between each point is equal
 */

{
    clearAllParams();
    m_paramsSet = false;
    m_allSet = false;
    setCDBParams(amountCP, degree);
    setTriangularScheme();

    //Set span for CU´s and create Vector which contains all CU´s in the end
    qreal factor = 1.0 / (amountCU + 1);
    QVector<QPointF> CUVector;

    for(int a = 1; a <= amountCU; a++)
    {
        qreal cu = a * factor;
        CUVector.append(pointOfFunction(amountCP, degree, cu));
    }

    return CUVector;
}


QVector<QPointF> SplineFunctions::getAllCPs()

/*
 * Public Function which returns the Vector which provides all CP´s as QPointF´s
 */

{
    return m_AllControlPoints;
}

void SplineFunctions::recreateCPVector(QVector<QPointF> newVector)
{
    m_AllControlPoints.clear();
    m_AllControlPoints = newVector;
}



void SplineFunctions::clearAllParams()

/*
 * Private Function which clears all parameters.
 * Those parameters are set when a function is called,
 * which creates a B-Spline
 */

{
    m_m = 0;
    m_TriangularScheme.clear();
//    m_AllControlPoints.clear();
    m_knotVector.clear();
}





qreal SplineFunctions::coxDeBoorAlgorithm(int amountCP, int p, qreal u, int i)

/*
 * Private function which contains the Cox-de-Boor algorithm.
 * This function is used by every other function,
 * which creates a B-Spline
 *
 * Cox-de-Boor algorithm:
 *
 * N i,0(u) = 1 if u i <= u <= u i+1
 *          = 0 Otherwise
 *
 * N i,p(u) = ((u - u i) / (u i+p - u i)) * N i, p-1(u) +
 *            ((u i+p+1 - u) / (u i+p+1 - u i+1)) * N i+1, p-1(u)
 *
 */

{
    if(m_allSet == true)
    {
        //Exceptionhandling i or p to big
        if(i + p >= m_knotVector.size() - 1 || amountCP == 0)
        {
            qDebug() << "ABBRUCH!";
            return -1.0;
        }

        //CDB knotspan is zero?!
        if(m_TriangularScheme[i][p] == false)
        {
            return 0.0;
        }


        //Degree is zero
        if(p == 0 && m_knotVector.at(i) <= u && u < m_knotVector.at(i+1))
        {
            return 1.0;
        }

        else if(p == 0)
        {
            return 0.0;
        }


        //Higher degrees
        else
        {
            qreal factOne;
            qreal factTwo;

            //CDB i, p-1 is zero?!
            //Yes -> would lead to division through null -> exception: set fact1 0.0
            if(m_TriangularScheme[i][p - 1] == false)
            {
                factOne = 0.0;
            }
            //No
            else
            {
                factOne = (u - m_knotVector.at(i)) /
                          (m_knotVector.at(i + p) - m_knotVector.at(i));
            }

            //CDB i+1, p-1 is zero?!
            //Yes -> would lead to division through null -> exception: set fact2 0.0
            if(m_TriangularScheme[i + 1][p - 1] == false)
            {
                factTwo = 0.0;
            }
            //No
            else
            {
                factTwo = (m_knotVector.at(i + p + 1) - u) /
                          (m_knotVector.at(i + p + 1) - m_knotVector.at(i+1));
            }


            qreal result = (factOne * coxDeBoorAlgorithm(amountCP, p - 1, u, i)) +
                           (factTwo * coxDeBoorAlgorithm(amountCP, p - 1, u, i+1));


            return result;

        }
    }
}



void SplineFunctions::setCDBParams(int amountCP, int degree)
/*
 * Private function which sets all necessary parameters
 * to craete a B-Spline. This function sets the Knotvector
 * as well.
 */


{

    //set parameters
    m_m = amountCP + degree;
    m_knotVector.resize(m_m + 1);

    //fill knotvector
    qreal amountOfSegments = (qreal) amountCP - (qreal) degree; //n-p+1
    qreal factor = 1.0 / amountOfSegments;
    qreal counter = 1.0;

    for(int a = 0; a <= m_m; a++)
    {
        //Multiplicity 0
        if(a <= degree)
        {
            m_knotVector[a] = 0.0;
        }

        //Multiplicity 1
        if(a >= m_m - degree)
        {
            m_knotVector[a] = 1.0;
        }

        //remaining knots
        if(a > degree && a < m_m - degree)
        {
            qreal knotPoint = factor * counter;
            m_knotVector[a] = knotPoint;
            counter = counter + 1.0;
        }

    }

    m_paramsSet = true;
}








void SplineFunctions::setTriangularScheme()

/*
 * Private function, which craetes a triangular
 * scheme filled with true/ false
 * true means zero span, false means non-zero span
 */

{

    if(m_paramsSet == false){
        return;
    }


    //Set-Triangle-Structure
    //Find-Zero-Knot-Spans
    //-------N i,0----------

    m_TriangularScheme.resize(m_m); //m_m is i for degree 0

    for(int i = 0; i < m_m; i++)
    {
        //set triangular structure
        m_TriangularScheme[i].resize(m_m - i);

        if(m_knotVector.at(i) == m_knotVector.at(i + 1))
        {
            //knotspan is zero -> false
            m_TriangularScheme[i][0] = false;
        }
        else
        {
            //knotspan is not zero -> true
            m_TriangularScheme[i][0] = true;
        }
    }


    //Find-Zero-Knot-Spans
    //-N i,1/2/.../m_m-1--

    int m = m_m - 1; //for increasing degrees by 1, i is decreasing by 1
                     //-> triangular structure (*)

    for(int j = 1; j < m_m; j++) //j -> degree (1 to m_m - 1)
    {
        for(int a = 0; a < m; a++) //a -> i (0 to m - 1)
                                   //m decreasing while j (degree) increasing (*)
        {
            if(m_TriangularScheme.at(a).at(j - 1) == false &&
               m_TriangularScheme.at(a + 1).at(j - 1) == false)
            {
                m_TriangularScheme[a][j] = false;
            }
            else
            {
                m_TriangularScheme[a][j] = true;
            }
        }

        m = m - 1; //decrease, because j (degree) increases next(*)
    }

    m_allSet = true;
}




QPointF SplineFunctions::pointOfFunction(int amountCP, int degree, qreal u)

/*
 * Private function which returns a QPointF
 * This is a point which is located on a B-Spline,
 * which was created before
 *
 * C(u) = Sum of N i,p(u) * P i
 * with i from 0 to n
 */

{
    if(m_allSet == true)
    {

        QPointF resultC(0.0, 0.0);

        qreal finalXCoor = 0.0;
        qreal finalYCoor = 0.0;

        for (int i = 0; i < amountCP; i++)
        {
            finalXCoor += coxDeBoorAlgorithm(amountCP, degree, u, i) *
                          m_AllControlPoints.at(i).x();



            finalYCoor += coxDeBoorAlgorithm(amountCP, degree, u , i) *
                          m_AllControlPoints.at(i).y();

        }

        resultC.setX(finalXCoor);
        resultC.setY(finalYCoor);

        return resultC;
    }

    else
    {
        cout << "Abbruch, setzen Sie zuerst die Kontrollpunkte" <<
                "mit der Funktion setAllCPoints\n";

        QPointF error(-1.0, -1.0);
        return error;
    }
}


void SplineFunctions::setCPoint(qreal xCoor, qreal yCoor)

/*
 * Private function which makes it possible
 * for the user to append a Control Point
 * of a B-Spline to the Control Point Vector (m_AllControlPoints)
 */

{
    QPointF controlPoint;
    controlPoint.setX(xCoor);
    controlPoint.setY(yCoor);

    m_AllControlPoints << controlPoint;
}

QVector<qreal> SplineFunctions::getKnotVector() const
{
    return m_knotVector;
}

























