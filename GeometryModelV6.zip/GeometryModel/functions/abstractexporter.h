#ifndef ABSTRACTEXPORTER_H
#define ABSTRACTEXPORTER_H

#include "Standard_CString.hxx"
#include "TopoDS_Shape.hxx"

/**
 * @brief The AbstractExporter class is an abstract class, which provides
 *        functionalities to create CAD output files out of a given geometry
 *        (Open Cascade TopoDS_Shape)
 */
class AbstractExporter
{
public:
    /**
     * @brief AbstractExporter constructor
     */
    AbstractExporter();

    /**
     * @brief ~AbstractExporter destructor
     */
    virtual ~AbstractExporter() {}

    /**
     * @brief exportFile provides functionality to create a cad output file out
     *        of a given geometry
     * @param geometryShape (geometry which should be described in the output
     *                       file)
     * @param filepath (path where outputfile should be created
     *                  For example: "D:/data/myOutputfiles/myFile.igs")
     */
    virtual void exportFile(TopoDS_Shape &geometryShape,
                            Standard_CString &filepath) = 0;

    /**
     * @brief successfulExport getter function for m_successfulExport
     * @return true if output file was successfully created, else false
     */
    bool successfulExport() const;


protected:

    /**
     * @brief m_successfulExport true if output file was successfully created,
     *                           else false
     */
    bool m_successfulExport;

    /**
     * @brief setSuccessfulExport setter function for m_successfulExport
     * @param successfulExport true if output file was successfully created,
     *                         else false
     */
    void setSuccessfulExport(bool successfulExport);

};

#endif // ABSTRACTEXPORTER_H
