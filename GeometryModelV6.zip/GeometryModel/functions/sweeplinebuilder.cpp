#define _USE_MATH_DEFINES
#include <cmath>

#include "sweeplinebuilder.h"

#include "gt_splinefit.h"
#include "gt_bsplinealgorithm.h"
//#include "splinefunctions.h"
#include "rootfinder.h"
#include "intersectionfinder.h"

#include <QDebug>
#include <QPointF>

SweepLineBuilder::SweepLineBuilder()
{

}

SweepLineBuilder::~SweepLineBuilder()
{

}

QList<QPointF> SweepLineBuilder::
buildNormedSweepLine(const QList<QPointF> &sweepAngleDegList,
                     int numberOfIterations,
                     double nonHubRad)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    //fit sweep angle
    GtSplineFit* sweepFitter = new GtSplineFit(3, 4, 0.001, 800);
    sweepFitter->fit(sweepAngleDegList);
    RootFinder finder;
    bool brentNotOK = false;

    //build sweep line iteratively
    QList<QPointF> sweepLine;
    sweepLine.clear();

    QPointF firstPoint(0.0, nonHubRad);
    sweepLine.append(firstPoint);

    //step factor in radial direction
    double iterFactor = (sweepAngleDegList.last().x() - nonHubRad) /
                        (numberOfIterations - 1);
    //last sweep
    double lastX = 0.0;

    for(int iterAt = 1; iterAt < numberOfIterations; iterAt++)
    {
        double nonRad = nonHubRad + (iterFactor * iterAt);
        double nonRadBefore = nonHubRad + (iterFactor * (iterAt - 1));

        auto sweepFunc = [nonRadBefore, sweepFitter](double u)
        {
            QPointF aPoint = sweepFitter->getCurvePoint(u);
            double diff = nonRadBefore - aPoint.x();
            return diff;
        };

        double sweepU = finder.Brent(sweepFunc, 0.0, 1.0,
                                     brentNotOK, 1.0e-12, 100);

        if(brentNotOK == true)
        {
            qDebug() << "ERROR: \nBrent did not work!\n"
                        "Empty List of sweep line will be returned!";

            QList<QPointF> emptyList;
            emptyList.clear();
            return emptyList;
        }

        QPointF sweepPnt = sweepFitter->getCurvePoint(sweepU);
        double sweepAngle = sweepPnt.y();


        //calculate position of pnt on sweep line by considering the sweep angle
        //at this nondimensional radius and the last calculated point of the
        //sweep line

        //negative sweep
        if(sweepAngle <= 0.0)
        {
            double shift = tan(sweepAngle * (M_PI / 180.0)) * iterFactor;
            double xCoor = lastX + shift;
            QPointF sweepLinePnt(xCoor, nonRad);
            sweepLine.append(sweepLinePnt);

            lastX = xCoor;
        }

        //positive sweep
        else
        {
            sweepAngle = -1.0 * sweepAngle;
            double shift = tan(sweepAngle * (M_PI / 180.0)) * iterFactor;
            double xCoor = lastX - shift;
            QPointF sweepLinePnt(xCoor, nonRad);
            sweepLine.append(sweepLinePnt);

            lastX = xCoor;
        }
    }

    return sweepLine;
}

QList<QPointF> SweepLineBuilder::
buildNormedSweepLine(QString normedSweepAngleDegPath, int numberOfIterations,
                     double nonHubRad)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> sweepList =
           m_reader.readFile(normedSweepAngleDegPath);

    return buildNormedSweepLine(sweepList, numberOfIterations, nonHubRad);

}

QList<QPointF> SweepLineBuilder::
buildSweepLine(const QList<QPointF>& normedSweepAngleDegList,
               int numberOfIterations, double nonHubRad, double propRadius)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> sweepLine = buildNormedSweepLine(normedSweepAngleDegList,
                                                    numberOfIterations,
                                                    nonHubRad);

    //scale normed sweep line
    for(int listAt = 0; listAt < sweepLine.size(); listAt++)
    {
        sweepLine[listAt].setX(sweepLine[listAt].x() * propRadius);
        sweepLine[listAt].setY(sweepLine[listAt].y() * propRadius);
    }

    return sweepLine;
}

QList<QPointF> SweepLineBuilder::
buildSweepLine(QString normedSweepAngleDegPath, int numberOfIterations,
               double nonHubRad, double propRadius)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> sweepLine = buildNormedSweepLine(normedSweepAngleDegPath,
                                                    numberOfIterations,
                                                    nonHubRad);
    //scale normed sweep line
    for(int listAt = 0; listAt < sweepLine.size(); listAt++)
    {
        sweepLine[listAt].setX(sweepLine[listAt].x() * propRadius);
        sweepLine[listAt].setY(sweepLine[listAt].y() * propRadius);
    }

    return sweepLine;
}

QList<QPointF> SweepLineBuilder::buildSweepLine(Propeller* propeller,
                                                int numberOfIterations)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> normedSweepAngleDegList;
    normedSweepAngleDegList.clear();

    for(int propAt = 0; propAt < propeller->blade()->numberOfStations();
        propAt++)
    {
        double radi = propeller->blade()->stationNonRadii().at(propAt);

        Station* station = propeller->blade()->station(radi);

        double sweepAngleDeg = station->sweepAngleDeg();
        normedSweepAngleDegList.append(QPointF(radi, sweepAngleDeg));
    }

    QList<QPointF> sweepLine =
            buildNormedSweepLine(normedSweepAngleDegList, numberOfIterations,
                                 propeller->blade()->nonHubRadius());

    //scale normed sweep line (radius from m in mm)
    for(int listAt = 0; listAt < sweepLine.size(); listAt++)
    {
        sweepLine[listAt].setX(sweepLine[listAt].x() *
                               propeller->radius() * 1000.0);
        sweepLine[listAt].setY(sweepLine[listAt].y() *
                               propeller->radius() * 1000.0);
    }

    return sweepLine;
}

QList<QPointF> SweepLineBuilder::buildSweepLine(QPointF hubPnt, QPointF tipPnt,
                                                double hubSweepAngleDeg,
                                                double tipSweepAngleDeg,
                                                int numberOfPoints)
{
    if(hubPnt.y() >= tipPnt.y())
    {
        "ERROR:\nHub Pnt has to be at a lower position than tipPnt!\nEmpty list"
        " will be returned";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    if(hubSweepAngleDeg <= 0.0 || hubSweepAngleDeg >= 90.0)
    {
        qDebug() << "ERROR:\nHubSweepAngleDeg Value is out of range!\nEmpty "
                    "list will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    if(tipSweepAngleDeg <= 0.0 || tipSweepAngleDeg >= 90.0)
    {
        qDebug() << "ERROR:\nTipSweepAngleDeg Value is out of range!\nEmpty "
                    "list will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }



    //get two directionvectors out of angles

    QPointF hubDirVect;
    hubDirVect.setY(1.0);
    hubDirVect.setX(-tan(hubSweepAngleDeg * (M_PI / 180.0)));

    QPointF tipDirVect;
    tipDirVect.setY(-1.0);
    tipDirVect.setX(-tan(tipSweepAngleDeg * (M_PI / 180.0)));

    if(hubDirVect.x() == tipDirVect.x() &&
       hubDirVect.y() == tipDirVect.y())
    {
        qDebug() << "ERROR:\nCreated directionVectors are equal!\nNo "
                    "intersection will be found!\nEmpty list will be returned!";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    //calculate intersection of two lines to get missing CP


    Intersectionfinder intersectionfinder;
    QPointF scndCP = intersectionfinder.findIntersection(hubPnt, hubDirVect,
                                                         tipPnt, tipDirVect);

    return buildSweepLine(hubPnt, scndCP, tipPnt, numberOfPoints);

}

QList<QPointF> SweepLineBuilder::buildSweepLine(const QPointF& hubPnt,
                                                const QPointF& scndCP,
                                                const QPointF& tipPnt,
                                                int numberOfPoints)
{
    QVector<QPointF> cps;
    cps.clear();
    cps.append(hubPnt);
    cps.append(scndCP);
    cps.append(tipPnt);

    int degree = 2;

    QVector<double> cpXs;
    cpXs.clear();
    cpXs.append(hubPnt.x());
    cpXs.append(scndCP.x());
    cpXs.append(tipPnt.x());

    QVector<double> cpYs;
    cpYs.clear();
    cpYs.append(hubPnt.y());
    cpYs.append(scndCP.y());
    cpYs.append(tipPnt.y());

    QVector<double> knotVector;
    knotVector.clear();
    knotVector.append(0.0);
    knotVector.append(0.0);
    knotVector.append(0.0);
    knotVector.append(1.0);
    knotVector.append(1.0);
    knotVector.append(1.0);

    GtBSplineAlgorithm splineBuilder;
    QList<QPointF> sweepLine;
    sweepLine.clear();

    double factor = 1.0 / (numberOfPoints - 1);
    for(int i = 0; i < numberOfPoints; i++)
    {
        QPointF sweepLinePnt;
        sweepLinePnt.setX(splineBuilder.BCurveValue(knotVector, cpXs,
                                                    degree + 1, 0, factor * i));
        sweepLinePnt.setY(splineBuilder.BCurveValue(knotVector, cpYs,
                                                    degree + 1, 0, factor * i));
        sweepLine.append(sweepLinePnt);
    }

    return sweepLine;

}












