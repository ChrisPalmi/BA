#ifndef COGSTACKINGSTRATEGY_H
#define COGSTACKINGSTRATEGY_H

#include "abstractairfoilstackingstrategy.h"
#include "geometrytransformation.h"
#include "airfoilparametercalculator.h"

/**
 * @brief The COGStackingStrategy class is a derived class from
 *        AbstractAirfoilStackingStrategy class. It provides functionalities to
 *        stack airfoils along radial axis at their center of gravity
 */
class COGStackingStrategy : public AbstractAirfoilStackingStrategy
{
public:

    /**
     * @brief COGStackingStrategy constructor
     */
    COGStackingStrategy();

    /**
     * @brief ~COGStackingStrategy destructor
     */
    ~COGStackingStrategy();

    /**
     * @brief stackAirfoils function provides the functionality to stack
     *        airfoils along radial axis at their center of gravity
     * @param airfoils (ordered pointlists which contain geometric information
     *        of airfoils)
     * @return stacked airfoils (ordered pointlists)
     */
    QList<QList<QVector3D>> stackAirfoils
    (const QList<QList<QVector3D>> &airfoils);


private:

    /**
     * @brief m_transformer (object of class GeometryTransformation which
     *        provides functionalities to transform geometries
     *        (ordered pointlists))
     */
    GeometryTransformation m_transformer;

    /**
     * @brief m_calculator (object of class AirfoilParameterCalculator which
     *        provides functionalities to calculate parameters of an airfoil,
     *        like the center of gravity, the area and so on
     */
    AirfoilParameterCalculator m_calculator;



};

#endif // COGSTACKINGSTRATEGY_H
