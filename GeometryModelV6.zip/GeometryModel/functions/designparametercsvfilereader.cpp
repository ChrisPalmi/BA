#include "designparametercsvfilereader.h"

#include <QFile>
#include <QDebug>
#include <QString>
#include <QStringList>


DesignParameterCSVFileReader::DesignParameterCSVFileReader()
{

}

DesignParameterCSVFileReader::~DesignParameterCSVFileReader()
{

}

QList<QPointF> DesignParameterCSVFileReader::readFile(const QString& filepath)
{
    QFile file(filepath);

    //read in file
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() << "ERROR:\n" << "File could not be read in!\n" <<
                    "Empty List will be returned!";
        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    //read all, split at line feeds and carriage return, skip whitespace
    QString fileData = file.readAll();
    file.close();

    QStringList lines = fileData.split(QRegExp("[\r\n]"),
                                       QString::SkipEmptyParts);
    lines.removeAll(QString(""));

    QList<QPointF> pointList;
    pointList.clear();

    //fill point list
    for(int i = 0; i < lines.size(); i++)
    {
        QString line = lines.at(i);
        QStringList lineList = line.split(QRegExp(","),
                                          QString::SkipEmptyParts);
        if(i != 0)
        {
            QPointF p(lineList.first().toDouble(), lineList.last().toDouble());
            pointList.append(p);
        }
    }

    return pointList;
}
