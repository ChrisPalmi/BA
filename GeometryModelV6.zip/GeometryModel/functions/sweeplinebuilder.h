#ifndef SWEEPLINEBUILDER_H
#define SWEEPLINEBUILDER_H

#include "designparametercsvfilereader.h"
#include "propeller.h"

#include <QList>
#include <QPointF>

/**
 * @brief The SweepLineBuilder class provides functionalities to create Sweep
 *        lines which can be used to set sweep lines in derived classes of
 *        AbstractAirfoilStackingStrategy to stack airfoils along this sweep
 *        line
 */
class SweepLineBuilder
{
public:

    /**
     * @brief SweepLineBuilder constructor
     */
    SweepLineBuilder();

    /**
     * @brief ~SweepLineBuilder destructor
     */
    ~SweepLineBuilder();

    /**
     * @brief buildNormedSweepLine function provides the functionality to build
     *        a normed sweep line (from nonhubRad < 1.0 to nondimensional tip
     *        (1.0)
     * @param sweepAngleDegList (ordered point list from tip to hub with
     *        sweep angles at r (x coordinates are filled with nondimensional
     *        radi and y coordinates are filled with sweep angles at this
     *        radius)
     * @param numberOfIterations (sweep line will be created iteratively and by
     *        using linear interpolation, the more iterations are choosen, the
     *        more exact the sweep line will be created)
     * @param nonHubRad (nondimensional hub radius of propeller which airfoils
     *        will be stacked along the created sweep line)
     * @return normed sweep line (ordered pointlist from hub to tip)
     */
    QList<QPointF> buildNormedSweepLine
    (const QList<QPointF> &sweepAngleDegList, int numberOfIterations,
     double nonHubRad);

    /**
     * @brief buildNormedSweepLine function provides the functionality to build
     *        a normed sweep line (from nonhubRad < 1.0 to nondimensional tip
     *        (1.0)
     * @param sweepAngleDegPath (path where sweep angle csv file can be found,
     *        For example: "D:/data/myCSVFiles/myFile.csv"
     * @param numberOfIterations (sweep line will be created iteratively and by
     *        using linear interpolation, the more iterations are choosen, the
     *        more exact the sweep line will be created)
     * @param nonHubRad (nondimensional hub radius of propeller which airfoils
     *        will be stacked along the created sweep line)
     * @return normed sweep line (ordered pointlist from hub to tip)
     */
    QList<QPointF> buildNormedSweepLine(QString sweepAngleDegPath,
                                        int numberOfIterations,
                                        double nonHubRad);

    /**
     * @brief buildSweepLine function provides the functionality to build
     *        a sweep line (from hub radius to tip radius)
     * @param sweepAngleDegList (ordered point list from tip to hub with
     *        sweep angles at r (x coordinates are filled with nondimensional
     *        radi and y coordinates are filled with sweep angles at this
     *        radius)
     * @param numberOfIterations (sweep line will be created iteratively and by
     *        using linear interpolation, the more iterations are choosen, the
     *        more exact the sweep line will be created)
     * @param nonHubRad (nondimensional hub radius of propeller which airfoils
     *        will be stacked along the created sweep line)
     * @param propRadius (radius of propeller, which airfoils will be stacked
     *        along created sweep line to scale a created normed sweep line)
     * @return sweep line (ordered pointlist from hub to tip)
     */
    QList<QPointF> buildSweepLine(const QList<QPointF> &sweepAngleDegList,
                                  int numberOfIterations, double nonHubRad,
                                  double propRadius);

    /**
     * @brief buildSweepLine function provides the functionality to build
     *        a sweep line (from hub radius to tip radius)
     * @param sweepAngleDegPath (path where sweep angle csv file can be found,
     *        For example: "D:/data/myCSVFiles/myFile.csv"
     * @param numberOfIterations (sweep line will be created iteratively and by
     *        using linear interpolation, the more iterations are choosen, the
     *        more exact the sweep line will be created)
     * @param nonHubRad(nondimensional hub radius of propeller which airfoils
     *        will be stacked along the created sweep line)
     * @param propRadius (radius of propeller, which airfoils will be stacked
     *        along created sweep line to scale a created normed sweep line)
     * @return sweep line (ordered pointlist from hub to tip)
     */
    QList<QPointF> buildSweepLine(QString sweepAngleDegPath,
                                  int numberOfIterations, double nonHubRad,
                                  double propRadius);

    /**
     * @brief buildSweepLine function provides the functionality to build
     *        a sweep line (from hub radius to tip radius)
     * @param propeller (object of class propeller, which provides geometric
     *        information of the propeller, which airfoils should be stacked
     *        along created sweep line
     * @param numberOfIterations sweep line will be created iteratively and by
     *        using linear interpolation, the more iterations are choosen, the
     *        more exact the sweep line will be created)
     * @return sweep line (ordered pointlist from hub to tip)
     */
    QList<QPointF> buildSweepLine(Propeller *propeller,
                                  int numberOfIterations);

    /**
     * @brief buildSweepLine function provides the functionality to build
     *        a sweep line (from hub radius to tip radius)
     * @param hubPnt (Point with coordinates where sweep line should start(hub))
     * @param tipPnt (Point with coordinates where sweep line should end(hub))
     * @param hubSweepAngleDeg (sweep angle (deg) at hub)
     * @param tipSweepAngleDeg (sweep angle (deg) at tip)
     * @param numberOfPoints (number of points of created sweep line)
     * @return sweep line
     */
    QList<QPointF> buildSweepLine(QPointF hubPnt, QPointF tipPnt,
                                  double hubSweepAngleDeg,
                                  double tipSweepAngleDeg, int numberOfPoints);

    /**
     * @brief buildSweepLine function provides the functionality to build
     *        a sweep line (from hub radius to tip radius)
     * @param hubPnt (Point with coordinates where sweep line should start(hub))
     * @param scndCP (second control point of b-spline which defines sweep line,
     *        the other two CP´s are hub- and tipPnt)
     * @param tipPnt (Point with coordinates where sweep line should end(hub))
     * @return sweep line
     */
    QList<QPointF> buildSweepLine(const QPointF& hubPnt, const QPointF& scndCP,
                                  const QPointF& tipPnt, int numberOfPoints);

private:

    /**
     * @brief m_reader (member variable of class DesignParameterCSVFileReader
     *        which provides functionalities to create an ordered point list
     *        with design parameters along the radial coordinates of a
     *        propeller)
     */
    DesignParameterCSVFileReader m_reader;

};

#endif // SWEEPLINEBUILDER_H
