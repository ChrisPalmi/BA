#include "abstractpropellershapebuilder.h"

AbstractPropellerShapeBuilder::AbstractPropellerShapeBuilder()
{

}
