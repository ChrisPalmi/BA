#include "abstractgeometryadapter.h"

AbstractGeometryAdapter::AbstractGeometryAdapter()
{

}
