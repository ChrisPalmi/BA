#include "abstractairfoilstackingstrategy.h"

AbstractAirfoilStackingStrategy::AbstractAirfoilStackingStrategy()
{

}
