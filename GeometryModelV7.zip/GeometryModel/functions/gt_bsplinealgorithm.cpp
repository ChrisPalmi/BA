/******************************************************************************
* Project:
*
* File:          bsplinealgorithm.cpp
*
* Version:       1.0
*
* Class:         BSplineAlgorithm
*
* Description:   Class containing algorithm for computing B splines
*
* Used classes:
*
* Hints:
*
*
*------------------------------------------------------------------------------
*
*   This class is free software; you can redistribute it and/or modify
*   it under the terms of the GNU Lesser General Public as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
******************************************************************************/

// std
#include <iostream>
#include <cstdlib>
#include <cmath>

// app
#include "gt_bsplinealgorithm.h"

#include <QList>
#include <QPointF>
#include <QDebug>

using namespace std;



/** Find span for the curveparameter of the spline */
int
GtBSplineAlgorithm::findSpan( const int degree,
                                  const double u,
                                  const QVector<double> U )
{

    if( u >= U[U.size()-degree-2] )
    {
        return U.size() - degree-2;
    }
    if(u <= U[degree+1] )
    {
        return degree;
    }

    //  static int mid=degree;

    /*  // look if u fits in the old interval
  if( u>=U[mid] || u<U[mid+1] ){ return mid; }*/

    // multiplicity of No. degree at both interval boundaries
    int low  = degree;
    int high = U.size() - degree - 1;
    // interval mid
    int mid = (low+high)/2;

    // do binary search
    while( u<U[mid] || u>=U[mid+1] )
    {
        if( u<U[mid] )
        {
            high = mid;
        }
        else
        {
            low = mid;
        }
        mid = (low+high)/2 ;
    }

    return mid ;
}

/** Compute curve coordinate at curve parameter u */
double
GtBSplineAlgorithm::BCurveValue(QVector<double> knot,
                                       QVector<double> CP,
                                       int order,
                                       int ideriv,
                                       double u )
{
    // auxiliary array
    static vector<double> work;
    work.resize( 3*order );

    // counting variables
    int j, jj;

    // check input parameter
    if (order < 1)
    {
      qDebug() << "BSplineValue: The order must be greater than or equal to one" << endl;
      exit(-1);
    }

    if(  static_cast<int>( CP.size() ) < order )
    {
      qDebug() << "BSplineValue: The number of control points must be greater than or equal to the order" << endl;
      exit(-1);
    }

    if (ideriv < 0 || ideriv >= order)
    {
      qDebug() << "BSplineValue: ideriv does not satisfy: 0 <= ideriv < order" << endl;
      exit(-1);
    }

    /* *** FIND *I* IN (K,N) SUCH THAT T(I) <= u < T(I+1) */
    /*     (OR, .LE. T(I+1) IF T(I) .LT. T(I+1) = T(N+1)). */
    int iSpan = findSpan( order-1, u, knot );
    ++iSpan; // increment for FORTRAN array indeces

//     qDebug << " ISPAN = " << iSpan << " :  "<< knot[iSpan] << " < " << u << " <= " <<knot[iSpan+1] << endl;

    if (u < knot[order-1])
    {
        qDebug() << "u = " << u;
        qDebug() << "knot[order-1] = " << knot[order-1];
        qDebug() << "BSplineValue: Parameter u is not greater than or equal to knot[order-1]" << endl;
        exit(-1);
    }

    /* *** DIFFERENCE THE COEFFICIENTS *IDERIV* TIMES */
    /*     WORK(I) = AJ(I), WORK(K+I) = DP(I), WORK(K+K+I) = DM(I), I=1.K */
    int imkpj;
    int imk = iSpan - order;
    for (j = 1; j <= order; ++j)
    {
      imkpj = imk + j;
      work[j-1] = CP[imkpj-1];
    }

    int ihi, kmj, ihmkmj;
    double  fkmj;
    if (ideriv > 0)
    { // derivative wanted
        for (j = 1; j <= ideriv; ++j)
        {
            kmj = order - j;
            fkmj = static_cast<double>( kmj );
            for (jj = 1; jj <= kmj; ++jj)
            {
                ihi = iSpan + jj;
                ihmkmj = ihi - kmj;
                work[jj-1] = (work[jj] - work[jj-1]) / (knot[ihi-1] - knot[ihmkmj-1]) * fkmj;
            }
        }
    }

    /* *** COMPUTE VALUE AT u IN knot interval (T(I),(T(I+1)) OF IDERIV-TH DERIVATIVE, */
    /*     GIVEN ITS RELEVANT B-SPLINE COEFF. IN AJ(1),...,AJ(K-IDERIV). */
    int km1 = order - 1;
    if (ideriv == km1)
    {
        return work[0];
    }

    int ipj, ip1mj;
    int kmider = order - ideriv;
    int ip1 = iSpan + 1;
    int kpk = order + order;
    int j1 = order + 1;
    int j2 = kpk + 1;
    for (j = 1; j <= kmider; ++j)
    {
      ipj = iSpan + j;
      work[j1-1] = knot[ipj-1] - u;
      ip1mj = ip1 - j;
      work[j2-1] = u - knot[ip1mj-1];
      ++j1;
      ++j2;
    }

    int ilo;
    int iderp1 = ideriv + 1;
    for (j = iderp1; j <= km1; ++j)
    {
        kmj = order - j;
        ilo = kmj;
        for (jj = 1; jj <= kmj; ++jj) {
            work[jj-1] =  (work[jj] * work[kpk + ilo - 1] + work[jj-1] * work[order + jj - 1])
                    / (work[kpk + ilo - 1] + work[order + jj - 1]);
            --ilo;
        }
    }

    return work[0];

}

QPointF
GtBSplineAlgorithm::curvePoint(double t,
                               QList<QPointF> control_points,
                               QVector<double> knot_vector,
                               double degree)
{
    QVector<double> cp_x;
    QVector<double> cp_y;

    for (int i = 0; i < control_points.size(); i++)
    {
        cp_x.append(control_points[i].x());
        cp_y.append(control_points[i].y());
    }

    double x = GtBSplineAlgorithm::BCurveValue(knot_vector, cp_x,
                                               degree + 1, 0, t);
    double y = GtBSplineAlgorithm::BCurveValue(knot_vector, cp_y,
                                               degree + 1, 0, t);

    return QPointF(x, y);
}

/** Computes all none-zero basis functions */
void
GtBSplineAlgorithm::NoneZeroBasisFuns(const int i,
                                           const double u, const int degree,
                                   QVector<double> U, vector<double>& N )
{
  double temp, saved ;

  static vector<double> left;
  static vector<double> right;

  // set size of arrays
  left.resize(degree+1);
  right.resize(degree+1);

  //  set size of array with none-zero base functions
  N.resize(degree+1) ;

  N[0] = 1.0;
  for( int j=1; j<degree+1; j++ )
  {
    left[j] = u - U[i+1-j];
    right[j] = U[i+j]-u;
    saved = 0.0;
    for( int r=0; r<j; r++ )
    {
      temp = N[r]/(right[r+1]+left[j-r]) ;
      N[r] = saved+right[r+1] * temp ;
      saved = left[j-r] * temp ;
    }
    N[j] = saved ;
  }
}

/** Computes all basis functions, i.e. including the zero ones */
void
GtBSplineAlgorithm::AllBasisFuns( const int iSpan, const double u,
                                       const int degree,
                                     QVector<double> U, vector<double>& N )
{
  // none zero basis functions
  static vector<double> NN;

  // set size of arrays
  NN.resize(degree+1);

  NoneZeroBasisFuns( iSpan, u, degree, U, NN );

  // copy all none zero functions
  for ( unsigned int i=0; i<N.size(); ++i )
  {
    N[i] = 0.0;
  }

  // copy all none zero functions
  for ( int j=0; j<degree+1; ++j )
  {
    N[ iSpan-degree+j ] = NN[j];
  }
}





