#include "intersectionfinder.h"

#include <QDebug>

Intersectionfinder::Intersectionfinder()
{

}

Intersectionfinder::~Intersectionfinder()
{

}

QPointF Intersectionfinder::findIntersection(const QPointF& firstPosVect,
                                             const QPointF& firstDirVect,
                                             const QPointF& secondPosVect,
                                             const QPointF& secondDirVect)
{
    if(firstDirVect.x() == 0.0 && firstDirVect.y() == 0.0)
    {
        qDebug() << "ERROR:\nFirstDirVect is null! No linear vector function!\n"
                    "QPointF(0.0, 0.0) will be returned!";
        setIntersectionFound(false);
        return QPointF(0.0, 0.0);
    }

    if(secondDirVect.x() == 0.0 && secondDirVect.y() == 0.0)
    {
        qDebug() << "ERROR:\nSecondDirVect is null!No linear vector function!\n"
                    "QPointF(0.0, 0.0) will be returned!";
        setIntersectionFound(false);
        return QPointF(0.0, 0.0);
    }

    if(firstDirVect.x() == 0.0 && secondDirVect.x() == 0.0)
    {
        qDebug() << "ERROR:\nThe two linear vector functions are parallel!\n"
                    "No intersection can be found!\nQPointF(0.0, 0.0) "
                    "will be returned!";
        setIntersectionFound(false);
        return QPointF(0.0, 0.0);
    }

    if(firstDirVect.y() == 0.0 && secondDirVect.y() == 0.0)
    {
        qDebug() << "ERROR:\nThe two linear vector functions are parallel!\n"
                    "No intersection can be found!\nQPointF(0.0, 0.0) "
                    "will be returned!";
        setIntersectionFound(false);
        return QPointF(0.0, 0.0);
    }

    if(firstDirVect.x() / secondDirVect.x() ==
       firstDirVect.y() / secondDirVect.y())
    {
        qDebug() << "ERROR:\nThe two linear vector functions are parallel!\n"
                    "No intersection can be found!\nQPointF(0.0, 0.0) "
                    "will be returned!";
        setIntersectionFound(false);
        return QPointF(0.0, 0.0);
    }



    QPointF firstDirVectCPY = firstDirVect;
    QPointF secondDirVectCPY = secondDirVect;

    QPointF firstPosVectCPY = firstPosVect;
    QPointF secondPosVectCPY = secondPosVect;

    //prepare CPY´s for subtraction method to solve linear equation

    firstDirVectCPY.setX(firstDirVectCPY.x() * firstDirVect.y());
    secondDirVectCPY.setX(secondDirVectCPY.x() * firstDirVect.y());
    firstPosVectCPY.setX(firstPosVectCPY.x() * firstDirVect.y());
    secondPosVectCPY.setX(secondPosVectCPY.x() * firstDirVect.y());

    firstDirVectCPY.setY(firstDirVectCPY.y() * firstDirVect.x());
    secondDirVectCPY.setY(secondDirVectCPY.y() * firstDirVect.x());
    firstPosVectCPY.setY(firstPosVectCPY.y() * firstDirVect.x());
    secondPosVectCPY.setY(secondPosVectCPY.y() * firstDirVect.x());

    double s = ((firstPosVectCPY.x() - firstPosVectCPY.y()) -
                (secondPosVectCPY.x() - secondPosVectCPY.y())) /
               (secondDirVectCPY.x() - secondDirVectCPY.y());
    double r;

    if(firstDirVect.x() != 0.0)
    {
        r = ((secondPosVect.x() + secondDirVect.x() * s) - firstPosVect.x())
            / firstDirVect.x();
    }
    else
    {
        r = ((secondPosVect.y() + secondDirVect.y() * s) - firstPosVect.y())
            / firstDirVect.y();
    }

    QPointF intersection(firstDirVect.x() * r + firstPosVect.x(),
                         firstDirVect.y() * r + firstPosVect.y());

    setIntersectionFound(true);

    return intersection;

}

bool Intersectionfinder::intersectionFound() const
{
    return m_intersectionFound;
}

void Intersectionfinder::setIntersectionFound(bool intersectionFound)
{
    m_intersectionFound = intersectionFound;
}

