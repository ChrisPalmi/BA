#ifndef ABSTRACTAIRFOILGEOMETRYBUILDER_H
#define ABSTRACTAIRFOILGEOMETRYBUILDER_H

#include <QList>
#include <QVector3D>

/**
 * @brief The AbstractAirfoilGeometryBuilder class is an abstract class to
 *        provide functionalaties to create 2D geometries of airfoils (Abstract
 *        class).
 */
class AbstractAirfoilGeometryBuilder
{
public:

    /**
     * @brief AbstractAirfoilGeometryBuilder constructor
     */
    AbstractAirfoilGeometryBuilder();

    /**
     * @brief ~AbstractAirfoilGeometryBuilder destructor
     */
    virtual ~AbstractAirfoilGeometryBuilder(){}

//    QList<QVector3D> buildGeometry();
};

#endif // ABSTRACTAIRFOILGEOMETRYBUILDER_H
