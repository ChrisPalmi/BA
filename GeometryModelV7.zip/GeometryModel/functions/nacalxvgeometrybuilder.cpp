#define _USE_MATH_DEFINES
#include <cmath>

#include "nacalxvgeometrybuilder.h"
#include "designparametercsvfilereader.h"
#include <QDebug>
#include <QFile>

#include "gt_splinefit.h"
#include "gt_rootfinder.h"
#include "math.h"

NACALXVGeometryBuilder::NACALXVGeometryBuilder()
{
    m_basicAirfoil = setUpBasicAirfoil();
    m_basicLEradius = 0.00687;
}

NACALXVGeometryBuilder::~NACALXVGeometryBuilder()
{

}

QList<QPointF> NACALXVGeometryBuilder::
buildGeometryNoCamber(double maxThicknessPC)
{
    //scaling factor -> max thickness of basic profile is
    //(at 40% chord) 4.996 percent chord
    //basic profile data is already divided with 100


    if(maxThicknessPC <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage <= 0.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    if(maxThicknessPC > 100.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage >= 100.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }


    //max thickness of m_basicairfoil is 0.04996
    double scalingFactor = ((1.0 / 0.04996) * maxThicknessPC) / 100.0;

    QList<QPointF> geomNoCamber;
    geomNoCamber.clear();

    //scale basic airfoil y coordinates to get normed, camberless airfoil
    //geometry with desired thickness
    for(int i = 0; i < m_basicAirfoil.size(); i++)
    {
        QPointF pnt(m_basicAirfoil[i].x(),
                    m_basicAirfoil[i].y() * scalingFactor);
        geomNoCamber.append(pnt);
    }

    return geomNoCamber;

}

QList<QPointF> NACALXVGeometryBuilder::buildGeometryNoCamber
    (double rad, QString thicknessRatioPath)
{

    if(rad < 0.0 || rad > 1.0)
    {
        qDebug() << "Error!\n" <<
                    "Rad is only accepted in ratio between 0 and 1!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    //get thickness information
    DesignParameterCSVFileReader reader;
    QList<QPointF> tbList = reader.readFile(thicknessRatioPath);

    //approximate thickness ratio spline
    GtSplineFit* myFitter = new GtSplineFit(3, 20, 0.01, 800);
    myFitter->fit(tbList);


    //find fitting u
    auto myFunc = [rad, myFitter](double u)
    {
        QPointF aPoint = myFitter->getCurvePoint(u);
        double diff = rad - aPoint.x();
        return diff;
    };

    RootFinder finder;
    double rootU = finder.Brent(myFunc, 0.0, 1.0);
    QPointF rootUPoint = myFitter->getCurvePoint(rootU);

    //call other buildGeometryNoCamber function with maxThicknessPC out of file
    //for given radius
    QList<QPointF> geomNOCamber = buildGeometryNoCamber(rootUPoint.y());

    return geomNOCamber;
}



QVector<QVector<QPointF>> NACALXVGeometryBuilder::buildCamberLineNNormals
(double cld, int numberOfPoints)
{


    if(cld >= 3.0 || cld <= -3.0)
    {
        qDebug() << "ERROR:\nCLD has to be a value between -3.0 and 3.0!\nEmpty"
                    " vector will be returned!";
        QVector<QVector<QPointF>> emptyVect;
        emptyVect.clear();

        return emptyVect;
    }

    if(numberOfPoints < 2)
    {
        qDebug() << "Error!\n" <<
                    "NumberOfPoints has to be >= 2!" <<
                    "Empty Vector will be returned";
        QVector<QVector<QPointF>> emptyVect;
        emptyVect.clear();

        return emptyVect;

    }

    if(numberOfPoints % 2 != 0)
    {
        qDebug() << "Warning!\n" <<
                    "Variable numberOfPoints can not be divided by 2!" <<
                    "Maybe your desired amount of points will not be generated";
    }

    //calculate necessary data
    //check "Praxisbericht T3000" of Christian Palmberg chapter
    //"Generierung der Profil Serie NACA 65/CA" for further information how
    //camber line is created
    double circArcCamberAngle = getCircArcCentralAngle(cld);
    double circRad = 50.0 / sin((circArcCamberAngle / 2.0) * (M_PI / 180.0));
    double rotationAngle = circArcCamberAngle / numberOfPoints;

    double yCenter;

    QVector<QPointF> circularArc;
    circularArc.clear();

    QVector<QPointF> normalsOfCamberLine;
    normalsOfCamberLine.clear();

    if(cld > 0.0)
    {
        yCenter = -50.0 / tan((circArcCamberAngle / 2.0) *
                              (M_PI / 180.0));

        //create circularArc

        QPointF startPnt(0.0, circRad);

        //calculate points of circularArc by rotating the start point

        //clockwise part of circularArc (anti clockwise direction)
        for(int i = numberOfPoints / 2; i >= 0; i--)
        {
            double xCoordinate = startPnt.x() *
                                 cos(rotationAngle * i * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 sin(rotationAngle * i * (M_PI / 180.0));

            double yCoordinate = startPnt.x() *
                                 - sin(rotationAngle * i * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 cos(rotationAngle * i * (M_PI / 180.0));

            QPointF p(xCoordinate, yCoordinate);
            circularArc.append(p);
            normalsOfCamberLine.append(p);
        }

        //anti clockwise part of circularArc (anti clockwise direction)
        for(int j = 1; j <= numberOfPoints / 2; j++)
        {
            double xCoordinate = startPnt.x() *
                                 cos(rotationAngle * j * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 - sin(rotationAngle * j * (M_PI / 180.0));

            double yCoordinate = startPnt.x() *
                                 sin(rotationAngle * j * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 cos(rotationAngle * j * (M_PI / 180.0));

            QPointF p(xCoordinate, yCoordinate);
            circularArc.append(p);
            normalsOfCamberLine.append(p);

        }
    }



    else
    {

        yCenter = 50.0 / tan((circArcCamberAngle / 2.0) * (M_PI / 180.0));

        //create circularArc

        QPointF startPnt(0.0, - circRad);

        //calculate points of circularArc by rotating the start point

        //anti clockwise part of circularArc (clockwise direction)
        for(int i = numberOfPoints / 2; i >= 0; i--)
        {
            double xCoordinate = startPnt.x() *
                                 cos(rotationAngle * i * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 - sin(rotationAngle * i * (M_PI / 180.0));

            double yCoordinate = startPnt.x() *
                                 sin(rotationAngle * i * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 cos(rotationAngle * i * (M_PI / 180.0));

            QPointF p(xCoordinate, yCoordinate);
            circularArc.append(p);
            normalsOfCamberLine.append(p);
        }

        //clockwise part of circularArc (clockwise direction)
        for(int j = 1; j <= numberOfPoints / 2; j++)
        {
            double xCoordinate = startPnt.x() *
                                 cos(rotationAngle * j * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 sin(rotationAngle * j * (M_PI / 180.0));

            double yCoordinate = startPnt.x() *
                                 - sin(rotationAngle * j * (M_PI / 180.0)) +
                                 startPnt.y() *
                                 cos(rotationAngle * j * (M_PI / 180.0));

            QPointF p(xCoordinate, yCoordinate);
            circularArc.append(p);
            normalsOfCamberLine.append(p);

        }
    }

    //move points in direction of center point of circle
    for(int l = 0; l < circularArc.size(); l++)
    {
        circularArc[l].setX((circularArc[l].x() + 50.0) / 100.0);
        circularArc[l].setY((circularArc[l].y() + yCenter) / 100.0);
    }

    QVector<QVector<QPointF>> camberNNormals;
    camberNNormals.append(circularArc);
    camberNNormals.append(normalsOfCamberLine);

    return camberNNormals;
}



double NACALXVGeometryBuilder::getCircArcCentralAngle(double cld)
{
    //circular arc center angle linear function is given in
    //"Cumpsty, N.A. Compressor aerodynamics. S.478 f. 1989"
    double gradient = 25.17715;
    double angle = gradient * cld;

    if(angle < 0)
    {
        angle = angle * - 1.0;
    }

    return angle;
}



QList<QPointF> NACALXVGeometryBuilder::buildGeometry
    (double cld, double maxThicknessPC, int pointsPerSide)
{
    if(cld == 0.0)
    {
        QList<QPointF> geom = buildGeometryNoCamber(maxThicknessPC);
        return geom;
    }

    if(cld >= 3.0 || cld <= -3.0)
    {
        qDebug() << "ERROR:\nCLD has to be a value between -3.0 and 3.0!\nEmpty"
                    " list will be returned!";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }


    if(maxThicknessPC <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage <= 0.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    if(maxThicknessPC > 100.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage >= 100.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "PointsPerSide has to be >= 2!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    //create camber line and thickness distribution

    QVector<QVector<QPointF>> camberLineNNormals =
            buildCamberLineNNormals(cld, pointsPerSide);


    QList<QPointF> thicknessDistribution =
            buildGeometryNoCamber(maxThicknessPC);


    //delete pressure side for thickness distribution

    int thickDistSize = thicknessDistribution.size();
    for(int i = thickDistSize - 1; i >= 0; i--)
    {
        if(thicknessDistribution[i].y() < 0.0)
        {
            thicknessDistribution.removeAt(i);
        }
    }

    thicknessDistribution.removeLast();

    //Approximate b-spline through thickness distribution

    GtSplineFit *fitter = new GtSplineFit(3, 20, 0.01, 800);
    fitter->fit(thicknessDistribution);

    //create geometry
    QList<QPointF> nacaLXVGeom;
    nacaLXVGeom.clear();

    QList<QPointF> pressureSide;
    pressureSide.clear();

    for(int camberLnAt = 0; camberLnAt <= camberLineNNormals[0].size() - 1;
        camberLnAt++)
    {
        QPointF normal = camberLineNNormals[1].at(camberLnAt);
        QPointF camberPnt = camberLineNNormals[0].at(camberLnAt);

        if(camberLnAt == 0)
        {
            QPointF thicknessPnt = QPointF(1.0, 0.0);
            nacaLXVGeom.append(thicknessPnt);
        }

        else if(camberLnAt == camberLineNNormals[0].size() - 1)
        {
            QPointF thicknessPnt = QPointF(0.0, 0.0);
            nacaLXVGeom.append(thicknessPnt);
            pressureSide.append(thicknessPnt);
        }

        else
        {
            double xCoor = camberPnt.x();

            //get fitting thickness distribution

            auto myFunc = [xCoor, fitter](double u)
            {
                QPointF aPoint = fitter->getCurvePoint(u);
                double diff = xCoor - aPoint.x();
                return diff;
            };

            RootFinder finder;
            double rootU = finder.Brent(myFunc, 0.0, 1.0);

            QPointF thicknessPnt = fitter->getCurvePoint(rootU);

            double normalLength = sqrt(pow(normal.x(), 2) + pow(normal.y(), 2));

            double factor;

            if(normalLength == 0)
            {
                factor = 0.0;
            }
            else
            {
                factor = thicknessPnt.y() / normalLength;
            }

            //create pressure and suction side and combine them to full geometry

            if(cld > 0.0)
            {

                double xCoorSS = camberPnt.x() + factor * normal.x();
                double yCoorSS = camberPnt.y() + factor * normal.y();

                QPointF suctionSidePoint(xCoorSS, yCoorSS);
                nacaLXVGeom.append(suctionSidePoint);

                double xCoorPS = camberPnt.x() - factor * normal.x();
                double yCoorPS = camberPnt.y() - factor * normal.y();

                QPointF pressureSidePnt(xCoorPS, yCoorPS);
                pressureSide.append(pressureSidePnt);

            }
            else
            {
                double xCoorPS = camberPnt.x() + factor * normal.x();
                double yCoorPS = camberPnt.y() + factor * normal.y();

                QPointF pressureSidePoint(xCoorPS, yCoorPS);
                pressureSide.append(pressureSidePoint);

                double xCoorSS = camberPnt.x() - factor * normal.x();
                double yCoorSS = camberPnt.y() - factor * normal.y();

                QPointF suctionSidePnt(xCoorSS, yCoorSS);
                nacaLXVGeom.append(suctionSidePnt);
            }
        }
    }

    for(int psAt = pressureSide.size() - 2; psAt >= 0; psAt--)
    {
        nacaLXVGeom.append(pressureSide.at(psAt));
    }


    return nacaLXVGeom;
}


QList<QPointF> NACALXVGeometryBuilder::setUpBasicAirfoil()
{
    //basic airfoil is out of "Cumpsty, N.A. Compressor aerodynamics. S.478 f."

    QList<QPointF> basicAirfoil;
    basicAirfoil.clear();

    basicAirfoil << QPointF(1.0, 0.0) << QPointF(0.95, 0.00306) <<
                    QPointF(0.9, 0.0081) << QPointF(0.85, 0.01385) <<
                    QPointF(0.8, 0.01987) << QPointF(0.75, 0.02584) <<
                    QPointF(0.7, 0.03156) << QPointF(0.65, 0.03682) <<
                    QPointF(0.6, 0.04146) << QPointF(0.55, 0.0453) <<
                    QPointF(0.5, 0.04812) << QPointF(0.45, 0.04963) <<
                    QPointF(0.4, 0.04996) << QPointF(0.35, 0.04924) <<
                    QPointF(0.3, 0.0476) << QPointF(0.25, 0.04503) <<
                    QPointF(0.2, 0.04143) << QPointF(0.15, 0.03666) <<
                    QPointF(0.1, 0.03040) << QPointF(0.075, 0.02647) <<
                    QPointF(0.05, 0.02177) << QPointF(0.025, 0.01574) <<
                    QPointF(0.0125, 0.01169) << QPointF(0.0075, 0.00932) <<
                    QPointF(0.005, 0.00772) << QPointF(0.0, 0.0);

    int currentSize = basicAirfoil.size();

    for(int i = currentSize - 2; i >= 0; i--)
    {
        QPointF p(basicAirfoil[i].x(),
                  basicAirfoil[i].y() * - 1.0);

        basicAirfoil << p;

    }

    return basicAirfoil;
}

double NACALXVGeometryBuilder::basicLEradius() const
{
    return m_basicLEradius;
}

bool NACALXVGeometryBuilder::
createAirfoilExperimentFile(double cld, double maxThicknessPC,
                            int pointsPerSide, QString filepath)
{

    if(cld >= 3.0 || cld <= -3.0)
    {
        qDebug() << "ERROR:\nCLD has to be a value between -3.0 and 3.0!\n"
                    "False will be returned!\nNo file will be created!";

        return false;

    }


    if(maxThicknessPC <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage <= 0.0 is not accepted!" <<
                    "False will be returned!\nNo file will be created!";

        return false;

    }

    if(maxThicknessPC > 100.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage >= 100.0 is not accepted!" <<
                    "False will be returned\nNo file wil be created!";
        return false;
    }

    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "PointsPerSide has to be >= 2!\n" <<
                    "False will be returned!\nNo file wil be created!";

        return false;

    }


    //create geometry of airfoil for experiment file
    QList<QPointF> geometry = buildGeometry(cld, maxThicknessPC, pointsPerSide);

    if(geometry.isEmpty())
    {
        qDebug() << "ERROR:\nEmpty geometry was created!\nFalse will be"
                    " returned! No file will be created!";
        return false;
    }

    //create experiment file

    QString cldString = QString::number(cld);
    QString thicknessString = QString::number(maxThicknessPC);

    QString airfoilName = "NACA65-(" + cldString + ")" + thicknessString;

    QFile experimentFile(filepath);

    if (experimentFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&experimentFile);

        out << "<Airfoil name=\"" << airfoilName << "\">\n";
        out << " <Geometry>\n";

        for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
        {
            out << "  <CoordinatePoint type=\"double\" y=\"" <<
                   geometry[geomAt].y() << "\" x=\"" <<
                   geometry[geomAt].x() << "\"/>\n";
        }

        out << " </Geometry>\n";

        out << "</Airfoil>\n";

        return true;

    }

    else
    {
        qDebug() << "ERROR: File could not be created!";
        return false;
    }
}

bool NACALXVGeometryBuilder::createAirfoilFile(double cld,
                                               double maxThicknessPC,
                                               int pointsPerSide,
                                               QString filepath)
{

    if(cld >= 3.0 || cld <= -3.0)
    {
        qDebug() << "ERROR:\nCLD has to be a value between -3.0 and 3.0!\n"
                    "False will be returned!\nNo file will be created!";

        return false;

    }


    if(maxThicknessPC <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage <= 0.0 is not accepted!" <<
                    "False will be returned!\nNo file will be created!";

        return false;

    }

    if(maxThicknessPC > 100.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Percentage >= 100.0 is not accepted!" <<
                    "False will be returned\nNo file wil be created!";
        return false;
    }

    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "PointsPerSIde has to be >= 2!\n" <<
                    "False will be returned!\nNo file wil be created!";

        return false;

    }

    //create geometry of airfoil
    QList<QPointF> geometry = buildGeometry(cld, maxThicknessPC, pointsPerSide);

    if(geometry.isEmpty())
    {
        qDebug() << "ERROR:\nEmpty geometry was created!\nFalse will be"
                    " returned! No file will be created!";
        return false;
    }

    //create experiment file

    QFile experimentFile(filepath);

    if (experimentFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&experimentFile);

        for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
        {
            out <<"     " << geometry[geomAt].x() << "    " <<
                   geometry[geomAt].y() << "\n";
        }

        return true;
    }

    else
    {
        qDebug() << "ERROR: File could not be created!";
        return false;
    }
}


QList<QPointF> NACALXVGeometryBuilder::basicAirfoil() const
{
    return m_basicAirfoil;
}

