#define _USE_MATH_DEFINES
#include <cmath>

#include <QDebug>

#include "airfoilparametercalculator.h"
#include "math.h"

AirfoilParameterCalculator::AirfoilParameterCalculator()
{

}

AirfoilParameterCalculator::~AirfoilParameterCalculator()
{

}

double AirfoilParameterCalculator::
calculateChordLength(const QList<QVector3D>& airfoil)
{
    if(airfoil.isEmpty())
    {
        qDebug() << "ERROR:\nAirfol is empty!\nChordLength of 0.0 will be "
                    "returned!";
        return 0.0;
    }

    //airfoil leading edge is at (0|0) and trailing edge is airfoil[0]
    double chordLength = sqrt(pow(airfoil[0].x(), 2.0) +
                              pow(airfoil[0].y(), 2.0));
    return chordLength;
}

double AirfoilParameterCalculator::
calculateBladeAngleDeg(const QList<QVector3D>& airfoil)
{
    if(airfoil.isEmpty())
    {
        qDebug() << "ERROR:\nAirfol is empty!\nBladeAngleDeg of 0.0 will be "
                    "returned!";
        return 0.0;
    }

    if(airfoil[0].x() == 0.0)
    {
        qDebug() << "ERROR:\nX coordinate of first point of airfoil "
                    "(trailing edge) is 0!\nBut in this algorithm the "
                    "leading edge of the airfoil is supposed to be at "
                    "x coordinate 0.0!\nBladeAngleDeg of 0.0 will be returned!";
        return 0.0;

    }

    //airfoil leading edge is at (0|0) and trailing edge is airfoil[0]

    double bladeAngleDeg = atan(airfoil[0].y() / airfoil[0].x()) *
                           (180.0 / M_PI);

    //if third or fourth quadrant
    if(airfoil[0].x() < 0.0)
    {
        //third quadrant
        if(airfoil[0].y() < 0.0)
        {
            return -180.0 + bladeAngleDeg;
        }
        //fourth quadrant
        else
        {
            return 180.0 + bladeAngleDeg;
        }
    }

    else
    {
        return bladeAngleDeg;
    }
}

QVector3D AirfoilParameterCalculator::
calculateCOG(const QList<QVector3D>& polygon)
{

    if(polygon.isEmpty())
    {
        qDebug() << "ERROR:\nPolygon is empty!\nOrigin will be returned!";

        return QVector3D(0.0, 0.0, 0.0);
    }


    QList<QVector3D> closedPolygon = polygon;

    //check if polygon is closed
    if(closedPolygon.first().x() != closedPolygon.last().x() ||
       closedPolygon.first().y() != closedPolygon.last().y())
    {
        closedPolygon.append(closedPolygon.first());
    }

    double zCoor = polygon.at(0).z();

    double area = calculateArea(polygon);

    double x = 0.0;
    double y = 0.0;

    //center of gravity is calculated with trapeze equation
    for(int i = 0; i < closedPolygon.size() - 1; ++i)
        x += (closedPolygon.at(i).x() + closedPolygon.at(i + 1).x()) *
             (closedPolygon.at(i).x() * closedPolygon.at(i + 1).y() -
              closedPolygon.at(i + 1).x() * closedPolygon.at(i).y());

    for(int j = 0; j < closedPolygon.size() - 1; ++j)
        y += (closedPolygon.at(j).y() + closedPolygon.at(j + 1).y()) *
             (closedPolygon.at(j).x() * closedPolygon.at(j + 1).y() -
              closedPolygon.at(j + 1).x() * closedPolygon.at(j).y());

    return QVector3D(x / (6.0 * area), y / (6.0 * area), zCoor);

}

double AirfoilParameterCalculator::
calculateArea(const QList<QVector3D>& polygon)
{
    if(polygon.isEmpty())
    {
        qDebug() << "ERROR:\nPolygon is empty!\nValue of area will be set to "
                    "0.0 and will be returned!";
        return 0.0;
    }

    double area = 0.0;

    QList<QVector3D> closedPolygon = polygon;

    //check if polygon is closed
    if(closedPolygon.first().x() != closedPolygon.last().x() ||
       closedPolygon.first().y() != closedPolygon.last().y())
    {
        closedPolygon.append(polygon.first());
    }

    for(int i = 0; i < closedPolygon.size() - 1; i++)
    {
        QVector3D pI = closedPolygon.at(i);
        QVector3D pIplusOne = closedPolygon.at(i + 1);
        area += (pI.x() * pIplusOne.y()) - (pIplusOne.x() * pI.y());
    }

    area = area * 0.5;
    return area;
}
