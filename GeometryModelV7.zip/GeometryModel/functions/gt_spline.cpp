/* GTlab - Gas Turbine laboratory
 * Source File: gt_spline.cpp
 * copyright 2009-2015 by DLR
 *
 *  Created on: Tu Sep 1 2015
 *      Author: Maximilian Vieweg
 *		 Email: maximilian.vieweg@dlr.de
 */


// Datamodel class
// offers function "getCurvePoint" that returns

#include "gt_spline.h"
#include "gt_bsplinealgorithm.h"
#include <QDebug>

GtSpline::GtSpline()
{

}

GtSpline::GtSpline(QList<QPointF> Cp, int N, QVector<double> knot)
{
    setControlPoints(Cp);
    setDegree(N);
    setKnotVec(knot);
}

void
GtSpline::setDegree(int degree)
{
    m_degree = degree;
}

int
GtSpline::degree()
{
    return m_degree;
}

void GtSpline::setControlPoints(QList<QPointF> controlP)
{
    m_controlPoints = controlP;
}

void
GtSpline::setControlPoints(int mark, QPointF controlP)
{
    m_controlPoints[mark] = controlP;
}

QList<QPointF>
GtSpline::Cp()
{
    return m_controlPoints;
}

void
GtSpline::setKnotVec(QVector<double> knotVec)
{
    m_knotVec = knotVec;
}

QVector<double>
GtSpline::KnotVec()
{
    return m_knotVec;
}

QPointF
GtSpline::curvePoint(double t)
{
    QVector<double> cp_x;
    QVector<double> cp_y;

    for(int i = 0; i < m_controlPoints.size(); i++)
    {
        cp_x.append(m_controlPoints[i].x());
        cp_y.append(m_controlPoints[i].y());
    }

    double x = GtBSplineAlgorithm::BCurveValue(m_knotVec, cp_x, m_degree, 0, t);
    double y = GtBSplineAlgorithm::BCurveValue(m_knotVec, cp_y, m_degree, 0, t);

    return QPointF(x, y);
}
