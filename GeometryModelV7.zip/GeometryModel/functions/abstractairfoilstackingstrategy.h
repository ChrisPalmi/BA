#ifndef ABSTRACTAIRFOILSTACKINGSTRATEGY_H
#define ABSTRACTAIRFOILSTACKINGSTRATEGY_H

#include "propeller.h"

#include <QList>
#include <QVector3D>


/**
 * @brief The AbstractFaedelStrategy class provides functionalities to stack
 *        airfoils of a propeller along radial axis (Abstract class).
 */
class AbstractAirfoilStackingStrategy
{
public:
    /**
     * @brief AbstractFaedelStrategy constructor
     */
    AbstractAirfoilStackingStrategy();

    /**
     * @brief ~AbstractFaedelStrategy destructor
     */
    virtual ~AbstractAirfoilStackingStrategy() {}

    /**
     * @brief faedelProfiles stacks airfoils along radial axis
     * @param profiles (list of 2D airfoils(ordered point lists))
     * @return list of stacked airfoils(ordered point lists)
     */
    virtual QList<QList<QVector3D>> stackAirfoils
    (const QList<QList<QVector3D>> &airfoils) = 0;
};

#endif // ABSTRACTAIRFOILSTACKINGSTRATEGY_H
