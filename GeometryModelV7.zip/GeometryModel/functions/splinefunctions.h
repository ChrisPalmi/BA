#ifndef SPLINEFUNCTIONS_H
#define SPLINEFUNCTIONS_H

#include "QPointF"
#include "QVector"
#include "QtGlobal"
//#include <qwt_plot.h>
//#include <qwt_plot_curve.h>


class SplineFunctions
{


public:
    SplineFunctions();
    ~SplineFunctions();

    void test(int amountCP, int degree, qreal u, int i, int p);
    QPointF getCU(int amountCP, int degree, qreal u);
    QVector<QPointF> getMultipleCUs(int amountCP, int degree, int amountCU);
    QVector<QPointF> getAllCPs();
    void recreateCPVector(QVector<QPointF> newVector);
    void setCPoint(qreal xCoor, qreal yCoor);





    QVector<qreal> getKnotVector() const;

private:

    //-------------------------------------------
    //----------Member-Variables-----------------
    //-------------------------------------------

    //--------------universal--------------------
    int m_m;

    //-------------Cox-de-Boor-------------------
    QVector<qreal> m_knotVector;
    QVector<QVector<bool > > m_TriangularScheme;
    bool m_paramsSet;
    bool m_allSet;

    //-----------------C(u)----------------------
    QVector<QPointF> m_AllControlPoints;



    //-------------------------------------------
    //-------------Procedures--------------------
    //-------------------------------------------

    //--------------universal--------------------
    void clearAllParams();

    //-------------Cox-de-Boor-------------------
    void setCDBParams(int amountCP, int degree);
    void setTriangularScheme();
    qreal coxDeBoorAlgorithm(int amountCP, int p, qreal u, int i);

    //-----------------C(u)----------------------
    QPointF pointOfFunction(int amountCP, int degree, qreal u);
    void setAllCPoints(int amountCP);


};

#endif // SPLINEFUNCTIONS_H
