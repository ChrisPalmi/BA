#include "nacaxvigeometrybuilder.h"

#include "gt_splinefit.h"
#include "gt_rootfinder.h"
#include "math.h"

#include <QFile>

NACAXVIGeometryBuilder::NACAXVIGeometryBuilder()
{

}

NACAXVIGeometryBuilder::~NACAXVIGeometryBuilder()
{

}

QList<QPointF> NACAXVIGeometryBuilder::buildGeometry(int pointsPerSide,
                                                     double thicknessRatio,
                                                     double cld)
{

    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "pointsPerSide < 2 is not accepted!" <<
                    "Empty List will be returned";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }


    if(thicknessRatio <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio <= 0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    if(thicknessRatio > 1.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio > 1.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    if(cld <= -3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD < -3.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    if(cld >= 3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD >= 3.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    QList<QPointF> thicknessList = thicknessDistribution(pointsPerSide + 1,
                                                         thicknessRatio);

    QList<QPointF> camberLineList = camberLine(pointsPerSide + 1, cld);

    QList<QPointF> camberDerivativeList =
            derivativesOfCamberLine(pointsPerSide + 1, cld);

    //   create geometry by going through thickness list in reversed order
    //   this will ensure the standard point order of a profile in Propster from
    //   trailing edge to leading edge in anti clockwise direction


    QList<QPointF> geometry;
    geometry.clear();

    //suction side
    for(int listAt = thicknessList.size() - 1; listAt >= 0; listAt--)
    {
        QPointF deriv = camberDerivativeList.at(listAt);
        QPointF camberPnt = camberLineList.at(listAt);
        QPointF thicknessPnt = thicknessList.at(listAt);

        double normalLength = sqrt(pow(deriv.y(), 2) + 1);
        double factor;

        if(normalLength == 0)
        {
            factor = 0.0;
        }
        else
        {
            factor = thicknessPnt.y() / normalLength;
        }

        double xCoor = camberPnt.x() + factor * deriv.y() * - 1.0;
        double yCoor = camberPnt.y() + factor * 1.0;

        QPointF suctionSidePoint(xCoor, yCoor);
        geometry.append(suctionSidePoint);
    }

    //pressure side
    for(int lAt = 1; lAt < thicknessList.size() - 1; lAt++)
    {
        QPointF deriv = camberDerivativeList.at(lAt);
        QPointF camberPnt = camberLineList.at(lAt);
        QPointF thicknessPnt = thicknessList.at(lAt);

        double normalLength = sqrt(pow(deriv.y(), 2) + 1);
        double factor;

        if(normalLength == 0)
        {
            factor = 0.0;
        }
        else
        {
            factor = thicknessPnt.y() / normalLength;
        }

        double xCoor = camberPnt.x() - factor * deriv.y() * - 1.0;
        double yCoor = camberPnt.y() - factor * 1.0;

        QPointF pressureSidePoint(xCoor, yCoor);
        geometry.append(pressureSidePoint);

    }

    qDebug() << geometry.size();

    return geometry;

}

QList<QPointF> NACAXVIGeometryBuilder::
buildGeometryNoCamber(int pointsPerSide, double thicknessRatio)
{

    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "pointsPerSide < 2 is not accepted!" <<
                    "Empty List will be returned";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }


    if(thicknessRatio <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio <= 0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    if(thicknessRatio > 1.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio > 1.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }



    QList<QPointF> thicknessDist = thicknessDistribution(pointsPerSide,
                                                         thicknessRatio);
    QList<QPointF> geom;
    geom.clear();

    for(int i = thicknessDist.size() - 1; i >= 0; i++)
    {
        geom.append(thicknessDist[i]);
    }

    for(int j = 1; j < thicknessDist.size(); j++)
    {
        geom.append(QPointF(thicknessDist[j].x(),
                            thicknessDist[j].y() * - 1.0));
    }

    return geom;
}



QList<QPointF> NACAXVIGeometryBuilder::
thicknessDistribution(int pointsPerSide, double thicknessRatio)
{

    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "pointsPerSide < 2 is not accepted!" <<
                    "Empty List will be returned";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }


    if(thicknessRatio <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio <= 0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    if(thicknessRatio > 1.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio > 1.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }


    //create thickness distribution vector
    QList<QPointF> thicknessDist;
    thicknessDist.clear();

    double factor = 1.0 / (pointsPerSide - 1);
    double lastThickness = -0.1;
    bool activateEquationYII = false;


    //equations given in "Stefko, G./ Jeracki, R. Wind-Tunnel Results of
    //High-Speed Propellers at Takeoff, Climb and Landing Mach Numbers"
    for(int i = 0; i < pointsPerSide - 1; i++)
    {
        double currentX = factor * i;
        if(activateEquationYII == false)
        {
            double thickness = thicknessRatio *
                               (0.989665 * pow(currentX, 0.5) -
                                0.23925 * currentX -
                                0.041 * pow(currentX, 2) -
                                0.5594 * pow(currentX, 3));

            if(lastThickness < thickness)
            {
                QPointF pnt(currentX, thickness);
                thicknessDist.append(pnt);
                lastThickness = thickness;
            }

            else
            {
                activateEquationYII = true;
                thickness = thicknessRatio * (0.01 +
                                              2.325 * (1.0 - currentX) -
                                              3.42 * pow(1.0 - currentX, 2) +
                                              1.46 * pow(1.0 - currentX, 3));
                QPointF pnt(currentX, thickness);
                thicknessDist.append(pnt);
            }



        }
        else
        {
            double thickness = thicknessRatio * (0.01 +
                                                 2.325 * (1.0 - currentX) -
                                                 3.42 * pow(1.0 - currentX, 2) +
                                                 1.46 * pow(1.0 - currentX, 3));
            QPointF pnt(currentX, thickness);
            thicknessDist.append(pnt);
        }
    }

    thicknessDist.append(QPointF(1.0, 0.0));

    return thicknessDist;

}




QList<QPointF> NACAXVIGeometryBuilder::camberLine(int numberOfPoints,
                                                  double cld)
{

    if(numberOfPoints < 2)
    {
        qDebug() << "Error!\n" <<
                    "Negative variable pointsPerSide is not accepted!" <<
                    "Empty List will be returned";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    if(cld <= -3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD < -3.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    if(cld >= 3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD >= 3.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    //create camber line
    QList<QPointF> camberLineList;
    camberLineList.clear();

    double factor = 1.0 / (numberOfPoints - 1);
    for(int j = 0; j < numberOfPoints; j++)
    {
        double currentX = factor * j;

        if(j == 0 || j == numberOfPoints - 1)
        {
            double yCoor = 0.0;

            QPointF pnt(currentX, yCoor);
            camberLineList.append(pnt);
        }

        else
        {
            double yCoor = - 0.079577 * cld *
                           (currentX * log(currentX) +
                           (1 - currentX) * log(1 - currentX));

            QPointF pnt(currentX, yCoor);
            camberLineList.append(pnt);
        }
    }

    return camberLineList;

}



QList<QPointF> NACAXVIGeometryBuilder::
derivativesOfCamberLine(int numberOfPoints, double cld)
{
    if(numberOfPoints < 2)
    {
        qDebug() << "Error!\n" <<
                    "Negative variable pointsPerSide is not accepted!" <<
                    "Empty List will be returned";

        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;

    }

    if(cld <= -3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD < -3.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    if(cld >= 3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD >= 3.0 is not accepted!" <<
                    "Empty List will be returned";
        QList<QPointF> emptyList;
        emptyList.clear();

        return emptyList;
    }

    //create camber line

    QList<QPointF> derivativeList;
    derivativeList.clear();

    double factor = 1.0 / (numberOfPoints - 1);
    for(int j = 0; j < numberOfPoints; j++)
    {
        double currentX = factor * j;

        if(j == 0 || j == numberOfPoints - 1)
        {
            double yCoor = 0;

            QPointF pnt(currentX, yCoor);
            derivativeList.append(pnt);
        }

        //equations given in "Stefko, G./ Jeracki, R. Wind-Tunnel Results of
        //High-Speed Propellers at Takeoff, Climb and Landing Mach Numbers"
        else
        {
            double yCoor = - 0.079577 * cld * (log(currentX) -
                                               log(1 - currentX));
            QPointF pnt(currentX, yCoor);
            derivativeList.append(pnt);
        }
    }

    return derivativeList;
}


double NACAXVIGeometryBuilder::getLeadingEdgeRadius(double thicknessRatio)
{
    //calculate leading edge radius


    double tbInPercent = thicknessRatio * 100.0;
    //equation given in "Stefko, G./ Jeracki, R. Wind-Tunnel Results of
    //High-Speed Propellers at Takeoff, Climb and Landing Mach Numbers"

    double leRad = pow(0.004897, 2) * pow(tbInPercent, 2);

    return leRad;

}

bool NACAXVIGeometryBuilder::createAirfoilExperimentFile(double cld,
                                                         double thicknessRatio,
                                                         int pointsPerSide,
                                                         double diameter,
                                                         QString filepath)
{
    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "PointsPerSide < 2 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;

    }


    if(thicknessRatio <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio <= 0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;

    }

    if(thicknessRatio > 1.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio > 1.0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;
    }

    if(cld <= -3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD < -3.0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;
    }

    if(cld >= 3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD >= 3.0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;
    }

    if(diameter <= 0.0)
    {
        qDebug() << "ERROR:\nDiameter has to be > 0.0!\nFalse will be returned "
                    "and no file will be created!";
        return false;
    }

    //create geometry of airfoil for experiment file
    QList<QPointF> geometry = buildGeometry(pointsPerSide, thicknessRatio, cld);

    if(geometry.isEmpty())
    {
        qDebug() << "ERROR:\nCreated geometry is empty!\n"
                    "False will be returned and no file will be created!";
        return false;
    }
    //create experiment file

    QString cldString = QString::number(cld);
    double maxThicknessPC = thicknessRatio * diameter * 100.0;
    QString thicknessString = QString::number(maxThicknessPC);

    QString airfoilName = "NACA65-(" + cldString + ")" + thicknessString;

    QFile experimentFile(filepath);

    if (experimentFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&experimentFile);

        out << "<Airfoil name=\"" << airfoilName << "\">\n";
        out << " <Geometry>\n";

        for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
        {
            out << "  <CoordinatePoint type=\"double\" y=\"" <<
                   geometry[geomAt].y() << "\" x=\"" <<
                   geometry[geomAt].x() << "\"/>\n";
        }

        out << " </Geometry>\n";

        out << "</Airfoil>\n";

        return false;

    }

    else
    {
        qDebug() << "ERROR: File could not be created!";
        return false;
    }
}

bool NACAXVIGeometryBuilder::createAirfoilFile(double cld,
                                               double thicknessRatio,
                                               int pointsPerSide,
                                               QString filepath)
{
    if(pointsPerSide < 2)
    {
        qDebug() << "Error!\n" <<
                    "PointsPerSide < 2 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;

    }


    if(thicknessRatio <= 0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio <= 0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;

    }

    if(thicknessRatio > 1.0)
    {
        qDebug() << "Error!\n" <<
                    "Thickness Ratio > 1.0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;
    }

    if(cld <= -3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD < -3.0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;
    }

    if(cld >= 3.0)
    {
        qDebug() << "ERROR!\n" <<
                    "CLD >= 3.0 is not accepted!" <<
                    "False will be returned and no file will be created!";
        return false;
    }



    //create geometry of airfoil
    QList<QPointF> geometry = buildGeometry(pointsPerSide, thicknessRatio, cld);

    if(geometry.isEmpty())
    {
        qDebug() << "ERROR:\nCreated geometry is empty!\n"
                    "False will be returned and no file will be created!";
        return false;
    }

    //create experiment file

    QFile experimentFile(filepath);

    if (experimentFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&experimentFile);

        for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
        {
            out <<"     " << geometry[geomAt].x() << "    " <<
                   geometry[geomAt].y() << "\n";
        }

        return true;
    }

    else
    {
        qDebug() << "ERROR: File could not be created!";
        return false;
    }
}
