#include "sweeplinebuilder.h"

#include "gtest.h"

class test_SweepLineBuilder : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }
};


TEST_F(test_SweepLineBuilder, errorHandling)
{
    //max and min of each variable:
    //-90.0 < sweepAngle < 90.0
    //nonHubRad > 0.0
    //numberOfIterations >= 2
    //propRadius > 0.0

    SweepLineBuilder builder;

    //-------------------------
    //buildNormedSweepLine test
    //-------------------------

    //emptyList

    QList<QPointF> emptyList;
    emptyList.clear();

    QList<QPointF> sweepLine = builder.buildNormedSweepLine(emptyList, 10, 0.2);
    ASSERT_TRUE(sweepLine.isEmpty());

    //inside list y-value (sweepAngle) > 90 or < -90
    QList<QPointF> sweepAngleList;
    sweepAngleList.clear();
    sweepAngleList.append(QPointF(0.2, -91.0));

    sweepLine = builder.buildNormedSweepLine(sweepAngleList, 10, 0.2);
    ASSERT_TRUE(sweepLine.isEmpty());

    sweepAngleList.clear();
    sweepAngleList.append(QPointF(0.2, 91.0));

    sweepLine = builder.buildNormedSweepLine(sweepAngleList, 10, 0.2);
    ASSERT_TRUE(sweepLine.isEmpty());

    //numberOfIterations < 2

    sweepAngleList.clear();
    sweepAngleList.append(QPointF(0.2, -20.0));
    sweepAngleList.append(QPointF(0.5, 0.0));
    sweepAngleList.append(QPointF(1.0, 45.0));

    sweepLine = builder.buildNormedSweepLine(sweepAngleList, 1, 0.2);
    ASSERT_TRUE(sweepLine.isEmpty());

    //nonHubRad < 0.0
    sweepLine = builder.buildNormedSweepLine(sweepAngleList, 10, -0.1);
    ASSERT_TRUE(sweepLine.isEmpty());

    //parameter values in range

    sweepLine = builder.buildNormedSweepLine(sweepAngleList, 10, 0.2);
    ASSERT_FALSE(sweepLine.isEmpty());


    //------------------------
    //buildSweepLine test
    //------------------------

    //build sweep line calls function build normed sweep line,
    //so some values like nonHubRad do not have to be checked again!

    //propRadius < 0.0
    sweepLine = builder.buildSweepLine(sweepAngleList, 10, 0.2, -0.1);
    ASSERT_TRUE(sweepLine.isEmpty());

    //propeller object is empty

    Propeller* prop = new Propeller();
    sweepLine = builder.buildSweepLine(prop, 10);
    ASSERT_TRUE(sweepLine.isEmpty());

    //parameter values in range
    sweepLine = builder.buildSweepLine(sweepAngleList, 10, 0.2, 0.622);
    ASSERT_FALSE(sweepLine.isEmpty());

    //------------------------
    //buildSweepLine test
    //------------------------

    //tests for functions which create sweep line out of given control points
    //for b-spline

    //sweepAngles not in allowed interval -90.0 < sweepAngle < 90.0
    QPointF hubPnt(0.0, 0.2);
    QPointF tipPnt(0.0, 1.0);

    sweepLine = builder.buildSweepLine(hubPnt, tipPnt, -90.1, 44.0, 20);
    ASSERT_TRUE(sweepLine.isEmpty());

    sweepLine = builder.buildSweepLine(hubPnt, tipPnt, 90.1, 44.0, 20);
    ASSERT_TRUE(sweepLine.isEmpty());

    sweepLine = builder.buildSweepLine(hubPnt, tipPnt, 44.0, -90.1 , 20);
    ASSERT_TRUE(sweepLine.isEmpty());

    sweepLine = builder.buildSweepLine(hubPnt, tipPnt, 44.0, 90.1, 20);
    ASSERT_TRUE(sweepLine.isEmpty());

    //numberOfPoints < 2
    sweepLine = builder.buildSweepLine(hubPnt, tipPnt, 44.0, 20.0, -20);
    ASSERT_TRUE(sweepLine.isEmpty());

    //tipPoint.y() =< hubPoint.y()
    hubPnt.setY(1.5);

    sweepLine = builder.buildSweepLine(hubPnt, tipPnt, 44.0, 20.0, 20);
    ASSERT_TRUE(sweepLine.isEmpty());

    //parameter values in range
    hubPnt.setY(0.2);
    sweepLine = builder.buildSweepLine(hubPnt, tipPnt, 44.0, 20.0, 20);
    ASSERT_FALSE(sweepLine.isEmpty());

    QPointF scndCP(0.0, 0.5);
    hubPnt.setY(1.5);
    sweepLine = builder.buildSweepLine(hubPnt, scndCP, tipPnt, 20);
    ASSERT_TRUE(sweepLine.isEmpty());

    //scndCP.y() >= tipPnt.y()

    hubPnt.setY(0.2);
    scndCP.setY(1.0);

    sweepLine = builder.buildSweepLine(hubPnt, scndCP, tipPnt, 20);
    ASSERT_TRUE(sweepLine.isEmpty());

    //parameter values in range
    scndCP.setY(0.8);
    sweepLine = builder.buildSweepLine(hubPnt, scndCP, tipPnt, 20);
    ASSERT_FALSE(sweepLine.isEmpty());
}
























