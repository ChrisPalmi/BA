#include "nacaxvigeometrybuilder.h"

#include "gtest.h"

#include <QString>

class test_NACAXVIGeometryBuilder : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

};

TEST_F(test_NACAXVIGeometryBuilder, errorHandlingTest)
{
    //max and min of each variable:
    //-3.0 <= cld <= 3.0
    // 0.0 < thicknessRatio (t/b) <= 100
    //PointsPerSide >= 2
    //NumberOfPoints >= 2

    NACAXVIGeometryBuilder builder;

    //--------------------------
    //buildGeometry test
    //--------------------------

    //cld < -3.0
    QList<QPointF> list = builder.buildGeometry(100, 0.2, -3.1);
    ASSERT_TRUE(list.isEmpty());

    //cld > 3.0
    list = builder.buildGeometry(100, 0.2, 3.1);
    ASSERT_TRUE(list.isEmpty());

    //negative thicknessRatio
    list = builder.buildGeometry(100, -0.2, 0.5);
    ASSERT_TRUE(list.isEmpty());

    //thicknessRatio > 1.0
    list = builder.buildGeometry(100, 1.2, 0.5);
    ASSERT_TRUE(list.isEmpty());

    //points per side < 2
    list = builder.buildGeometry(-3, 0.2, 0.5);
    ASSERT_TRUE(list.isEmpty());

    //--------------------------
    //buildGeometryNoCamber test
    //--------------------------

    //negative thicknessRatio
    list = builder.buildGeometryNoCamber(100, -0.05);
    ASSERT_TRUE(list.isEmpty());

    //thicknessRatio > 1.0
    list = builder.buildGeometryNoCamber(100, 1.02);
    ASSERT_TRUE(list.isEmpty());

    //points per side < 2
    list = builder.buildGeometryNoCamber(1, 0.2);
    ASSERT_TRUE(list.isEmpty());

    //--------------------------
    //thicknessDistribution test
    //--------------------------

    //negative thicknessRatio
    list = builder.thicknessDistribution(100, -0.05);
    ASSERT_TRUE(list.isEmpty());

    //thicknessRatio > 1.0
    list = builder.thicknessDistribution(100, 1.02);
    ASSERT_TRUE(list.isEmpty());

    //points per side < 2
    list = builder.thicknessDistribution(1, 0.2);
    ASSERT_TRUE(list.isEmpty());

    //--------------------------
    //camberLine test
    //--------------------------

    //CLD < -3.0
    list = builder.camberLine(100, -3.05);
    ASSERT_TRUE(list.isEmpty());

    //CLD > 3.0
    list = builder.camberLine(100, 3.02);
    ASSERT_TRUE(list.isEmpty());

    //points per side < 2
    list = builder.camberLine(1, 0.2);
    ASSERT_TRUE(list.isEmpty());

    //----------------------------
    //derivativesOfCamberLine test
    //----------------------------

    //CLD < -3.0
    list = builder.derivativesOfCamberLine(100, -3.05);
    ASSERT_TRUE(list.isEmpty());

    //CLD > 3.0
    list = builder.derivativesOfCamberLine(100, 3.02);
    ASSERT_TRUE(list.isEmpty());

    //points per side < 2
    list = builder.derivativesOfCamberLine(1, 0.2);
    ASSERT_TRUE(list.isEmpty());

    //--------------------------------
    //createAirfoilExperimentFile test
    //--------------------------------

    QString bla = "bla";

    //cld < -3.0
    bool success = builder.createAirfoilExperimentFile(-3.1, 0.2, 100,
                                                       10.0, bla);
    ASSERT_FALSE(success);

    //CLD > 3.0
    success = builder.createAirfoilExperimentFile(3.1, 0.2, 100, 10.0, bla);
    ASSERT_FALSE(success);

    //thicknessRatio <= 0.0
    success = builder.createAirfoilExperimentFile(0.5, 0.0, 100, 10.0, bla);
    ASSERT_FALSE(success);

    //thicknessRatio > 1.0
    success = builder.createAirfoilExperimentFile(0.5, 1.01, 100, 10.0, bla);
    ASSERT_FALSE(success);

    //pointsPerSide < 2
    success = builder.createAirfoilExperimentFile(0.5, 0.1, 1, 10.0, bla);
    ASSERT_FALSE(success);

    //diameter <= 0.0
    success = builder.createAirfoilExperimentFile(0.5, 0.1, 100, 0.0, bla);
    ASSERT_FALSE(success);


    //--------------------------------
    //createAirfoilFile test
    //--------------------------------

    //cld < -3.0
    success = builder.createAirfoilFile(-3.1, 0.2, 100, bla);
    ASSERT_FALSE(success);

    //CLD > 3.0
    success = builder.createAirfoilFile(3.1, 0.2, 100, bla);
    ASSERT_FALSE(success);

    //thicknessRatio <= 0.0
    success = builder.createAirfoilFile(0.5, 0.0, 100, bla);
    ASSERT_FALSE(success);

    //thicknessRatio > 1.0
    success = builder.createAirfoilFile(0.5, 1.01, 100, bla);
    ASSERT_FALSE(success);

    //pointsPerSide < 2
    success = builder.createAirfoilFile(0.5, 0.1, 1, bla);
    ASSERT_FALSE(success);

}
