#include "intersectionfinder.h"
#include <QDebug>
#include "gtest.h"

class test_Intersectionfinder : public ::testing::Test
{
protected:
    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

};

TEST_F(test_Intersectionfinder, errorHandling)
{
    QPointF pI(0.0, 0.0);
    QPointF pII(1.0, 0.0);
    QPointF pIII(0.0, 1.0);
    QPointF pIV(2.0, 3.0);

    Intersectionfinder finder;

    //firstDirVect is null!
    QPointF p = finder.findIntersection(pII, pI, pIII, pIV);
    ASSERT_NEAR(0.0, p.x(), 0.00001);
    ASSERT_NEAR(0.0, p.y(), 0.00001);
    ASSERT_FALSE(finder.intersectionFound());

    //secondDirVect is null!
    p = finder.findIntersection(pII, pIV, pIII, pI);
    ASSERT_NEAR(0.0, p.x(), 0.00001);
    ASSERT_NEAR(0.0, p.y(), 0.00001);
    ASSERT_FALSE(finder.intersectionFound());

    //parallel direction vectors
    QPointF pV(4.0, 6.0);
    p = finder.findIntersection(pI, pIV, pII, pV);
    ASSERT_NEAR(0.0, p.x(), 0.00001);
    ASSERT_NEAR(0.0, p.y(), 0.00001);
    ASSERT_FALSE(finder.intersectionFound());

    //first dirvect x = 0
    p = finder.findIntersection(pI, pIII, pII, pIV);
    ASSERT_TRUE(finder.intersectionFound());

    //first dirvect y = 0
    p = finder.findIntersection(pI, pII, pIII, pIV);
    ASSERT_TRUE(finder.intersectionFound());

    QPointF dirVectI(2.0, 0.0);
    QPointF dirVectII(0.0, 2.0);

    p = finder.findIntersection(pI, dirVectI, pII, dirVectII);
    ASSERT_TRUE(finder.intersectionFound());
}


TEST_F(test_Intersectionfinder, findIntersectionTest)
{
    QPointF posVectI(2.0, 0.0);
    QPointF dirVectI(1.0, 1.0);
    QPointF posVectII(4.0, 0.0);
    QPointF dirVectII(0.0, 1.0);

    Intersectionfinder finder;
    QPointF intersection = finder.findIntersection(posVectI, dirVectI,
                                                   posVectII, dirVectII);

    ASSERT_TRUE(finder.intersectionFound());
    ASSERT_NEAR(4.0, intersection.x(), 0.00001);
    ASSERT_NEAR(2.0, intersection.y(), 0.00001);
}
