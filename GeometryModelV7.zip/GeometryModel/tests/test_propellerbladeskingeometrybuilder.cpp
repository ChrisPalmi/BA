#include "propellerbladeskingeometrybuilder.h"
#include "propeller.h"
#include "cogstackingstrategy.h"

#include "gtest.h"

class test_PropellerBladeSkinGeometryBuilder : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

};

TEST_F(test_PropellerBladeSkinGeometryBuilder, errorHandling)
{
    //------------------------
    //buildGeometry test
    //------------------------
    //empty Propeller object
    Propeller* propeller = new Propeller();
    COGStackingStrategy strategy;

    PropellerBladeSkinGeometryBuilder builder;
    QList<QList<QVector3D>> list = builder.buildGeometry(propeller, strategy);

    ASSERT_TRUE(list.isEmpty());

    //------------------------
    //buildGeometry test
    //------------------------
    //empty Propeller object


    PropellerBladeSkinGeometry geom =
            builder.buildPropellerBladeSkinGeometry(propeller, strategy);

    ASSERT_FALSE(geom.geometrySet());

}


























