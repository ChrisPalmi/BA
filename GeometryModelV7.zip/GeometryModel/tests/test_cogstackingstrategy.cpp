#include "cogstackingstrategy.h"

#include <QList>
#include <QVector3D>

#include "gtest.h"


class test_COGStackingStrategy : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

};

TEST_F(test_COGStackingStrategy, errorHandling)
{
    COGStackingStrategy strategy;

    //empty Airfoil
    QList<QList<QVector3D>> emptyAirfoil;
    emptyAirfoil.clear();

    QList<QList<QVector3D>> newEmptyAirfoil =
            strategy.stackAirfoils(emptyAirfoil);

    ASSERT_TRUE(newEmptyAirfoil.isEmpty());

}

TEST_F(test_COGStackingStrategy, stackAirfoilsTest)
{
    QList<QList<QVector3D>> airfoils;
    airfoils.clear();

    QVector3D pI(0.0, 0.0, 0.0);
    QVector3D pII(2.0, 0.0, 0.0);
    QVector3D pIII(2.0, 2.0, 0.0);
    QVector3D pIV(0.0, 2.0, 0.0);

    QList<QVector3D> airfoilI;
    airfoilI.clear();
    airfoilI.append(pI);
    airfoilI.append(pII);
    airfoilI.append(pIII);
    airfoilI.append(pIV);

    QVector3D pV(0.0, 0.0, 0.0);
    QVector3D pVI(2.0, 0.0, 0.0);
    QVector3D pVII(2.0, 2.0, 0.0);
    QVector3D pVIII(0.0, 2.0, 0.0);
    QVector3D pIX(0.0, 0.0, 0.0);

    QList<QVector3D> airfoilII;
    airfoilII.clear();
    airfoilII.append(pV);
    airfoilII.append(pVI);
    airfoilII.append(pVII);
    airfoilII.append(pVIII);
    airfoilII.append(pIX);

    airfoils.append(airfoilI);
    airfoils.append(airfoilII);

    COGStackingStrategy strategy;
    QList<QList<QVector3D>> stackedAirfoils = strategy.stackAirfoils(airfoils);

    //airfoilI
    ASSERT_NEAR(-1.0, stackedAirfoils[0][0].x(), 0.00001);
    ASSERT_NEAR(-1.0, stackedAirfoils[0][0].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[0][0].z(), 0.00001);

    ASSERT_NEAR(1.0, stackedAirfoils[0][1].x(), 0.00001);
    ASSERT_NEAR(-1.0, stackedAirfoils[0][1].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[0][1].z(), 0.00001);

    ASSERT_NEAR(1.0, stackedAirfoils[0][2].x(), 0.00001);
    ASSERT_NEAR(1.0, stackedAirfoils[0][2].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[0][2].z(), 0.00001);

    ASSERT_NEAR(-1.0, stackedAirfoils[0][3].x(), 0.00001);
    ASSERT_NEAR(1.0, stackedAirfoils[0][3].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[0][3].z(), 0.00001);

    //airfoilII
    ASSERT_NEAR(-1.0, stackedAirfoils[1][0].x(), 0.00001);
    ASSERT_NEAR(-1.0, stackedAirfoils[1][0].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[1][0].z(), 0.00001);

    ASSERT_NEAR(1.0, stackedAirfoils[1][1].x(), 0.00001);
    ASSERT_NEAR(-1.0, stackedAirfoils[1][1].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[1][1].z(), 0.00001);

    ASSERT_NEAR(1.0, stackedAirfoils[1][2].x(), 0.00001);
    ASSERT_NEAR(1.0, stackedAirfoils[1][2].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[1][2].z(), 0.00001);

    ASSERT_NEAR(-1.0, stackedAirfoils[1][3].x(), 0.00001);
    ASSERT_NEAR(1.0, stackedAirfoils[1][3].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[1][3].z(), 0.00001);

    ASSERT_NEAR(-1.0, stackedAirfoils[1][4].x(), 0.00001);
    ASSERT_NEAR(-1.0, stackedAirfoils[1][4].y(), 0.00001);
    ASSERT_NEAR(0.0, stackedAirfoils[1][4].z(), 0.00001);

}
