#include "propellerbladeskingeometry.h"
#include <QList>
#include <QVector3D>
#include <QDebug>


#include "gtest.h"


class test_PropellerBladeSkinGeometry : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

};


TEST_F(test_PropellerBladeSkinGeometry, errorHandlingTest)
{
    //check if setting of geometry works
    PropellerBladeSkinGeometry geom;
    ASSERT_FALSE(geom.geometrySet());

    QList<QList<QVector3D>> emptyList;
    emptyList.clear();

    geom.setGeometry(emptyList);
    ASSERT_FALSE(geom.geometrySet());


    QList<QList<QVector3D>> geometryList;
    geometryList.clear();

    QVector3D pnt(0.0, 0.0, 0.0);
    QList<QVector3D> list;
    list.clear();
    list.append(pnt);
    geometryList.append(list);

    geom.setGeometry(geometryList);
    ASSERT_TRUE(geom.geometrySet());

    PropellerBladeSkinGeometry geometry(geometryList);
    ASSERT_TRUE(geometry.geometrySet());

}
