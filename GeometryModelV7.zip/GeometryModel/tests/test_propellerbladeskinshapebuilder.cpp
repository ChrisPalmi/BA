#include "propellerbladeskinshapebuilder.h"

#include "gp_Pnt.hxx"

#include "gtest.h"

class test_PropellerBladSkinShapeBuilder : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

};

TEST_F(test_PropellerBladSkinShapeBuilder, errorHandling)
{
    //--------------------
    //buildShape test
    //--------------------

    //empty input

    QList<QList<QVector3D>> emptyList;
    emptyList.clear();

    PropellerBladeSkinShapeBuilder builder;
    TopoDS_Shape shape = builder.buildShape(emptyList);

    ASSERT_TRUE(shape.IsNull());

    QList<Handle(TColgp_HArray1OfPnt)> emptyListII;
    emptyListII.clear();

    shape = builder.buildShape(emptyListII);
    ASSERT_TRUE(shape.IsNull());

    //input with neighbouring points which are too close next to each other
    QList<QList<QVector3D>> list;
    list.clear();

    QList<QVector3D> aList;
    aList.clear();

    QVector3D pI(0.0, 0.0, 0.0);
    QVector3D pII(0.0, 0.5, 0.0);

    aList.append(pI);
    aList.append(pI);
    aList.append(pII);
    list.append(aList);

    shape = builder.buildShape(list);
    ASSERT_TRUE(shape.IsNull());

    QList<Handle(TColgp_HArray1OfPnt)> listI;
    listI.clear();

    Handle(TColgp_HArray1OfPnt) aListI = new TColgp_HArray1OfPnt(1, 3);

    gp_Pnt pOne(0.0, 0.0, 0.0);
    gp_Pnt pTwo(0.0, 0.5, 0.0);


    aListI->SetValue(1, pOne);
    aListI->SetValue(2, pOne);
    aListI->SetValue(3, pTwo);
    listI.append(aListI);

    shape = builder.buildShape(listI);
    ASSERT_TRUE(shape.IsNull());

}
















