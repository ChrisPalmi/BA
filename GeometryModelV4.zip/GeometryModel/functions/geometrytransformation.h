#ifndef GEOMETRYTRANSFORMATION_H
#define GEOMETRYTRANSFORMATION_H

#include <QList>
#include <QVector3D>

/**
 * @brief The GeometryTransformation class provides functionalities to transform
 *        points or geometries (ordered pointlists). Given transformations:
 *        Scaling, Rotating and Locating
 */
class GeometryTransformation
{
public:
    /**
     * @brief GeometryTransformation constructor
     */
    GeometryTransformation();

    /**
     * @brief ~GeometryTransformation destructor
     */
    ~GeometryTransformation();

    /**
     * @brief resizeGeometry provides functionality to resize a given geometry
     *        (ordered pointlist (scaling from origin (0.0|0.0)))
     * @param geometry (ordered pointlist which should be scaled)
     * @param scalingFactor (factor of scalation)
     * @return scaled geometry (ordered pointlist)
     */
    QList<QVector3D> resizeGeometry(const QList<QVector3D> &geometry,
                                    const double scalingFactor);

    /**
     * @brief resizeMultipleGeometries provides functionality to resize
     *        multiple given geometries (ordered pointlist
     *        (scaling from origin (0.0|0.0)))
     * @param geometries (ordered pointlists which should be scaled)
     * @param scalingFactorList (factors of scalation)
     * @return scaled geometries (ordered pointlists)
     */
    QList<QList<QVector3D>> resizeMultipleGeometries
    (const QList<QList<QVector3D>> &geometries,
     const QList<double> scalingFactorList);

    /**
     * @brief rotatePnt provides functionality to rotate a point in clockwise
     *        direction around the z axis and a given angle
     * @param pnt (point which should be rotated)
     * @param angleDeg (value of angle in degrees)
     * @return rotated point
     */
    QVector3D rotatePnt(const QVector3D &pnt, const double angleDeg);

    /**
     * @brief rotateGeometry provides functionality to rotate a geometry
     *        (ordered pointlist) in clockwise direction around the z axis and
     *        a given angle
     * @param geometry (pointlist which should be rotated)
     * @param angleDeg (value of angle in degrees)
     * @return rotated geometry (ordered pointlist)
     */
    QList<QVector3D> rotateGeometry(const QList<QVector3D> &geometry,
                                   const double angleDeg);

    /**
     * @brief rotateMultipleGeometries provides functionality to rotate
     *        multiple geometries (ordered pointlists) in clockwise direction
     *        around the z axis and a given angle
     * @param geometries (pointlists which should be rotated)
     * @param angleDegList (values of angle in degrees)
     * @return rotated geometris (ordered pointlists)
     */
    QList<QList<QVector3D>> rotateMultipleGeometries
    (const QList<QList<QVector3D>> &geometries,
     const QList<double> angleDegList);

    /**
     * @brief locatePnt provides functionality to relocate a point by moving it
     *        along a given direction vector
     * @param pnt (point which should be relocated)
     * @param directionVect (direction vector)
     * @return (relocated point)
     */
    QVector3D locatePnt(const QVector3D &pnt, const QVector3D &directionVect);

    /**
     * @brief locateGeometry provides functionality to relocate a geometry
     *        (ordered pointlist) by moving it along a given direction vector
     * @param geometry (ordered pointlist which should be relocated)
     * @param directionVect (direction vector)
     * @return relocated geometry (ordered pointlist)
     */
    QList<QVector3D> locateGeometry(const QList<QVector3D> &geometry,
                                   const QVector3D &directionVect);

    /**
     * @brief locateMultipleGeometries provides functionality to relocate
     *         multiple geometries (ordered pointlists) by moving them along
     *         a given direction vector
     * @param geometries (ordered pointlists which should be relocated)
     * @param directionVectList (direction vectors)
     * @return relocated geometries (ordered pointlists)
     */
    QList<QList<QVector3D>> locateMultipleGeometries
    (const QList<QList<QVector3D>> &geometries,
     const QList<QVector3D> &directionVectList);

};

#endif //GEOMETRYTRANSFORMATION_H
