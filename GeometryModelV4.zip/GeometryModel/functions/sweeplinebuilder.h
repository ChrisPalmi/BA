#ifndef SWEEPLINEBUILDER_H
#define SWEEPLINEBUILDER_H

#include "designparametercsvfilereader.h"
#include "propeller.h"

#include <QList>
#include <QPointF>

class SweepLineBuilder
{
public:
    SweepLineBuilder();

    ~SweepLineBuilder();

    QList<QPointF> createNormedSweepLine
    (const QList<QPointF> &sweepAngleDegList, int numberOfIterations,
     double nonHubRad);

    QList<QPointF> createNormedSweepLine(QString sweepAngleDegPath,
                                   int numberOfIterations, double nonHubRad);

    QList<QPointF> createSweepLine(const QList<QPointF> &sweepAngleDegList,
                                   int numberOfIterations, double nonHubRad,
                                   double propRadius);

    QList<QPointF> createSweepLine(QString sweepAngleDegPath,
                                   int numberOfIterations, double nonHubRad,
                                   double propRadius);

    QList<QPointF> createSweepLine(Propeller *propeller,
                                   int numberOfIterations);

private:

    DesignParameterCSVFileReader m_reader;

};

#endif // SWEEPLINEBUILDER_H
