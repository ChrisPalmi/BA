#ifndef DESIGNPARAMETERCSVFILEREADER_H
#define DESIGNPARAMETERCSVFILEREADER_H

#include "abstractdesignparameterfilereader.h"

/**
 * @brief The DesignParameterCSVFileReader class provides functionalities
 *        to read in design parameters of propellers out of csv files and create
 *        an ordered point list out of it
 */
class DesignParameterCSVFileReader : public AbstractDesignParameterFileReader
{
public:
    /**
     * @brief DesignParameterCSVFileReader constructor
     */
    DesignParameterCSVFileReader();

    /**
     * @brief ~DesignParameterCSVFileReader destructor
     */
    ~DesignParameterCSVFileReader();

    /**
     * @brief readFile reads in a csv file with one column. A line of this file
     *        has two values seperated with a ",". First value should be the x
     *        value which is the non-dimensional radius (r/R) and y value should
     *        be the design parameter for r/R
     * @param filepath (path where csv file can be found. For example:
     *        "D:/data/myfiles/aCSVFile.csv"
     * @return ordered point list of a design parameter subject to the
     *         non-dimensional radius
     */
    virtual QList<QPointF> readFile(const QString &filepath);
};

#endif // DESIGNPARAMETERCSVFILEREADER_H
