#include "chordstackingstrategy.h"

ChordStackingStrategy::ChordStackingStrategy()
{

}

//ChordFaedelStrategy::ChordFaedelStrategy(double faedelAt)
//{

//}

ChordStackingStrategy::~ChordStackingStrategy()
{

}

//QList<QList<QVector3D> > ChordFaedelStrategy::
//faedelProfiles(const QList<QList<QVector3D> >& profiles)
//{

//}

//double ChordFaedelStrategy::faedelAt() const
//{
//    return m_faedelAt;
//}

//void ChordFaedelStrategy::setFaedelAt(double faedelAt)
//{
//    m_faedelAt = faedelAt;
//}


