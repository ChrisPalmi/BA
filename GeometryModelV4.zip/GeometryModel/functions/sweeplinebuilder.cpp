#define _USE_MATH_DEFINES
#include <cmath>

#include "sweeplinebuilder.h"

#include "gt_splinefit.h"
#include "rootfinder.h"

#include <QDebug>

SweepLineBuilder::SweepLineBuilder()
{

}

SweepLineBuilder::~SweepLineBuilder()
{

}

QList<QPointF> SweepLineBuilder::
createNormedSweepLine(const QList<QPointF> &sweepAngleDegList,
                      int numberOfIterations,
                      double nonHubRad)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    GtSplineFit* sweepFitter = new GtSplineFit(3, 4, 0.001, 800);
    sweepFitter->fit(sweepAngleDegList);
    qDebug() << "sweep fit";
    RootFinder finder;
    bool brentNotOK = false;

    QList<QPointF> sweepLine;
    sweepLine.clear();

    QPointF firstPoint(0.0, nonHubRad);
    sweepLine.append(firstPoint);

    double iterFactor = (sweepAngleDegList.last().x() - nonHubRad) /
                        (numberOfIterations - 1);
    double lastX = 0.0;

    for(int iterAt = 1; iterAt < numberOfIterations; iterAt++)
    {
        double nonRad = nonHubRad + (iterFactor * iterAt);
        double nonRadBefore = nonHubRad + (iterFactor * (iterAt - 1));

        auto sweepFunc = [nonRadBefore, sweepFitter](double u)
        {
            QPointF aPoint = sweepFitter->getCurvePoint(u);
            double diff = nonRadBefore - aPoint.x();
            return diff;
        };

        double sweepU = finder.Brent(sweepFunc, 0.0, 1.0,
                                     brentNotOK, 1.0e-12, 100);

        if(brentNotOK == true)
        {
            qDebug() << "ERROR: \nBrent did not work!\n"
                        "Empty List of sweep line will be returned!";

            QList<QPointF> emptyList;
            emptyList.clear();
            return emptyList;
        }

        QPointF sweepPnt = sweepFitter->getCurvePoint(sweepU);
        double sweepAngle = sweepPnt.y();


        if(sweepAngle <= 0.0)
        {
            double shift = tan(sweepAngle * (M_PI / 180.0)) * iterFactor;
            double xCoor = lastX + shift;
            QPointF sweepLinePnt(xCoor, nonRad);
            sweepLine.append(sweepLinePnt);

            lastX = xCoor;
        }

        else
        {
            sweepAngle = -1.0 * sweepAngle;
            double shift = tan(sweepAngle * (M_PI / 180.0)) * iterFactor;
            double xCoor = lastX - shift;
            QPointF sweepLinePnt(xCoor, nonRad);
            sweepLine.append(sweepLinePnt);

            lastX = xCoor;
        }
    }

    return sweepLine;
}

QList<QPointF> SweepLineBuilder::
createNormedSweepLine(QString normedSweepAngleDegPath, int numberOfIterations,
                double nonHubRad)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> sweepList =
           m_reader.readFile(normedSweepAngleDegPath);

    return createNormedSweepLine(sweepList, numberOfIterations, nonHubRad);

}

QList<QPointF> SweepLineBuilder::
createSweepLine(const QList<QPointF>& normedSweepAngleDegList,
                int numberOfIterations, double nonHubRad, double propRadius)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> sweepLine = createNormedSweepLine(normedSweepAngleDegList,
                                                     numberOfIterations,
                                                     nonHubRad);

    for(int listAt = 0; listAt < sweepLine.size(); listAt++)
    {
        sweepLine[listAt].setX(sweepLine[listAt].x() * propRadius);
        sweepLine[listAt].setY(sweepLine[listAt].y() * propRadius);
    }

    return sweepLine;
}

QList<QPointF> SweepLineBuilder::
createSweepLine(QString normedSweepAngleDegPath, int numberOfIterations,
                double nonHubRad, double propRadius)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> sweepLine = createNormedSweepLine(normedSweepAngleDegPath,
                                                     numberOfIterations,
                                                     nonHubRad);

    for(int listAt = 0; listAt < sweepLine.size(); listAt++)
    {
        sweepLine[listAt].setX(sweepLine[listAt].x() * propRadius);
        sweepLine[listAt].setY(sweepLine[listAt].y() * propRadius);
    }

    return sweepLine;
}

QList<QPointF> SweepLineBuilder::createSweepLine(Propeller* propeller,
                                                 int numberOfIterations)
{
    if(numberOfIterations < 1)
    {
        qDebug() << "ERROR:\nNumber of iterations has to be > 0\nEmpty List"
                    " will be returned!";

        QList<QPointF> emptyList;
        emptyList.clear();
        return emptyList;
    }

    QList<QPointF> normedSweepAngleDegList;
    normedSweepAngleDegList.clear();

    for(int propAt = 0; propAt < propeller->blade()->numberOfStations();
        propAt++)
    {
        double radi = propeller->blade()->stationNonRadii().at(propAt);

        Station* station =
                propeller->blade()->station(radi);

        double sweepAngleDeg = station->sweepAngleDeg();
        normedSweepAngleDegList.append(QPointF(radi, sweepAngleDeg));
    }

    QList<QPointF> sweepLine =
            createNormedSweepLine(normedSweepAngleDegList, numberOfIterations,
                                  propeller->blade()->nonHubRadius());

    for(int listAt = 0; listAt < sweepLine.size(); listAt++)
    {
        sweepLine[listAt].setX(sweepLine[listAt].x() *
                               propeller->radius() * 1000.0);
        sweepLine[listAt].setY(sweepLine[listAt].y() *
                               propeller->radius() * 1000.0);
    }

    return sweepLine;
}



