#include "nasasrstackingstrategy.h"

#include "gt_splinefit.h"
#include "rootfinder.h"

NASASRStackingStrategy::NASASRStackingStrategy()
{
    setSweepLineSet(false);
}

NASASRStackingStrategy::NASASRStackingStrategy(QList<QPointF> sweepLine)
{
    setSweepLine(sweepLine);
    setSweepLineSet(true);
}



NASASRStackingStrategy::~NASASRStackingStrategy()
{

}

QList<QList<QVector3D> > NASASRStackingStrategy::
stackAirfoils(const QList<QList<QVector3D> >& airfoils)
{
    if(sweepLineSet() == false)
    {
        qDebug() << "ERROR:\nSweep line was not set!\nPlease set it before "
                    "calling this function again!\n"
                    "Same profiles will be returned!";

        return airfoils;
    }

    else
    {

        QList<QList<QVector3D>> sweptProfiles;
        sweptProfiles.clear();

        for(int profileNumb = 0; profileNumb < airfoils.size(); profileNumb++)
        {

            double bladeAngleDeg = m_calculator.calculateBladeAngleDeg
                                   (airfoils.at(profileNumb));

            QVector3D dirVect(-(airfoils[profileNumb][0].x() / 2.0),
                              -(airfoils[profileNumb][0].y() / 2.0), 0.0);

            QList<QVector3D> aProfile =
                           m_transformer.locateGeometry(airfoils.at(profileNumb),
                                                       dirVect);

            //calc sweep and lean
            double profileAtZ = airfoils[profileNumb][0].z();
            double sweep = calculateSweep(profileAtZ);

            QVector3D sweepPnt(sweep, 0.0, profileAtZ);
            sweepPnt = m_transformer.rotatePnt(sweepPnt, bladeAngleDeg);

            for(int pointNumb = 0; pointNumb < airfoils[profileNumb].size();
                pointNumb++)
            {

                aProfile[pointNumb].setX(aProfile[pointNumb].x() +
                                         sweepPnt.x());
                aProfile[pointNumb].setY(aProfile[pointNumb].y() +
                                         sweepPnt.y());
            }

            sweptProfiles.append(aProfile);
        }

        return sweptProfiles;
    }
}

bool NASASRStackingStrategy::sweepLineSet() const
{
    return m_sweepLineSet;
}

QList<QPointF> NASASRStackingStrategy::sweepLine() const
{
    return m_sweepLine;
}

void NASASRStackingStrategy::setSweepLine(const QList<QPointF>& sweepLine)
{
    if(sweepLine.isEmpty())
    {
        qDebug() << "WARNING:\nSweep line is empty!";
        setSweepLineSet(false);
    }
    else
    {
        bool readyToSetSweepLine = true;
        for(int listAt = 0; listAt < (sweepLine.size() - 1); listAt++)
        {
            if(sweepLine.at(listAt).y() >= sweepLine.at(listAt + 1).y())
            {
                qDebug() << "ERROR:\nY values of points have to increase with "
                            "every step!\nSweep line will not be set!";
                readyToSetSweepLine = false;
                setSweepLineSet(false);
            }
        }

        if(readyToSetSweepLine)
        {
            m_sweepLine = sweepLine;
            setSweepLineSet(true);
        }
    }
}

double NASASRStackingStrategy::calculateSweep(double radi)
{
    if(sweepLineSet() == false)
    {
        qDebug() << "ERROR:\n No sweep line was set!\n Please set th sweep line"
                    " before calling this function again!\n Sweep of 0.0 will"
                    " be returned!";

        return 0.0;

    }

    if(radi < 0.0)
    {
        qDebug() << "ERROR:\n No negative radi allowed!\n Sweep of 0.0 "
                    "will be returned!";

        return 0.0;
    }

    if(radi > m_sweepLine.last().y())
    {
        if(radi < m_sweepLine.last().y() * 1.0001)
        {
            radi = m_sweepLine.last().y();
        }

        else
        {
            qDebug() << radi << m_sweepLine.last().y();

            qDebug() << "ERROR: \n Your chosen radi is bigger than max size of"
                        " sweep line you set!\nSweep of 0.0 will be returned!";

            return 0.0;
        }
    }

    double sweep = 0.0;

    for(int i = 0; i < m_sweepLine.size() - 1; i++)
    {


        if(m_sweepLine.at(i).y() <= radi &&
           m_sweepLine.at(i + 1).y() >= radi)
        {

            //calculate sweep
            //linear interpolation between pnt i and i+1 of semichord

            QPointF dirVect(m_sweepLine.at(i + 1).x() - m_sweepLine.at(i).x(),
                            m_sweepLine.at(i + 1).y() - m_sweepLine.at(i).y());

            if(dirVect.y() == 0.0)
            {
                qDebug() << "ERROR:\n Y values of your sweep line have to "
                            "increase with every point!\nSweep of 0.0 will be "
                            "returned!";
                sweep = 0.0;
                return sweep;
            }
            else
            {
                double factor = (radi - m_sweepLine.at(i).y()) / dirVect.y();
                sweep = m_sweepLine.at(i).x() + factor * dirVect.x();
                return sweep;
            }
        }
    }

    return sweep;
}

void NASASRStackingStrategy::setSweepLineSet(bool sweepLineSet)
{
    m_sweepLineSet = sweepLineSet;
}

