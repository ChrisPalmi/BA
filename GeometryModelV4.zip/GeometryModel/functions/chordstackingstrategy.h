#ifndef CHORDSTACKINGSTRATEGY_H
#define CHORDSTACKINGSTRATEGY_H

#include "abstractairfoilstackingstrategy.h"

class ChordStackingStrategy : public AbstractAirfoilStackingStrategy
{
public:
    ChordStackingStrategy();

//    ChordStackingStrategy(double faedelAt);

    ~ChordStackingStrategy();

//    QList<QList<QVector3D>> faedelProfiles
//    (const QList<QList<QVector3D>> &profiles);


//    double faedelAt() const;
//    void setFaedelAt(double faedelAt);

private:

    double m_faedelAt;

};

#endif // CHORDSTACKINGSTRATEGY_H
