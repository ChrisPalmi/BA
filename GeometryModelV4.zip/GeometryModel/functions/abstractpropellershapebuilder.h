#ifndef ABSTRACTPROPELLERSHAPEBUILDER_H
#define ABSTRACTPROPELLERSHAPEBUILDER_H

#include <TopoDS_Shape.hxx>

/**
 * @brief The AbstractPropellerShapeBuilder class provides functionalities to
 *        create a shape (Open Cascade TopoDS_Shape) out of a geometry which was
 *        adapted by class OpenCascadeGeometryAdapter (Abstract class).
 */
class AbstractPropellerShapeBuilder
{
public:

    /**
     * @brief AbstractPropellerShapeBuilder constructor
     */
    AbstractPropellerShapeBuilder();

    /**
     * @brief ~AbstractPropellerShapeBuilder destructor
     */
    virtual ~AbstractPropellerShapeBuilder() {}

    virtual TopoDS_Shape buildShape() = 0;

};

#endif // ABSTRACTPROPELLERSHAPEBUILDER_H
