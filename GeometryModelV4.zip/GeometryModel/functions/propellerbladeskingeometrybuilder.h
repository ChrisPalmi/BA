#ifndef PROPELLERBLADESKINGEOMETRYBUILDER_H
#define PROPELLERBLADESKINGEOMETRYBUILDER_H

#include "abstractpropellergeometrybuilder.h"
#include "nasasrstackingstrategy.h"
#include "geometrytransformation.h"
#include "sweeplinebuilder.h"
#include "propellerbladeskingeometry.h"

#include "propeller.h"


class PropellerBladeSkinGeometryBuilder :
        public AbstractPropellerGeometryBuilder
{
public:
    PropellerBladeSkinGeometryBuilder();

    ~PropellerBladeSkinGeometryBuilder();

    QList<QList<QVector3D>> buildGeometry(const Propeller *propeller,
                                          AbstractAirfoilStackingStrategy
                                          &stackingStrategy);

    PropellerBladeSkinGeometry buildPropellerBladeSkinGeometry
    (const Propeller *propeller,
     AbstractAirfoilStackingStrategy &stackingStrategy);



private:

    GeometryTransformation m_transformer;



    bool outputSTLII(QString filepath, QList<QVector3D> station);
};

#endif // PROPELLERBLADESKINGEOMETRYBUILDER_H
