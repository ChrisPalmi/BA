#include "opencascadegeometryadapter.h"
#include <QDebug>
#include <QFile>

#include "pointdistributer.h"

OpenCascadeGeometryAdapter::OpenCascadeGeometryAdapter()
{

}

OpenCascadeGeometryAdapter::~OpenCascadeGeometryAdapter()
{

}

bool OpenCascadeGeometryAdapter::
outputSTLI(QString filepath, QList<QVector3D> station)
{
    QString filename = filepath + ".stl";
    QFile aFile(filename);

    if (aFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&aFile);

        //list with points of station(stationNumb)

        //xCoors
        for (int pointNumb = 0; pointNumb < station.size() - 1; pointNumb++)
        {
            QVector3D pointP = station.at(pointNumb);

            out << pointP.x() << ", ";
        }

        //after last point new line for yCoors
        QVector3D pointPP = station.at(station.size() - 1);

        out << pointPP.x() << "\n";


        //yCoors
        for (int pointNum = 0; pointNum < station.size() - 1; pointNum++)
        {
            QVector3D pointA = station.at(pointNum);
            out << pointA.y() << ", ";
        }

        QVector3D pointAA = station.at(station.size() - 1);

        out << pointAA.y() << "\n";

    }

    else
    {
        qDebug() << "ERROR: File could not be created";
        return false;
    }

    return true;
}

bool OpenCascadeGeometryAdapter::outputSTLII(QString filepath,
                                            Handle(TColgp_HArray1OfPnt) station)
{
    {
        QString filename = filepath + ".stl";
        QFile aFile(filename);

        if (aFile.open(QFile::WriteOnly | QFile::Truncate))
        {
            QTextStream out(&aFile);

            //list with points of station(stationNumb)

            //xCoors
            for (int pointNumb = 0; pointNumb < station->Length() - 1;
                 pointNumb++)
            {
                gp_Pnt pointP = station->Value(pointNumb + 1);

                out << pointP.X() << ", ";
            }

            //after last point new line for yCoors
            gp_Pnt pointPP = station->Value(station->Length());

            out << pointPP.X() << "\n";


            //yCoors
            for (int pointNum = 0; pointNum < station->Length() - 1; pointNum++)
            {
                gp_Pnt pointA = station->Value(pointNum + 1);
                out << pointA.Y() << ", ";
            }

            gp_Pnt pointAA = station->Value(station->Length());

            out << pointAA.Y() << "\n";

        }

        else
        {
            qDebug() << "ERROR: File could not be created";
            return false;
        }

        return true;
    }
}

void OpenCascadeGeometryAdapter::
createSTLFile(QList<Handle(TColgp_HArray1OfPnt)> blade, QString outputpath)
{
    QFile stlFile(outputpath);
    if(stlFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&stlFile);
        out << "solid propGeometry\n";

        for(int i = 0; i < blade.size() - 1; i++)
        {
            Handle(TColgp_HArray1OfPnt) lowerProfile = blade.at(i);
            Handle(TColgp_HArray1OfPnt) upperProfile = blade.at(i + 1);



            for(int j = 0; j < lowerProfile->Length(); j++)
            {
                //points of two triangles

                gp_Pnt pI;
                gp_Pnt pII;
                gp_Pnt pIII;
                gp_Pnt pIV;

                if(j == lowerProfile->Length() - 1)
                {
                    pI = lowerProfile->Value(j + 1);
                    pII = lowerProfile->Value(1);
                    pIII = upperProfile->Value(j + 1);
                    pIV = upperProfile->Value(1);
                }

                else
                {
                    pI = lowerProfile->Value(j + 1);
                    pII = lowerProfile->Value(j + 2);
                    pIII = upperProfile->Value(j + 1);
                    pIV = upperProfile->Value(j + 2);
                }


                //-----------first triangle------------------------------
                //direction vectors for one triangle
                gp_Pnt dirVectI(pII.X() - pI.X(), pII.Y() - pI.Y(),
                                   pII.Z() - pI.Z());
                gp_Pnt dirVectII(pIII.X() - pI.X(), pIII.Y() - pI.Y(),
                                   pIII.Z() - pI.Z());
                //normal vector
                gp_Pnt normalVect;
                normalVect.SetX(dirVectI.Y() * dirVectII.Z() -
                                dirVectI.Z() * dirVectII.Y());
                normalVect.SetY(dirVectI.Z() * dirVectII.X() -
                                dirVectI.X() * dirVectII.Z());
                normalVect.SetZ(dirVectI.X() * dirVectII.Y() -
                                dirVectI.Y() * dirVectII.X());

                out << "\tfacet normal " << normalVect.X() << " " <<
                    normalVect.Y() << " " << normalVect.Z() << "\n";

                out << "\t\touter loop\n";
                out << "\t\t\tvertex " << pI.X() << " " <<
                       pI.Y() << " " << pI.Z() << "\n";
                out << "\t\t\tvertex " << pII.X() << " " <<
                       pII.Y() << " " << pII.Z() << "\n";
                out << "\t\t\tvertex " << pIII.X() << " " <<
                       pIII.Y() << " " << pIII.Z() << "\n";
                out << "\t\tendloop\n";
                out << "\tendfacet\n";

                //-----------second triangle----------------------------

                //direction vectors for one triangle
                dirVectI.SetX(pIII.X() - pII.X());
                dirVectI.SetY(pIII.Y() - pII.Y());
                dirVectI.SetZ(pIII.Z() - pII.Z());

                dirVectII.SetX(pIV.X() - pII.X());
                dirVectII.SetY(pIV.Y() - pII.Y());
                dirVectII.SetZ(pIV.Z() - pII.Z());

                //normal vector
                normalVect.SetX(dirVectI.Y() * dirVectII.Z() -
                                dirVectI.Z() * dirVectII.Y());
                normalVect.SetY(dirVectI.Z() * dirVectII.X() -
                                dirVectI.X() * dirVectII.Z());
                normalVect.SetZ(dirVectI.X() * dirVectII.Y() -
                                dirVectI.Y() * dirVectII.X());

                out << "\tfacet normal " << normalVect.X() << " " <<
                    normalVect.Y() << " " << normalVect.Z() << "\n";

                out << "\t\touter loop\n";
                out << "\t\t\tvertex " << pII.X() << " " <<
                       pII.Y() << " " << pII.Z() << "\n";
                out << "\t\t\tvertex " << pIII.X() << " " <<
                       pIII.Y() << " " << pIII.Z() << "\n";
                out << "\t\t\tvertex " << pIV.X() << " " <<
                       pIV.Y() << " " << pIV.Z() << "\n";
                out << "\t\tendloop\n";
                out << "\tendfacet\n";

            }

        }

        out << "endsolid propGeometry";

    }
    return;
}

Handle(TColgp_HArray1OfPnt) OpenCascadeGeometryAdapter::
adaptTwoDGeometry(QList<QVector3D> &profile, int deg, int numbOfCP,
             double eps, int maxIter)
{
    int profileSize = profile.size();

    QList<QVector3D> newProfile;
    QVector3D lastPnt;
    newProfile.clear();

    bool nearbyPointsExistent = false;

    for(int profileAt = 0; profileAt < profileSize; profileAt++)
    {
        //check if two neighbouring points are to close to each other
        //for b-spline approximation

        //first point
        if(profileAt == 0)
        {
            newProfile.append(profile[profileAt]);
            lastPnt = profile[profileAt];
        }
        //xCoors close to each other
        else if(profile[profileAt].x() - lastPnt.x() <= 1e-10 &&
                ((profile[profileAt].x() - lastPnt.x()) * -1.0) <= 1e-10)
        {
            //yCoors close to each other
            if(profile[profileAt].y() - lastPnt.y() <= 1e-10 &&
               ((profile[profileAt].y() - lastPnt.y()) * -1.0) <= 1e-10)
            {
                qDebug() << "Nearby Points existent!";
                nearbyPointsExistent = true;
            }

            //points have enaugh space (yCoor space enaugh)
            else
            {
                newProfile.append(profile[profileAt]);
                lastPnt = profile[profileAt];
            }
        }
        //points have enaugh space (xCoor space enaugh)
        else
        {
            newProfile.append(profile[profileAt]);
            lastPnt = profile[profileAt];
        }
    }

    QList<gp_Pnt> ocProfile;
    ocProfile.clear();

    //points have been removed

    if(nearbyPointsExistent)
    {
        //new point distribution with same amount of points than before
        PointDistributer distributer(deg, numbOfCP,
                                     eps, maxIter);


        QList<QPointF> twoDList =
                m_adapter.qVectorThreeDsToQPointFs(newProfile);

        QList<QPointF> twoDListDistributed =
                distributer.equalDistribution(twoDList, profile.size());

        ocProfile = m_adapter.qPointFsToGpPnts(twoDListDistributed,
                                               profile.first().z());
    }
    else
    {
        ocProfile = m_adapter.qVectorThreeDsToGpPnts(profile);
    }

    Handle(TColgp_HArray1OfPnt) ocGeometry =
            new TColgp_HArray1OfPnt(1, profileSize);

    for(int listIter = 0; listIter < profileSize; listIter++)
    {
        ocGeometry->SetValue(listIter + 1, ocProfile.at(listIter));
    }


    return ocGeometry;
}

QList<Handle(TColgp_HArray1OfPnt)> OpenCascadeGeometryAdapter::
adaptThreeDGeometry(QList<QList<QVector3D>> &geometry, int deg, int numbOfCP,
              double eps, int maxIter)
{
    for(int geoAt = 1; geoAt < geometry.size(); geoAt++)
    {
        if(geometry[0].size() != geometry[geoAt].size())
        {
            qDebug() << "ERROR:\nNot all Profiles have the same amount of"
                        "points!\nEmpty List will be returned!";

            QList<Handle(TColgp_HArray1OfPnt)> emptyList;
            emptyList.clear();
            return emptyList;

        }
    }

    QList<Handle(TColgp_HArray1OfPnt)> ocSkinGeometry;
    ocSkinGeometry.clear();

    for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
    {
        qDebug() << "geomAt: " << geomAt;
        Handle(TColgp_HArray1OfPnt) profileGeom =
                adaptTwoDGeometry(geometry[geomAt], deg, numbOfCP,
                             eps, maxIter);

        ocSkinGeometry.append(profileGeom);
    }

//    createSTLFile
//            (ocSkinGeometry,
//             "D:/data/PraxisphaseVI/SRIII/OutputFiles/STLFiles/test.stl");

    return ocSkinGeometry;
}
