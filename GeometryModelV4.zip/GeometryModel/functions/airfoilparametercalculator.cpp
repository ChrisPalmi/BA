#define _USE_MATH_DEFINES
#include <cmath>

#include "airfoilparametercalculator.h"
#include "math.h"

AirfoilParameterCalculator::AirfoilParameterCalculator()
{

}

AirfoilParameterCalculator::~AirfoilParameterCalculator()
{

}

double AirfoilParameterCalculator::
calculateChordLength(const QList<QVector3D>& airfoil)
{
    double chordLength = sqrt(pow(airfoil[0].x(), 2.0) +
                              pow(airfoil[0].y(), 2.0));
    return chordLength;
}

double AirfoilParameterCalculator::
calculateBladeAngleDeg(const QList<QVector3D>& airfoil)
{
    double bladeAngleDeg = atan(airfoil[0].y() / airfoil[0].x()) *
                           (180.0 / M_PI);

    return bladeAngleDeg;
}
