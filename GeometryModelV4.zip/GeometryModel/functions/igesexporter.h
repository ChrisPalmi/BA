#ifndef IGESEXPORTER_H
#define IGESEXPORTER_H

#include "abstractexporter.h"

/**
 * @brief The IGESExporter class provides functionality to create IGES output
 *        files out of a given geometry (Open Cascade TopoDS_Shape)
 */
class IGESExporter : public AbstractExporter
{
public:
    /**
     * @brief IGESExporter constructor
     */
    IGESExporter();

    /**
     * @brief ~IGESExporter destructor
     */
    virtual ~IGESExporter();

    /**
     * @brief exportFile function provides functionality to create IGES output
     *        files out of a given geometry (Open Cascade TopoDS_Shape)
     * @param geometryShape (geometry which should be described in output file)
     * @param filepath (path where output file should be created
     *                  For example: "D:/data/myOutputFiles/myFile.igs")
     */
    void exportFile(TopoDS_Shape& geometryShape, Standard_CString &filepath);
};

#endif // IGESEXPORTER_H
