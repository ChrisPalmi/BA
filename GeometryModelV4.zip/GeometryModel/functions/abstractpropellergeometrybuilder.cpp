#include "abstractpropellergeometrybuilder.h"

AbstractPropellerGeometryBuilder::AbstractPropellerGeometryBuilder()
{

}
