#ifndef OPENCASCADEGEOMETRYADAPTER_H
#define OPENCASCADEGEOMETRYADAPTER_H

#include "abstractgeometryadapter.h"
#include "pointadapter.h"

#include "gp_Pnt.hxx"
#include "TColgp_HArray1OfPnt.hxx"
#include "Standard_Macro.hxx"

#include <QList>
#include <QVector3D>
#include <QString>


class OpenCascadeGeometryAdapter
{
public:
    OpenCascadeGeometryAdapter();

    ~OpenCascadeGeometryAdapter();

    Handle(TColgp_HArray1OfPnt) adaptTwoDGeometry(QList<QVector3D> &geometry,
                                                  int deg, int numbOfCP,
                                                  double eps, int maxIter);

    QList<Handle(TColgp_HArray1OfPnt)>
    adaptThreeDGeometry(QList<QList<QVector3D>> & geometry, int deg,
                        int numbOfCP, double eps, int maxIter);

private:

    PointAdapter m_adapter;

    void createSTLFile(QList<Handle(TColgp_HArray1OfPnt)> blade,
                       QString outputpath);

    bool outputSTLII(QString filepath, Handle(TColgp_HArray1OfPnt) station);
    bool outputSTLI(QString filepath, QList<QVector3D> station);

};

#endif // OPENCASCADEGEOMETRYADAPTER_H
