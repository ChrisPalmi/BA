#ifndef COGSTACKINGSTRATEGY_H
#define COGSTACKINGSTRATEGY_H

#include "abstractairfoilstackingstrategy.h"

class COGStackingStrategy : public AbstractAirfoilStackingStrategy
{
public:
    COGStackingStrategy();

    ~COGStackingStrategy();

//    QList<QList<QVector3D>> faedelProfiles();


private:

//    QVector3D calcCOG(QList<QVector3D> &profile);

};

#endif // COGSTACKINGSTRATEGY_H
