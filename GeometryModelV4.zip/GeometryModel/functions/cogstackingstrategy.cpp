#include "cogstackingstrategy.h"

COGStackingStrategy::COGStackingStrategy()
{

}

COGStackingStrategy::~COGStackingStrategy()
{

}

//QList<QList<QVector3D> > COGFaedelStrategy::faedelProfiles()
//{

//}

//QVector3D COGFaedelStrategy::calcCOG(QList<QVector3D>& profile)
//{

//}
