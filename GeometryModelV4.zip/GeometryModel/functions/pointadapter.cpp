#include "pointadapter.h"

#include <QDebug>

PointAdapter::PointAdapter()
{

}

PointAdapter::~PointAdapter()
{

}

QPointF PointAdapter::gpPntToQPointF(gp_Pnt pnt)
{
    QPointF returnPnt(pnt.X(), pnt.Y());
    return returnPnt;
}

QPointF PointAdapter::qVectorThreeDToQPointF(QVector3D pnt)
{
    QPointF returnPnt(pnt.x(), pnt.y());
    return returnPnt;
}

QVector3D PointAdapter::gpPntToQVectorThreeD(gp_Pnt pnt)
{
    QVector3D returnPnt(pnt.X(), pnt.Y(), pnt.Z());
    return returnPnt;
}

QVector3D PointAdapter::qPointFToQVectorThreeD(QPointF pnt, double zCoor)
{
    QVector3D returnPnt(pnt.x(), pnt.y(), zCoor);
    return returnPnt;
}

gp_Pnt PointAdapter::qVectorThreeDToGpPnt(QVector3D pnt)
{
    gp_Pnt returnPnt(pnt.x(), pnt.y(), pnt.z());
    return returnPnt;
}

gp_Pnt PointAdapter::qPointFToGpPnt(QPointF pnt, double zCoor)
{
    gp_Pnt returnPnt(pnt.x(), pnt.y(), zCoor);
    return returnPnt;
}

QList<QPointF> PointAdapter::gpPntsToQPointFs(QList<gp_Pnt> pnts)
{
    QList<QPointF> returnPnts;
    returnPnts.clear();

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        QPointF aPnt = gpPntToQPointF(pnts[listAt]);
        returnPnts.append(aPnt);
    }

    return returnPnts;
}

QList<QPointF> PointAdapter::qVectorThreeDsToQPointFs(QList<QVector3D> pnts)
{
    QList<QPointF> returnPnts;
    returnPnts.clear();

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        QPointF aPnt = qVectorThreeDToQPointF(pnts[listAt]);
        returnPnts.append(aPnt);
    }

    return returnPnts;
}

QList<QVector3D> PointAdapter::gpPntsToQVectorThreeDs(QList<gp_Pnt> pnts)
{
    QList<QVector3D> returnPnts;
    returnPnts.clear();

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        QVector3D aPnt = gpPntToQVectorThreeD(pnts[listAt]);
        returnPnts.append(aPnt);
    }

    return returnPnts;
}

QList<QVector3D> PointAdapter::qPointFsToQVectorThreeDs(QList<QPointF> pnts,
                                                        QList<double> zCoors)
{
    QList<QVector3D> returnPnts;
    returnPnts.clear();

    if(pnts.size() != zCoors.size())
    {
        qDebug() << "WARNING:\nYour lists have not the same number of items!\n"
                    "Empty List will be returned";

        return returnPnts;
    }

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        QVector3D aPnt = qPointFToQVectorThreeD(pnts[listAt], zCoors[listAt]);
        returnPnts.append(aPnt);
    }

    return returnPnts;
}

QList<QVector3D> PointAdapter::qPointFsToQVectorThreeDs(QList<QPointF> pnts,
                                                        double zCoor)
{
    QList<QVector3D> returnPnts;
    returnPnts.clear();

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        QVector3D aPnt = qPointFToQVectorThreeD(pnts[listAt], zCoor);
        returnPnts.append(aPnt);
    }

    return returnPnts;


}

QList<gp_Pnt> PointAdapter::qVectorThreeDsToGpPnts(QList<QVector3D> pnts)
{
    QList<gp_Pnt> returnPnts;
    returnPnts.clear();

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        gp_Pnt aPnt = qVectorThreeDToGpPnt(pnts[listAt]);
        returnPnts.append(aPnt);
    }

    return returnPnts;
}

QList<gp_Pnt> PointAdapter::qPointFsToGpPnts(QList<QPointF> pnts,
                                             QList<double> zCoors)
{
    QList<gp_Pnt> returnPnts;
    returnPnts.clear();

    if(pnts.size() != zCoors.size())
    {
        qDebug() << "WARNING:\nYour lists have not the same number of items!\n"
                    "Empty List will be returned";

        return returnPnts;
    }

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        gp_Pnt aPnt = qPointFToGpPnt(pnts[listAt], zCoors[listAt]);
        returnPnts.append(aPnt);
    }

    return returnPnts;
}

QList<gp_Pnt> PointAdapter::qPointFsToGpPnts(QList<QPointF> pnts, double zCoor)
{
    QList<gp_Pnt> returnPnts;
    returnPnts.clear();

    for(int listAt = 0; listAt < pnts.size(); listAt++)
    {
        gp_Pnt aPnt = qPointFToGpPnt(pnts[listAt], zCoor);
        returnPnts.append(aPnt);
    }

    return returnPnts;
}
