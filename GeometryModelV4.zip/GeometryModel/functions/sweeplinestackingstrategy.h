#ifndef SWEEPLINESTACKINGSTRATEGY_H
#define SWEEPLINESTACKINGSTRATEGY_H

#include "abstractairfoilstackingstrategy.h"
#include "propeller.h"
#include "designparametercsvfilereader.h"
#include "geometrytransformation.h"
#include "airfoilparametercalculator.h"

class SweepLineStackingStrategy : public AbstractAirfoilStackingStrategy
{
public:

    SweepLineStackingStrategy();

    SweepLineStackingStrategy(QList<QPointF> sweepLine);

    ~SweepLineStackingStrategy();

    QList<QList<QVector3D>> stackAirfoils
    (const QList<QList<QVector3D>> &airfoils);

    QList<QPointF> sweepLine() const;
    void setSweepLine(const QList<QPointF>& sweepLine);
    bool sweepLineSet() const;

    double calculateSweep(double radi);


private:

    QList<QPointF> m_sweepLine;
    bool m_sweepLineSet;
    void setSweepLineSet(bool sweepLineSet);

    AirfoilParameterCalculator m_calculator;
    GeometryTransformation m_transformer;






};

#endif // SWEEPLINESTACKINGSTRATEGY_H
