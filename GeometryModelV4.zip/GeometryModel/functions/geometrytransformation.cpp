#define _USE_MATH_DEFINES
#include <cmath>

#include "geometrytransformation.h"

#include <QDebug>

GeometryTransformation::GeometryTransformation()
{

}

GeometryTransformation::~GeometryTransformation()
{

}


QList<QVector3D> GeometryTransformation::
resizeGeometry(const QList<QVector3D>& geometry, const double scalingFactor)
{
    QList<QVector3D> resizedProfile;
    resizedProfile.clear();

    for(int listAt = 0; listAt < geometry.size(); listAt++)
    {
        QVector3D pnt(geometry[listAt].x() * scalingFactor,
                      geometry[listAt].y() * scalingFactor,
                      geometry[listAt].z());
        resizedProfile.append(pnt);
    }

    return resizedProfile;
}

QList<QList<QVector3D> > GeometryTransformation::resizeMultipleGeometries
(const QList<QList<QVector3D> >& geometries,
 const QList<double> scalingFactorList)
{
    if(geometries.size() != scalingFactorList.size())
    {
        qDebug() << "ERROR:\nYour number of profiles is not the same than your "
                 << "number of scaling factors!\n"
                    "Unrotated profiles will be returned!";

        return geometries;
    }

    QList<QList<QVector3D>> resizedProfiles;
    resizedProfiles.clear();

    for(int profilesAt = 0; profilesAt < geometries.size(); profilesAt++)
    {
        QList<QVector3D> newProfile = resizeGeometry(geometries[profilesAt],
                                             scalingFactorList[profilesAt]);
        resizedProfiles.append(newProfile);
    }

    return resizedProfiles;

}


QVector3D GeometryTransformation::rotatePnt(const QVector3D& pnt,
                                                   const double angleDeg)
{
    /*
     * 2D Position Vector
     *
     * xCoor     yCoor
     *
     * 2D Rotation matrix
     *
     * cos(beta)    -sin(beta)
     * sin(beta)     cos(beta)
     *
     */

    //blade angle degree has to be considered in clockwise rotation
    //matrix multiplication with rotation matrix for x coordinate
    double x = (pnt.x() * cos(angleDeg * (M_PI / 180.0))) +
               (pnt.y() * sin(angleDeg * (M_PI / 180.0)));

    //matrix multiplication with rotation matrix for y coordinate
    double y = (pnt.x() * - sin(angleDeg * (M_PI / 180.0))) +
               (pnt.y() * cos(angleDeg * (M_PI / 180.0)));


    QVector3D rotatedPnt(x, y, pnt.z());

    return rotatedPnt;
}


QList<QVector3D> GeometryTransformation::
rotateGeometry(const QList<QVector3D>& geometry, const double angleDeg)
{
    QList<QVector3D> rotatedProfile;
    rotatedProfile.clear();

    for(int profileAt = 0; profileAt < geometry.size(); profileAt++)
    {
        QVector3D point = rotatePnt(geometry[profileAt], angleDeg);
        rotatedProfile.append(point);
    }

    return rotatedProfile;
}

QList<QList<QVector3D> > GeometryTransformation::rotateMultipleGeometries
(const QList<QList<QVector3D> >& geometries, const QList<double> angleDegList)
{
    if(geometries.size() != angleDegList.size())
    {
        qDebug() << "ERROR:\nYour number of profiles is not the same than your "
                 << "number of angles!\n Unrotated profiles will be returned!";

        return geometries;
    }

    QList<QList<QVector3D>> rotatedProfiles;
    rotatedProfiles.clear();

    for(int profilesAt = 0; profilesAt < geometries.size(); profilesAt++)
    {
        QList<QVector3D> aProfile = rotateGeometry(geometries[profilesAt],
                                             angleDegList[profilesAt]);
        rotatedProfiles.append(aProfile);
    }

    return rotatedProfiles;
}


QVector3D GeometryTransformation::locatePnt(const QVector3D& pnt,
                                          const QVector3D& directionVect)
{
    QVector3D locatedPnt(pnt.x() + directionVect.x(),
                         pnt.y() + directionVect.y(),
                         pnt.z() + directionVect.z());

    return locatedPnt;
}


QList<QVector3D> GeometryTransformation::
locateGeometry(const QList<QVector3D>& geometry, const QVector3D& directionVect)
{
    QList<QVector3D> locatedProfile;
    locatedProfile.clear();

    for(int listAt = 0; listAt < geometry.size(); listAt++)
    {
        QVector3D point = locatePnt(geometry[listAt], directionVect);
        locatedProfile.append(point);
    }

    return locatedProfile;
}

QList<QList<QVector3D> > GeometryTransformation::
locateMultipleGeometries(const QList<QList<QVector3D> >& geometries,
                       const QList<QVector3D>& directionVectList)
{
    if(geometries.size() != directionVectList.size())
    {
        qDebug() << "ERROR:\nYour number of profiles is not the same than your "
                 << "number of direction vectors!\n"
                    "Unrotated profiles will be returned!";

        return geometries;
    }

    QList<QList<QVector3D>> locatedProfiles;
    locatedProfiles.clear();

    for(int profilesAt = 0; profilesAt < geometries.size(); profilesAt++)
    {
        QList<QVector3D> aProfile = locateGeometry(geometries[profilesAt],
                                             directionVectList[profilesAt]);
        locatedProfiles.append(aProfile);
    }

    return locatedProfiles;
}
