#include "abstractpropellergeometry.h"

AbstractPropellerGeometry::AbstractPropellerGeometry()
{

}

QList<QList<QVector3D> > AbstractPropellerGeometry::geometry() const
{
    return m_geometry;
}

void AbstractPropellerGeometry::setGeometry(const QList<QList<QVector3D> >& geometry)
{
    m_geometry = geometry;
}

bool AbstractPropellerGeometry::geometrySet() const
{
    return m_geometrySet;
}

void AbstractPropellerGeometry::setGeometrySet(bool geometrySet)
{
    m_geometrySet = geometrySet;
}
