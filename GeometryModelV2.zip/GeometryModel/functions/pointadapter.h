#ifndef POINTADAPTER_H
#define POINTADAPTER_H

#include <QPointF>
#include <QVector3D>
#include <QList>

#include "gp_Pnt.hxx"


class PointAdapter
{
public:
    PointAdapter();

    ~PointAdapter();

    QPointF gpPntToQPointF(gp_Pnt pnt);

    QPointF qVectorThreeDToQPointF(QVector3D pnt);

    QVector3D gpPntToQVectorThreeD(gp_Pnt pnt);

    QVector3D qPointFToQVectorThreeD(QPointF pnt, double zCoor);

    gp_Pnt qVectorThreeDToGpPnt(QVector3D pnt);

    gp_Pnt qPointFToGpPnt(QPointF pnt, double zCoor);

    QList<QPointF> gpPntsToQPointFs(QList<gp_Pnt> pnts);

    QList<QPointF> qVectorThreeDsToQPointFs(QList<QVector3D> pnts);

    QList<QVector3D> gpPntsToQVectorThreeDs(QList<gp_Pnt> pnts);

    QList<QVector3D> qPointFsToQVectorThreeDs(QList<QPointF> pnts,
                                              QList<double> zCoors);

    QList<gp_Pnt> qVectorThreeDsToGpPnts(QList<QVector3D> pnts);

    QList<gp_Pnt> qPointFsToGpPnts(QList<QPointF> pnts, QList<double> zCoors);


};



#endif // POINTADAPTER_H
