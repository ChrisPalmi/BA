#ifndef ABSTRACTDESIGNPARAMETERFILEREADER_H
#define ABSTRACTDESIGNPARAMETERFILEREADER_H

#include <QPointF>
#include <QList>

class AbstractDesignParameterFileReader
{
public:
    AbstractDesignParameterFileReader();

    ~AbstractDesignParameterFileReader(){}

    virtual QList<QPointF> readFile(const QString &filepath) = 0;
};

#endif // ABSTRACTDESIGNPARAMETERFILEREADER_H
