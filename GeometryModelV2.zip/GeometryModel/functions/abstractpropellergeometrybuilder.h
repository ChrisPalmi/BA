#ifndef ABSTRACTPROPELLERGEOMETRYBUILDER_H
#define ABSTRACTPROPELLERGEOMETRYBUILDER_H

#include <QList>
#include <QVector3D>

class AbstractPropellerGeometryBuilder
{
public:
    AbstractPropellerGeometryBuilder();

    ~AbstractPropellerGeometryBuilder() {}

//    virtual QList<QList<QVector3D>> buildGeometry() = 0;
};

#endif // ABSTRACTPROPELLERGEOMETRYBUILDER_H
