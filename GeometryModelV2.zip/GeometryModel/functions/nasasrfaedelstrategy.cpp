#include "nasasrfaedelstrategy.h"

#include "gt_splinefit.h"
#include "rootfinder.h"

NASASRFaedelStrategy::NASASRFaedelStrategy()
{
    setBAListSet(false);
    setSweepLineSet(false);
}

NASASRFaedelStrategy::NASASRFaedelStrategy(QList<QPointF> sweepLine,
                                           QList<QPointF> bladeAngleList)
{
    setSweepLine(sweepLine);
    setBladeAngleList(bladeAngleList);
    setBAListSet(true);
    setSweepLineSet(true);
}



NASASRFaedelStrategy::~NASASRFaedelStrategy()
{

}

QList<QList<QVector3D> > NASASRFaedelStrategy::
faedelProfiles(const QList<QList<QVector3D> >& profiles)
{
    if(BAListSet() == false && sweepLineSet() == false)
    {
        qDebug() << "WARNING:\nNeither blade angle list, "
                    "nor sweep line was set!\n Please set those before calling "
                    "this function again!\n Same profiles will be returned!";
        return profiles;
    }

    else if(BAListSet() == false)
    {
        qDebug() << "WARNING:\nBlade angle list was not set!\n Please set it "
                    "before calling this function again!\n Same profiles will "
                    "be returned!";

        return profiles;
    }

    else if(sweepLineSet() == false)
    {
        qDebug() << "WARNING:\nSweep line was not set!\n Please set it before "
                    "calling this function again!\n Same profiles will be "
                    "returned!";

        return profiles;
    }

    if(m_bladeAngleList.size() != profiles.size())
    {
        qDebug() << "ERROR:\nBladeAngleList and profiles have not the same"
                    "size!\nSame profiles will be returned";

        return profiles;
    }

    else
    {

        QList<QList<QVector3D>> sweptProfiles;
        sweptProfiles.clear();

        QVector3D sweptPnt;

        for(int profileNumb = 0; profileNumb < profiles.size(); profileNumb++)
        {

            //calc sweep and lean
            double profileAtZ = profiles[profileNumb][0].z();
            double sweep = calculateSweep(profileAtZ);

            double bladeAngle = m_bladeAngleList.at(profileNumb).y();

            QVector3D sweepPnt(sweep, 0.0, profileAtZ);

            sweptPnt = m_transformator.rotatePnt
                       (sweepPnt, bladeAngle);

            QList<QVector3D> aProfile;
            aProfile.clear();

            for(int pointNumb = 0; pointNumb < profiles[profileNumb].size();
                pointNumb++)
            {
                QVector3D pnt;

                pnt.setX(profiles[profileNumb][pointNumb].x() + sweptPnt.x());
                pnt.setY(profiles[profileNumb][pointNumb].y() + sweptPnt.y());
                pnt.setZ(profiles[profileNumb][pointNumb].z());

                aProfile.append(pnt);
            }

            sweptProfiles.append(aProfile);
        }

        return sweptProfiles;
    }
}

QList<QPointF> NASASRFaedelStrategy::bladeAngleList() const
{
    return m_bladeAngleList;
}

void NASASRFaedelStrategy::setBladeAngleList
(const QList<QPointF>& bladeAngleList)
{
    m_bladeAngleList = bladeAngleList;
    if(m_bladeAngleList.isEmpty())
    {
       setBAListSet(false);
    }
    else
    {
        setBAListSet(true);
    }
}

void NASASRFaedelStrategy::setBladeAngleList(const QString& bladeAngleFilePath)
{
    setBladeAngleList(m_reader.readFile(bladeAngleFilePath));
    if(m_bladeAngleList.isEmpty())
    {
       setBAListSet(false);
    }
    else
    {
        setBAListSet(true);
    }
}

bool NASASRFaedelStrategy::BAListSet() const
{
    return m_BAListSet;
}

bool NASASRFaedelStrategy::sweepLineSet() const
{
    return m_sweepLineSet;
}

QList<QPointF> NASASRFaedelStrategy::sweepLine() const
{
    return m_sweepLine;
}

void NASASRFaedelStrategy::setSweepLine(const QList<QPointF>& sweepLine)
{
    if(sweepLine.isEmpty())
    {
        qDebug() << "WARNING:\nSweep line is empty!";
        setSweepLineSet(false);
    }
    else
    {
        bool readyToSetSweepLine = true;
        for(int listAt = 0; listAt < (sweepLine.size() - 1); listAt++)
        {
            if(sweepLine.at(listAt).y() >= sweepLine.at(listAt + 1).y())
            {
                qDebug() << "ERROR:\nY values of points have to increase with "
                            "every step!\nSweep line will not be set!";
                readyToSetSweepLine = false;
                setSweepLineSet(false);
            }
        }

        if(readyToSetSweepLine)
        {
            m_sweepLine = sweepLine;
            setSweepLineSet(true);
        }
    }
}

double NASASRFaedelStrategy::calculateSweep(double radi)
{
    if(sweepLineSet() == false)
    {
        qDebug() << "ERROR:\n No sweep line was set!\n Please set th sweep line"
                    " before calling this function again!\n Sweep of 0.0 will"
                    " be returned!";

        return 0.0;

    }

    if(radi < 0.0)
    {
        qDebug() << "ERROR:\n No negative radi allowed!\n Sweep of 0.0 "
                    "will be returned!";

        return 0.0;
    }

    if(radi > m_sweepLine.last().y())
    {
        qDebug() << "ERROR: \n Your chosen radi ist bigger than max size of "
                    "sweep line you set!\nSweep of 0.0 will be returned!";

        return 0.0;
    }

    double sweep = 0.0;

    for(int i = 0; i < m_sweepLine.size() - 1; i++)
    {


        if(m_sweepLine.at(i).y() <= radi &&
           m_sweepLine.at(i + 1).y() >= radi)
        {

            //calculate sweep
            //linear interpolation between pnt i and i+1 of semichord

            QPointF dirVect(m_sweepLine.at(i + 1).x() - m_sweepLine.at(i).x(),
                            m_sweepLine.at(i + 1).y() - m_sweepLine.at(i).y());

            if(dirVect.y() == 0.0)
            {
                qDebug() << "ERROR:\n Y values of your sweep line have to "
                            "increase with every point!\nSweep of 0.0 will be "
                            "returned!";
                sweep = 0.0;
                return sweep;
            }
            else
            {
                double factor = (radi - m_sweepLine.at(i).y()) / dirVect.y();
                sweep = m_sweepLine.at(i).x() + factor * dirVect.x();
                return sweep;
            }
        }
    }

    return sweep;
}

void NASASRFaedelStrategy::setSweepLineSet(bool sweepLineSet)
{
    m_sweepLineSet = sweepLineSet;
}

void NASASRFaedelStrategy::setBAListSet(bool BAListSet)
{
    m_BAListSet = BAListSet;
}



