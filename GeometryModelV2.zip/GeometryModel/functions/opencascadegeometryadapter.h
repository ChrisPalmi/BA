#ifndef OPENCASCADEGEOMETRYADAPTER_H
#define OPENCASCADEGEOMETRYADAPTER_H

#include "abstractgeometryadapter.h"
#include "pointadapter.h"

#include "gp_Pnt.hxx"
#include <TColgp_HArray1OfPnt.hxx>
#include "Standard_Macro.hxx"

#include <QList>
#include <QVector3D>


class OpenCascadeGeometryAdapter
{
public:
    OpenCascadeGeometryAdapter();

    ~OpenCascadeGeometryAdapter();

    Handle(TColgp_HArray1OfPnt) adaptProfile(QList<QVector3D> &geometry);

    QList<Handle(TColgp_HArray1OfPnt)>
    adaptGeometry(QList<QList<QVector3D>> & geometry);

private:

    PointAdapter m_adapter;


};

#endif // OPENCASCADEGEOMETRYADAPTER_H
