#ifndef NASASRFAEDELSTRATEGY_H
#define NASASRFAEDELSTRATEGY_H

#include "sweeplinefaedelstrategy.h"
#include "designparametercsvfilereader.h"
#include "profiletransformation.h"

class NASASRFaedelStrategy : public AbstractFaedelStrategy
{
public:
    NASASRFaedelStrategy();

    NASASRFaedelStrategy(QList<QPointF> sweepLine,
                         QList<QPointF> bladeAngleList);

    ~NASASRFaedelStrategy();

    virtual QList<QList<QVector3D>>faedelProfiles
    (const QList<QList<QVector3D> > &profiles);

    QList<QPointF> bladeAngleList() const;
    void setBladeAngleList(const QList<QPointF>& bladeAngleList);
    void setBladeAngleList(const QString &bladeAngleFilePath);

    bool BAListSet() const;
    bool sweepLineSet() const;

    QList<QPointF> sweepLine() const;
    void setSweepLine(const QList<QPointF>& sweepLine);

    double calculateSweep(double radi);


private:

    QList<QPointF> m_bladeAngleList;
    bool m_BAListSet;

    QList<QPointF> m_sweepLine;
    bool m_sweepLineSet;

    void setSweepLineSet(bool sweepLineSet);
    void setBAListSet(bool BAListSet);

    DesignParameterCSVFileReader m_reader;
    ProfileTransformation m_transformator;


};

#endif // NASASRFAEDELSTRATEGY_H
