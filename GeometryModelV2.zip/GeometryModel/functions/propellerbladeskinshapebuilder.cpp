#include "propellerbladeskinshapebuilder.h"

#include <QDebug>

#include "TColgp_HArray1OfPnt.hxx"
#include "GeomAPI_Interpolate.hxx"
#include "BRepBuilderAPI_MakeEdge.hxx"
#include "BRepBuilderAPI_MakeWire.hxx"
#include "BRepOffsetAPI_ThruSections.hxx"
#include <Precision.hxx>

PropellerBladeSkinShapeBuilder::PropellerBladeSkinShapeBuilder()
{

}

PropellerBladeSkinShapeBuilder::~PropellerBladeSkinShapeBuilder()
{

}

TopoDS_Shape PropellerBladeSkinShapeBuilder::
buildShape(const QList<QList<QVector3D> >& geometry)
{
    for(int geoAt = 1; geoAt < geometry.size(); geoAt++)
    {
        if(geometry[0].size() != geometry[geoAt].size())
        {
            qDebug() << "ERROR:\nNot all Profiles have the same amount of"
                        "points!\nEmpty TopoDS_Shape will be returned!";

            TopoDS_Shape shape;
            return shape;
        }
    }

    try
    {
        QList<Handle(TColgp_HArray1OfPnt)> ocGeometry;
        ocGeometry.clear();

        for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
        {
            Handle(TColgp_HArray1OfPnt) profileArray = new TColgp_HArray1OfPnt
                                                      (1,
                                                       geometry[geomAt].size());
            for(int profileAt = 1; profileAt <= geometry[geomAt].size();
                profileAt++)
            {
                qDebug() << profileAt;
                gp_Pnt profilepoint = m_adapter.qVectorThreeDToGpPnt
                                      (geometry.at(geomAt).at(profileAt - 1));
                profileArray->SetValue(profileAt, profilepoint);
            }

            ocGeometry.append(profileArray);
        }

        return shapeBuild(ocGeometry);
    }

    catch (...)
    {
        TopoDS_Shape emptyShape;
        return emptyShape;
    }
}


TopoDS_Shape PropellerBladeSkinShapeBuilder::
buildShape(const QList<Handle(TColgp_HArray1OfPnt)> &ocGeometry)
{
    for(int geoAt = 1; geoAt < ocGeometry.size(); geoAt++)
    {
        if(ocGeometry[0]->Length() != ocGeometry[geoAt]->Length())
        {
            qDebug() << "ERROR:\nNot all Profiles have the same amount of"
                        "points!\nEmpty TopoDS_Shape will be returned!";

            TopoDS_Shape shape;
            return shape;
        }
    }

    try
    {
        return shapeBuild(ocGeometry);
    }
    catch (...)
    {
        TopoDS_Shape emptyShape;
        return emptyShape;
    }
}



TopoDS_Shape PropellerBladeSkinShapeBuilder::
shapeBuild(const QList<Handle (TColgp_HArray1OfPnt)> &ocGeometry)
{
    try
    {

        qDebug() << "In shape build";
        QList<TopoDS_Wire> profileWires;


        for(int geomAt = 0; geomAt < ocGeometry.size(); geomAt++)
        {
            qDebug() << "GeomAt: " << geomAt;

            int profileSize = ocGeometry[geomAt]->Length();

            qDebug() << "Interpolator";



//            qDebug() << "P " << geomAt << "|200" << ":";
//            qDebug() << "x: " << ocGeometry[geomAt]->Value(200).X();
//            qDebug() << "y: " << ocGeometry[geomAt]->Value(200).Y();
//            qDebug() << "z: " << ocGeometry[geomAt]->Value(200).Z();

//            qDebug() << "r/R: " << ocGeometry[geomAt]->Value(200).Z() / 0.311;




            GeomAPI_Interpolate interpolator(ocGeometry[geomAt], Standard_False,
                                             1e-6);

            qDebug() << "Perform";
            interpolator.Perform();
            qDebug() << "after perform";

            Handle(Geom_Curve) profileCurve = interpolator.Curve();
            BRepBuilderAPI_MakeWire wireMaker;
            wireMaker.Add(BRepBuilderAPI_MakeEdge(profileCurve));

            //the wing profile might be opened at the trailing edge
            //we close it using a straight line edge
            gp_Pnt first = ocGeometry[geomAt]->Value(1);
            gp_Pnt last  = ocGeometry[geomAt]->Value(profileSize);

            if (first.Distance(last) > Precision::Confusion())
            {
                wireMaker.Add(BRepBuilderAPI_MakeEdge(last, first));
            }

            profileWires.append(wireMaker.Wire());
        }

        BRepOffsetAPI_ThruSections lofter(Standard_True, Standard_False);

        for(int wiresAt = 0; wiresAt < profileWires.size(); wiresAt++)
        {
            lofter.AddWire(profileWires.at(wiresAt));
        }

        lofter.Build();
        TopoDS_Shape propellerBladeSkinGeometryShape = lofter.Shape();

        return propellerBladeSkinGeometryShape;

    }

    catch (...)
    {
        qDebug() << "WARNING:\nSomething went wrong by creating a shape!\n"
                    "Funktion shape build is concerned!\nEmpty Shape will be "
                    "returned!";
        TopoDS_Shape emptyShape;
        return emptyShape;
    }
}




















