#ifndef DESIGNPARAMETERCSVFILEREADER_H
#define DESIGNPARAMETERCSVFILEREADER_H

#include "abstractdesignparameterfilereader.h"

class DesignParameterCSVFileReader : public AbstractDesignParameterFileReader
{
public:
    DesignParameterCSVFileReader();

    ~DesignParameterCSVFileReader();

    virtual QList<QPointF> readFile(const QString &filepath);
};

#endif // DESIGNPARAMETERCSVFILEREADER_H
