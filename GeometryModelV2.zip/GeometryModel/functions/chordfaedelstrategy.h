#ifndef CHORDFAEDELSTRATEGY_H
#define CHORDFAEDELSTRATEGY_H

#include "abstractfaedelstrategy.h"

class ChordFaedelStrategy : public AbstractFaedelStrategy
{
public:
    ChordFaedelStrategy();

    ~ChordFaedelStrategy();

//    QList<QList<QVector3D>> faedelProfiles(double chordAt);
};

#endif // CHORDFAEDELSTRATEGY_H
