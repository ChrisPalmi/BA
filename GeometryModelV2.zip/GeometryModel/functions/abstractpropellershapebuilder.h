#ifndef ABSTRACTPROPELLERSHAPEBUILDER_H
#define ABSTRACTPROPELLERSHAPEBUILDER_H

#include <TopoDS_Shape.hxx>

class AbstractPropellerShapeBuilder
{
public:
    AbstractPropellerShapeBuilder();

    ~AbstractPropellerShapeBuilder() {}

    virtual TopoDS_Shape buildShape() = 0;

};

#endif // ABSTRACTPROPELLERSHAPEBUILDER_H
