#include "opencascadegeometryadapter.h"
#include <QDebug>

OpenCascadeGeometryAdapter::OpenCascadeGeometryAdapter()
{

}

OpenCascadeGeometryAdapter::~OpenCascadeGeometryAdapter()
{

}

Handle(TColgp_HArray1OfPnt) OpenCascadeGeometryAdapter::
adaptProfile(QList<QVector3D> &geometry)
{
    int listSize = geometry.size();
    QList<gp_Pnt> geom = m_adapter.qVectorThreeDsToGpPnts(geometry);

    Handle(TColgp_HArray1OfPnt) ocGeometry = new TColgp_HArray1OfPnt(1,
                                                                     listSize);

    for(int listAt = 0; listAt < listSize; listAt++)
    {
        ocGeometry->SetValue(listAt + 1, geom[listAt]);
    }

    return ocGeometry;
}

QList<Handle(TColgp_HArray1OfPnt)> OpenCascadeGeometryAdapter::
adaptGeometry(QList<QList<QVector3D>> &geometry)
{
    for(int geoAt = 1; geoAt < geometry.size(); geoAt++)
    {
        if(geometry[0].size() != geometry[geoAt].size())
        {
            qDebug() << "ERROR:\nNot all Profiles have the same amount of"
                        "points!\nEmpty List will be returned!";

            QList<Handle(TColgp_HArray1OfPnt)> emptyList;
            emptyList.clear();
            return emptyList;

        }
    }

    QList<Handle(TColgp_HArray1OfPnt)> ocSkinGeometry;
    ocSkinGeometry.clear();

    for(int geomAt = 0; geomAt < geometry.size(); geomAt++)
    {
        Handle(TColgp_HArray1OfPnt) profileGeom =
                adaptProfile(geometry[geomAt]);
        ocSkinGeometry.append(profileGeom);
    }

//    for(int i = 0; i < ocSkinGeometry.size(); i++)
//    {
//        for(int j = 1; j <= ocSkinGeometry[i]->Length(); j++)
//        {
//            qDebug() << "P " << i << "|" << j << ":";
//            qDebug() << "x: " << ocSkinGeometry[i]->Value(j).X();
//            qDebug() << "y: " << ocSkinGeometry[i]->Value(j).Y();
//            qDebug() << "z: " << ocSkinGeometry[i]->Value(j).Z();
//        }
//    }

    return ocSkinGeometry;
}

//Handle_TColgp_HArray1OfPnt OpenCascadeGeometryAdapter::
//adaptGeometry(QList<QVector3D> geometry)
