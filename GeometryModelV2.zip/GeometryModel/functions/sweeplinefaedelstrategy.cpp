#define _USE_MATH_DEFINES
#include <cmath>

#include "sweeplinefaedelstrategy.h"

#include "gt_splinefit.h"
#include "rootfinder.h"

#include <QDebug>

SweepLineFaedelStrategy::SweepLineFaedelStrategy()
{
    setSweepLineSet(false);
}

SweepLineFaedelStrategy::SweepLineFaedelStrategy(QList<QPointF> sweepLine)
{
    setSweepLine(sweepLine);
    setSweepLineSet(true);
}

SweepLineFaedelStrategy::~SweepLineFaedelStrategy()
{

}

QList<QList<QVector3D> > SweepLineFaedelStrategy::
faedelProfiles(const QList<QList<QVector3D> >& profiles)
{
    if(sweepLineSet() == false)
    {
        qDebug() << "ERROR:\n No sweep line was set!\n Please set th sweep line"
                    " before calling this function again!\n Same profiles will"
                    "be returned!";

        return profiles;
    }

    QList<QList<QVector3D>> sweptProfiles;
    sweptProfiles.clear();

    for(int profileNumb = 0; profileNumb < profiles.size(); profileNumb++)
    {

        QList<QVector3D> aProfile;
        aProfile.clear();

        double profileAtZ = profiles[profileNumb][0].z();
        double sweep = calculateSweep(profileAtZ);

        for(int pointNumb = 0; pointNumb < profiles[profileNumb].size();
            pointNumb++)
        {
            QVector3D pnt;
            pnt.setX(profiles[profileNumb][pointNumb].x() + sweep);
            pnt.setY(profiles[profileNumb][pointNumb].y());
            pnt.setZ(profiles[profileNumb][pointNumb].z());

            aProfile.append(pnt);
        }

        sweptProfiles.append(aProfile);
    }

    return sweptProfiles;
}

QList<QPointF> SweepLineFaedelStrategy::sweepLine() const
{
    return m_sweepLine;
}

void SweepLineFaedelStrategy::setSweepLine(const QList<QPointF>& sweepLine)
{
    if(sweepLine.isEmpty())
    {
        qDebug() << "WARNING:\nSweep line is empty!";
        setSweepLineSet(false);
    }
    else
    {
        bool readyToSetSweepLine = true;
        for(int listAt = 0; listAt < (sweepLine.size() - 1); listAt++)
        {
            if(sweepLine.at(listAt).y() >= sweepLine.at(listAt + 1).y())
            {
                qDebug() << "ERROR:\nY values of points have to increase with"
                            "every step!\n Sweep line won´t be set!";
                readyToSetSweepLine = false;
                setSweepLineSet(false);
            }
        }

        if(readyToSetSweepLine)
        {
            m_sweepLine = sweepLine;
            setSweepLineSet(true);
        }
    }
}

bool SweepLineFaedelStrategy::sweepLineSet() const
{
    return m_sweepLineSet;
}

void SweepLineFaedelStrategy::setSweepLineSet(bool sweepLineSet)
{
    m_sweepLineSet = sweepLineSet;
}

double SweepLineFaedelStrategy::calculateSweep(double radi)
{
    if(sweepLineSet() == false)
    {
        qDebug() << "ERROR:\n No sweep line was set!\n Please set th sweep line"
                    " before calling this function again!\n Sweep of 0.0 will"
                    "be returned!";

        return 0.0;

    }

    if(radi < 0.0)
    {
        qDebug() << "ERROR:\n No negative radi allowed!\n Sweep of 0.0 "
                    "will be returned!";

        return 0.0;
    }

    if(radi > m_sweepLine.last().y())
    {
        qDebug() << "ERROR: \n Your chosen radi ist bigger than max size of "
                    "sweep line you set!\n Sweep of 0.0 will be returned!";

        return 0.0;
    }

    double sweep;

    for(int i = 0; i < m_sweepLine.size() - 1; i++)
    {


        if(m_sweepLine.at(i).y() <= radi &&
           m_sweepLine.at(i + 1).y() >= radi)
        {

            //calculate sweep
            //linear interpolation between pnt i and i+1 of semichord

            QPointF dirVect(m_sweepLine.at(i + 1).x() - m_sweepLine.at(i).x(),
                            m_sweepLine.at(i + 1).y() - m_sweepLine.at(i).y());

            if(dirVect.y() == 0.0)
            {
                qDebug() << "ERROR:\n Y values of your sweep line have to "
                            "increase with every point!\nSweep of 0.0 will be "
                            "returned!";
                sweep = 0.0;
            }
            else
            {
                double factor = (radi - m_sweepLine.at(i).y()) / dirVect.y();
                sweep = m_sweepLine.at(i).x() + factor * dirVect.x();
            }


        }
    }

    return sweep;
}























