#ifndef ABSTRACTFAEDELSTRATEGY_H
#define ABSTRACTFAEDELSTRATEGY_H

#include <QList>
#include <QVector3D>

class AbstractFaedelStrategy
{
public:
    AbstractFaedelStrategy();

    ~AbstractFaedelStrategy() {}

    virtual QList<QList<QVector3D>> faedelProfiles
    (const QList<QList<QVector3D>> &profiles) = 0;
};

#endif // ABSTRACTFAEDELSTRATEGY_H
