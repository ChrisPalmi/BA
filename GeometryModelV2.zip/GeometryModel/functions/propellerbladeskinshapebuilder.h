#ifndef PROPELLERBLADESKINSHAPEBUILDER_H
#define PROPELLERBLADESKINSHAPEBUILDER_H

#include "abstractpropellershapebuilder.h"
#include "pointadapter.h"

#include "TopoDS_Wire.hxx"
#include "TColgp_HArray1OfPnt.hxx"

#include <QList>
#include <QVector3D>



class PropellerBladeSkinShapeBuilder
{
public:
    PropellerBladeSkinShapeBuilder();

    ~PropellerBladeSkinShapeBuilder();

    TopoDS_Shape buildShape(const QList<QList<QVector3D>> &geometry);

    TopoDS_Shape buildShape
    (const QList<Handle(TColgp_HArray1OfPnt)> &ocGeometry);

private:

    QList<TopoDS_Wire> m_sections;
    PointAdapter m_adapter;

    TopoDS_Shape shapeBuild
    (const QList<Handle(TColgp_HArray1OfPnt)> &ocGeometry);



};

#endif // PROPELLERBLADESKINSHAPEBUILDER_H
