#include "abstractfaedelstrategy.h"

AbstractFaedelStrategy::AbstractFaedelStrategy()
{

}
