#include "propellerbladeskingeometrybuilder.h"
#include <QFile>

PropellerBladeSkinGeometryBuilder::PropellerBladeSkinGeometryBuilder()
{

}

PropellerBladeSkinGeometryBuilder::~PropellerBladeSkinGeometryBuilder()
{

}

QList<QList<QVector3D> > PropellerBladeSkinGeometryBuilder::
buildGeometry(const Propeller *propeller)
{
    //propeller design parameters
    double radius = propeller->radius();
    Blade *blade = propeller->blade();
    double nonHubRadius = blade->nonHubRadius();


    //get profile geometries and further design parameters

    QList<QList<QVector3D>> allProfiles;
    allProfiles.clear();

    QList<QPointF> bladeAngleDistribution;
    bladeAngleDistribution.clear();

    QList<QPointF> sweepAngleDegDistribution;
    sweepAngleDegDistribution.clear();

    for(int profileNumb = 0; profileNumb < blade->stationNonRadii().size();
        profileNumb++)
    {
        Station *station =
                blade->station(blade->stationNonRadii().at(profileNumb));

        double radi = station->nonRadius() * radius;

        sweepAngleDegDistribution.append(QPointF(station->nonRadius(),
                                                 station->sweepAngleDeg()));
        bladeAngleDistribution.append(QPointF(station->nonRadius(),
                                              station->bladeAngleDeg()));

        QVector<QPointF> geom =
                station->airfoil()->airfoilGeometry()->geometry();

        QList<QVector3D> profileGeometry;

        for(int geomAt = 0; geomAt < geom.size(); geomAt++)
        {
            QVector3D pnt(geom[geomAt].x(), geom[geomAt].y(), radi);

            profileGeometry.append(pnt);
        }

        profileGeometry = m_transformer.resizeProfile(profileGeometry,
                                                      station->chord());

        profileGeometry = m_transformer.locateProfile
                          (profileGeometry,
                           QVector3D(-(station->chord() / 2.0), 0.0, 0.0));

        profileGeometry = m_transformer.rotateProfile(profileGeometry,
                                                      station->bladeAngleDeg());

        allProfiles.append(profileGeometry);
    }

    //consider sweep and lean

    QList<QPointF> sweepLine =
            m_sweepLineBuilder.createSweepLine(sweepAngleDegDistribution, 10000,
                                               nonHubRadius, radius);

    m_sweeper.setSweepLine(sweepLine);
    m_sweeper.setBladeAngleList(bladeAngleDistribution);

    QList<QList<QVector3D>> finalGeometry =
            m_sweeper.faedelProfiles(allProfiles);

    for(int i = 0; i < finalGeometry.size(); i++)
    {
        QString path = "D:/data/PraxisphaseVI/SRIII/Profiles/Profile" +
                       QString::number(i);
        outputSTLII(path, finalGeometry.at(i));
    }

    return finalGeometry;

}

PropellerBladeSkinGeometry PropellerBladeSkinGeometryBuilder::
buildPropellerBladeSkinGeometry(const Propeller* propeller)
{
    QList<QList<QVector3D>> geometry = buildGeometry(propeller);
    PropellerBladeSkinGeometry skinGeometry(geometry);
    return skinGeometry;
}


bool PropellerBladeSkinGeometryBuilder::
outputSTLII(QString filepath, QList<QVector3D> station)
{
    QString filename = filepath + ".stl";
    QFile aFile(filename);

    if (aFile.open(QFile::WriteOnly | QFile::Truncate))
    {
        QTextStream out(&aFile);

        //list with points of station(stationNumb)

        //xCoors
        for (int pointNumb = 0; pointNumb < station.size() - 1; pointNumb++)
        {
            QVector3D pointP = station.at(pointNumb);

            out << pointP.x() << ", ";
        }

        //after last point new line for yCoors
        QVector3D pointPP = station.at(station.size() - 1);

        out << pointPP.x() << "\n";


        //yCoors
        for (int pointNum = 0; pointNum < station.size() - 1; pointNum++)
        {
            QVector3D pointA = station.at(pointNum);
            out << pointA.y() << ", ";
        }

        QVector3D pointAA = station.at(station.size() - 1);

        out << pointAA.y() << "\n";

    }

    else
    {
        qDebug() << "ERROR: File could not be created";
        return false;
    }

    return true;
}























