#include "sweeplinefaedelstrategy.h"

#include "gtest.h"


class test_SweepLineFaedelStrategy : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }



    SweepLineFaedelStrategy strategy;


};

TEST_F(test_SweepLineFaedelStrategy, errorHandlingTest)
{
    //faedelProfiles
    //no sweepline set
    QList<QList<QVector3D>> profiles;
    profiles.clear();

    QList<QVector3D> pI;
    pI.clear();
    QList<QVector3D> pII;
    pII.clear();

    QVector3D pOne(0.0, -1.0, 10.0);
    QVector3D pTwo(-2.5, 6.99, 0.0);

    pI.append(pOne);
    pII.append(pTwo);

    profiles.append(pI);
    profiles.append(pII);

    QList<QList<QVector3D>> newProfiles = strategy.faedelProfiles(profiles);

    ASSERT_NEAR(profiles[0][0].x(), newProfiles[0][0].x(), 0.00001);
    ASSERT_NEAR(profiles[0][0].y(), newProfiles[0][0].y(), 0.00001);
    ASSERT_NEAR(profiles[0][0].z(), newProfiles[0][0].z(), 0.00001);
    ASSERT_NEAR(profiles[1][0].x(), newProfiles[1][0].x(), 0.00001);
    ASSERT_NEAR(profiles[1][0].y(), newProfiles[1][0].y(), 0.00001);
    ASSERT_NEAR(profiles[1][0].z(), newProfiles[1][0].z(), 0.00001);

    //calculateSweep
    //no sweepline set
    double sweep = strategy.calculateSweep(0.2);
    ASSERT_NEAR(0.0, sweep, 0.00001);
    ASSERT_FALSE(strategy.sweepLineSet());

    //sweep line with two points with the same y coor
    QList<QPointF> sweepLine;
    sweepLine.append(QPointF(0.0, 0.0));
    sweepLine.append(QPointF(-1.0, 0.5));
    sweepLine.append(QPointF(1.0, 0.5));

    strategy.setSweepLine(sweepLine);
    ASSERT_FALSE(strategy.sweepLineSet());

    //sweep line with two points with decreasing y coor
    sweepLine.clear();
    sweepLine.append(QPointF(0.0, 0.0));
    sweepLine.append(QPointF(-1.0, 0.5));
    sweepLine.append(QPointF(1.0, 0.4));
    strategy.setSweepLine(sweepLine);
    ASSERT_FALSE(strategy.sweepLineSet());

    sweepLine.clear();
    sweepLine.append(QPointF(0.0, 0.0));
    sweepLine.append(QPointF(-1.0, 0.5));
    sweepLine.append(QPointF(1.0, 1.0));
    strategy.setSweepLine(sweepLine);
    ASSERT_TRUE(strategy.sweepLineSet());

    //radi > propRadius
    sweep = strategy.calculateSweep(1.25);
    ASSERT_NEAR(0.0, sweep, 0.00001);
    ASSERT_TRUE(strategy.sweepLineSet());

    //radi < 0.0
    sweep = strategy.calculateSweep(-0.05);
    ASSERT_NEAR(0.0, sweep, 0.00001);
    ASSERT_TRUE(strategy.sweepLineSet());

}

TEST_F(test_SweepLineFaedelStrategy, calculateSweepTest)
{
    QList<QPointF> sweepLine;
    sweepLine.append(QPointF(0.0, 0.0));
    sweepLine.append(QPointF(-1.0, 0.5));
    sweepLine.append(QPointF(1.0, 1.0));

    SweepLineFaedelStrategy s(sweepLine);

    double sweep = s.calculateSweep(0.0);
    ASSERT_NEAR(0.0, sweep, 0.00001);
    sweep = s.calculateSweep(0.25);
    ASSERT_NEAR(-0.5, sweep, 0.00001);
    sweep = s.calculateSweep(0.5);
    ASSERT_NEAR(-1.0, sweep, 0.00001);
    sweep = s.calculateSweep(0.75);
    ASSERT_NEAR(0.0, sweep, 0.00001);
    sweep = s.calculateSweep(1.0);
    ASSERT_NEAR(1.0, sweep, 0.00001);
}

TEST_F(test_SweepLineFaedelStrategy, faedelProfilesTest)
{
    QList<QPointF> sweepLine;
    sweepLine.clear();
    sweepLine.append(QPointF(0.0, 0.0));
    sweepLine.append(QPointF(-1.0, 0.5));
    sweepLine.append(QPointF(1.0, 1.0));

    SweepLineFaedelStrategy s(sweepLine);

    QVector3D testPnt(0.0, 0.0, 0.0);
    QList<QVector3D> testProfile;
    testProfile.clear();
    testProfile.append(testPnt);
    QList<QList<QVector3D>> testProp;
    testProp.clear();
    testProp.append(testProfile);

    QList<QList<QVector3D>> newProp = s.faedelProfiles(testProp);
    //sweep only affects xCoor of every profile
    ASSERT_NEAR(0.0, newProp[0][0].x(), 0.00001);

    testProp[0][0].setZ(0.25);
    newProp = s.faedelProfiles(testProp);
    ASSERT_NEAR(-0.5, newProp[0][0].x(), 0.00001);

    testProp[0][0].setZ(0.5);
    newProp = s.faedelProfiles(testProp);
    ASSERT_NEAR(-1.0, newProp[0][0].x(), 0.00001);

    testProp[0][0].setZ(0.75);
    newProp = s.faedelProfiles(testProp);
    ASSERT_NEAR(0.0, newProp[0][0].x(), 0.00001);

    testProp[0][0].setZ(1.0);
    newProp = s.faedelProfiles(testProp);
    ASSERT_NEAR(1.0, newProp[0][0].x(), 0.00001);
}
