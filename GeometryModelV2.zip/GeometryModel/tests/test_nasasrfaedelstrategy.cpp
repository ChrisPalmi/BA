#include "nasasrfaedelstrategy.h"
#include "designparametercsvfilereader.h"
#include "profiletransformation.h"

#include <QDebug>
#include <QString>

#include "gtest.h"



class test_NASASRFaedelStrategy : public ::testing::Test
{

protected:

    virtual void SetUp()
    {

    }

    virtual void TearDown()
    {

    }

    NASASRFaedelStrategy strategy;
    DesignParameterCSVFileReader reader;
    ProfileTransformation trafo;
};

TEST_F(test_NASASRFaedelStrategy, errorHandlingTest)
{
    //faedelProfiles
    //no sweepline set, no blade angle list set
    QList<QList<QVector3D>> profiles;
    profiles.clear();

    QList<QVector3D> pI;
    pI.clear();
    QList<QVector3D> pII;
    pII.clear();

    QVector3D pOne(0.0, -1.0, 10.0);
    QVector3D pTwo(-2.5, 6.99, 0.0);

    pI.append(pOne);
    pII.append(pTwo);

    profiles.append(pI);
    profiles.append(pII);

    QList<QList<QVector3D>> newProfiles = strategy.faedelProfiles(profiles);

    ASSERT_NEAR(profiles[0][0].x(), newProfiles[0][0].x(), 0.00001);
    ASSERT_NEAR(profiles[0][0].y(), newProfiles[0][0].y(), 0.00001);
    ASSERT_NEAR(profiles[0][0].z(), newProfiles[0][0].z(), 0.00001);
    ASSERT_NEAR(profiles[1][0].x(), newProfiles[1][0].x(), 0.00001);
    ASSERT_NEAR(profiles[1][0].y(), newProfiles[1][0].y(), 0.00001);
    ASSERT_NEAR(profiles[1][0].z(), newProfiles[1][0].z(), 0.00001);

    //no blade angle list set

    QList<QPointF> sweepLine;
    sweepLine.append(QPointF(0.0, 0.0));
    sweepLine.append(QPointF(-1.0, 0.5));
    sweepLine.append(QPointF(1.0, 1.0));

    strategy.setSweepLine(sweepLine);

    newProfiles = strategy.faedelProfiles(profiles);

    ASSERT_NEAR(profiles[0][0].x(), newProfiles[0][0].x(), 0.00001);
    ASSERT_NEAR(profiles[0][0].y(), newProfiles[0][0].y(), 0.00001);
    ASSERT_NEAR(profiles[0][0].z(), newProfiles[0][0].z(), 0.00001);
    ASSERT_NEAR(profiles[1][0].x(), newProfiles[1][0].x(), 0.00001);
    ASSERT_NEAR(profiles[1][0].y(), newProfiles[1][0].y(), 0.00001);
    ASSERT_NEAR(profiles[1][0].z(), newProfiles[1][0].z(), 0.00001);


    //no sweep line set
    NASASRFaedelStrategy s;
    s.setBladeAngleList(sweepLine);

    newProfiles = s.faedelProfiles(profiles);

    ASSERT_NEAR(profiles[0][0].x(), newProfiles[0][0].x(), 0.00001);
    ASSERT_NEAR(profiles[0][0].y(), newProfiles[0][0].y(), 0.00001);
    ASSERT_NEAR(profiles[0][0].z(), newProfiles[0][0].z(), 0.00001);
    ASSERT_NEAR(profiles[1][0].x(), newProfiles[1][0].x(), 0.00001);
    ASSERT_NEAR(profiles[1][0].y(), newProfiles[1][0].y(), 0.00001);
    ASSERT_NEAR(profiles[1][0].z(), newProfiles[1][0].z(), 0.00001);

    //sweep line with two points with same y coordinate
    QList<QPointF> sLine;
    sLine.clear();

    sLine.append(QPointF(0.0, 0.0));
    sLine.append(QPointF(0.5, 0.3));
    sLine.append(QPointF(1.0, 0.3));

    ASSERT_FALSE(s.sweepLineSet());
    s.setSweepLine(sLine);
    ASSERT_FALSE(s.sweepLineSet());

    sLine.clear();

    //sweep line with two points with decreasing y coordinates
    sLine.append(QPointF(0.0, 0.0));
    sLine.append(QPointF(0.5, 0.3));
    sLine.append(QPointF(1.0, 0.2));

    s.setSweepLine(sLine);
    ASSERT_FALSE(s.sweepLineSet());



}

TEST_F(test_NASASRFaedelStrategy, faedelProfilesTest)
{
    QList<QPointF> sweepLine;
    sweepLine.clear();
    sweepLine.append(QPointF(0.0, 0.3));
    sweepLine.append(QPointF(-1.0, 0.75));
    sweepLine.append(QPointF(1.0, 1.5));

    QList<QPointF> bladeAngleList;
    bladeAngleList.append(QPointF(0.3, 0.0));
    bladeAngleList.append(QPointF(0.75, 9.5));
    bladeAngleList.append(QPointF(1.5, 10.7));

    strategy.setBladeAngleList(bladeAngleList);
    strategy.setSweepLine(sweepLine);

    QVector3D testPnt(0.0, 0.0, 0.3);
    QVector3D testPntII(0.0, 0.0, 0.75);
    QVector3D radPnt(0.0, 0.0, 1.5);

    QList<QVector3D> testProfile;
    QList<QVector3D> testProfileI;
    QList<QVector3D> testProfileII;
    testProfile.clear();
    testProfileI.clear();
    testProfileII.clear();
    testProfile.append(testPnt);
    testProfileI.append(testPntII);
    testProfileII.append(radPnt);

    QList<QList<QVector3D>> testProp;
    testProp.clear();
    testProp.append(testProfile);
    testProp.append(testProfileI);
    testProp.append(testProfileII);

    QList<QList<QVector3D>> newProp = strategy.faedelProfiles(testProp);
    //no sweep at r = 0.3 -> see testPnt
    ASSERT_NEAR(0.0, newProp[0][0].x(), 0.001);
    ASSERT_NEAR(0.0, newProp[0][0].y(), 0.001);

    //blade angle at r = 0.75 is about 9.5 degrees
    QVector3D estimate = trafo.rotatePnt(QVector3D(-1.0, 0.0, 0.5), 9.5);

    newProp = strategy.faedelProfiles(testProp);

    ASSERT_NEAR(estimate.x(), newProp[1][0].x(), 0.00001);
    ASSERT_NEAR(estimate.y(), newProp[1][0].y(), 0.00001);

}

